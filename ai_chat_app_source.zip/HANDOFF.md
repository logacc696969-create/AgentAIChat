# HANDOFF: AI Chat App (Flutter) — Trạng thái & tiếp tục từ đây

> Đọc file này thay vì đọc lại hội thoại gốc. Mục tiêu: build app Android
> hoàn chỉnh từ source đã có, KHÔNG lặp lại các quyết định/lỗi bên dưới.

## 1. Mục tiêu sản phẩm (yêu cầu gốc của người dùng)

- Tên app: **AgentAiChat** (đổi từ "ai_chat_app" theo yêu cầu), icon riêng
  đã tạo (`assets/icon/app_icon.png`, tự sinh mọi size qua
  `flutter_launcher_icons` trên CI).
- App chat AI kiểu Claude/ChatGPT, gọi **API model bất kỳ do người dùng tự
  cấu hình** — **tuyệt đối không hardcode hãng/model nào**.
- Quản lý nhiều đoạn chat như app chat khác: folder, ghim, đổi tên, xóa.
- **Ưu tiên #1 xuyên suốt dự án: tối ưu token khi chat dài/phức tạp.**
- Xuất file từ câu trả lời AI: docx, pptx, xlsx, zip source code (để push
  GitHub build).
- Chuyển model giữa chừng 1 đoạn chat, tiếp tục mạch, **không đốt token**
  để "giải thích lại ngữ cảnh".
- **Thảo luận nhóm nhiều model**: chọn ≥2 provider cùng tham gia 1 đoạn
  chat, mỗi model lần lượt trả lời, thấy được ý kiến model nói trước (xem
  mục 4.8).
- (Đề xuất, chưa hoàn thiện) Tự động build APK qua GitHub Actions, tự đọc
  lỗi và tự sửa bằng AI.

## 2. Stack & lý do chọn

| Quyết định | Lý do |
|---|---|
| Flutter | 1 codebase → APK, CI build dễ nhất qua GitHub Actions |
| Hive (không phải sqflite) | NoSQL nhẹ, không cần server, đủ cho local storage |
| `provider` package | State management đơn giản, đủ dùng |
| `archive` package tự dựng XML | docx/pptx/xlsx đều là zip+XML — tự viết để tránh phụ thuộc thư viện Office nặng/trả phí |
| Hive adapters **viết tay**, KHÔNG dùng `build_runner` | Môi trường dev lúc viết code không có mạng để chạy codegen — đã viết `.g.dart` thủ công khớp 100% với model |

## 3. Kiến trúc thư mục (đã code xong, nằm trong `ai_chat_app_source.zip` đã gửi)

```
lib/
  models/         ChatMessage, Conversation, ChatFolder, ProviderConfig (+ .g.dart tay)
  services/
    api_service.dart        gọi API 3 định dạng: openaiCompatible / anthropicCompatible / custom
    context_manager.dart     LÕI tối ưu token (xem mục 4)
    token_estimator.dart     ước lượng token (không có tokenizer thật vì đa hãng)
    usage_service.dart       lưu token THẬT (từ field usage của API) theo ngày/provider
    storage_service.dart     Hive boxes
    github_build_service.dart  auto-build qua GitHub API (CHƯA có UI, xem mục 6)
    export/{docx,pptx,xlsx,code_zip}_export.dart
  providers/chat_provider.dart   ChangeNotifier trung tâm, nối tất cả service trên
  screens/  chat/ home/ settings/(provider_settings, provider_edit, usage_stats)
  widgets/  message_bubble, chat_input_bar, token_usage_bar, export_menu
```

## 4. Cơ chế tối ưu token (đã implement, ĐỪNG thiết kế lại từ đầu)

1. **Sliding window** 12 tin nhắn gần nhất giữ nguyên văn.
2. **Auto-summarize**: khi tổng token ước tính > 65% `maxContextTokens` của
   provider đang dùng → gọi chính model đó tóm tắt phần cũ, thay thế lịch sử
   gốc bằng bản tóm tắt (message có `isSummary=true`; message gốc đánh dấu
   `collapsedIntoSummary=true`, vẫn hiển thị UI nhưng không gửi API nữa).
3. **Incremental summary**: tóm tắt lần sau = tóm tắt cũ + tin mới, không
   tóm tắt lại từ đầu.
4. Safety margin 15% — không bao giờ build context sát giới hạn.
5. **Usage THẬT từ API** (`ApiUsage` parse từ field `usage` trong response,
   kể cả streaming qua `stream_options.include_usage`/Anthropic
   `message_delta`) ghi đè lên số ước lượng ngay khi có, để các quyết định
   sau chính xác hơn.
6. **Chuyển model giữa chừng** (`ContextManager.switchModel`): chèn 1
   message `isSystemNote=true` (không tính token, không gửi API) đánh dấu
   mốc chuyển; nếu model mới có `maxContextTokens` ≥ model cũ → **tái dùng
   nguyên bản tóm tắt cũ, KHÔNG gọi thêm request tóm tắt nào**; chỉ tóm tắt
   nén thêm khi model mới có ngữ cảnh nhỏ hơn hẳn.
7. **Thinking/reasoning_effort** (field `reasoningEffort` trên
   ProviderConfig): map sang `reasoning_effort` (OpenAI-compat/Gemini) hoặc
   `thinking.budget_tokens` (Anthropic: low=2000/medium=8000/high=16000).
   Bật cao hơn tốn thêm completion token — đánh đổi có chủ đích, không phải
   bug.
8. **Thảo luận nhóm nhiều model** (`Conversation.discussionProviderIds`,
   `ChatMessage.speakerProviderId/speakerName`, `ChatProvider.
   sendDiscussionMessage`): mỗi model trong danh sách lần lượt trả lời 1
   câu hỏi, context của model sau có prefix `[Tên model]: ` trên các tin
   nhắn assistant trước đó (xử lý trong `ContextManager.buildContext`) để
   nó hiểu đó là phát biểu của model KHÁC, không phải lượt trả lời cũ của
   chính nó. Token vẫn tối ưu riêng theo `maxContextTokens` của TỪNG model
   tham gia — không dùng chung 1 ngân sách.
9. **Override riêng theo từng đoạn chat** (`Conversation.
   reasoningEffortOverride`/`temperatureOverride`/`webSearchOverride`,
   `ChatProvider._effectiveProvider`/`setChatOverrides`, UI:
   `chat_quick_settings_sheet.dart`, icon ⚙️ trên chat_screen):
   Thinking/Temperature/System prompt/Web search giờ đổi được NGAY TRONG
   LÚC CHAT, riêng cho từng đoạn chat, không cần vào lại Cài đặt Provider —
   khắc phục hạn chế "cài đặt chết" mà người dùng phản ánh. `temperature`
   cũng đã có UI (slider) ở màn hình sửa Provider — trước đó field có
   trong model nhưng bị thiếu UI, đã bổ sung.
10. **Tìm kiếm web** (`ProviderConfig.webSearchEnabled`,
    `Conversation.webSearchOverride`, xử lý trong `api_service.dart
    _buildBody`): Anthropic dùng tool chính thức `web_search_20250305`
    (ổn định, có tài liệu). OpenAI-compatible/Custom gửi
    `web_search_options: {}` — CHỈ có tác dụng thật với model dòng search
    của OpenAI (gpt-4o-search-preview, gpt-5-search-api); với Gemini qua
    endpoint OpenAI-compat, tài liệu Google hiện KHÔNG xác nhận field
    tương đương cho chat/completions (chỉ thấy cho ảnh/video) — đã tra
    cứu kỹ, không đoán mò, ghi rõ mức độ tin cậy khác nhau theo từng
    provider trong cả README lẫn UI. Không phải scraping/browser — chỉ là
    bật đúng field API.
11. **Panel "File đã tạo"** (`models/generated_file.dart` typeId=7,
    `Conversation.generatedFiles`, `widgets/generated_files_panel.dart`,
    `widgets/export_runner.dart` — logic xuất file dùng chung, tách khỏi
    `export_menu.dart` để panel "xuất lại" gọi lại được y hệt): icon 📁 mở
    endDrawer liệt kê file đã xuất, có nút chia sẻ lại (regenerate từ
    `sourceMessageId`, KHÔNG lưu bytes lâu dài) và xoá khỏi danh sách.
12. **Liên kết đoạn chat** (`Conversation.linkedConversationIds` +
    `linkedContextCache`/`linkedContextCacheVersion`, `ContextManager.
    refreshLinkedContext`, UI: `widgets/link_conversations_sheet.dart`,
    icon 🔗): BẮT BUỘC theo yêu cầu người dùng — không phình token dù đoạn
    chat liên kết dài bao nhiêu. Cơ chế: tái dùng summary có sẵn của đoạn
    chat kia (0 request) → nếu ngắn thì lấy nguyên văn (0 request) → chỉ
    khi dài mà chưa từng tóm tắt mới gọi 1 request tóm tắt ≤100 từ → MỌI
    kết quả bị cắt cứng ≤600 ký tự trước khi cache → cache chỉ tính lại khi
    đoạn chat kia có thêm ≥5 tin nhắn mới (`linkedRefreshThreshold`). Nếu
    sửa lại cơ chế này, PHẢI giữ nguyên tinh thần "chặn trên cố định, không
    tỉ lệ thuận độ dài nguồn" — đây là yêu cầu tường minh của người dùng,
    không phải tối ưu tuỳ chọn.

## 5. Cấu hình API đã xác nhận hoạt động (điền trực tiếp, không cần đoán)

| Provider | Base URL | Format | Ghi chú |
|---|---|---|---|
| Gemini (free tier) | `https://generativelanguage.googleapis.com/v1beta/openai` | openaiCompatible | Giới hạn request/phút chặt ở free tier; dữ liệu free tier có thể bị dùng train trừ khi trả phí |
| DeepSeek chính thức | `https://api.deepseek.com` | openaiCompatible | model: `deepseek-chat` / `deepseek-reasoner`, rẻ |
| Anthropic | chuẩn `/v1/messages` | anthropicCompatible | cần `x-api-key` + header `anthropic-version` |

## 6. Việc CÒN DANG DỞ — làm tiếp từ đây, đúng thứ tự ưu tiên

1. ~~Tạo phần khung Android~~ — **ĐÃ SỬA**: workflow tự chạy
   `flutter create --platforms=android .` trên CI nếu chưa có `android/`.
2. ~~Auto-generate ghi đè code thật bằng app đếm số mẫu~~ — **ĐÃ SỬA**:
   thêm bước backup `lib/`+`pubspec.yaml` ra `/tmp` TRƯỚC khi chạy
   `flutter create`, rồi phục hồi đè lại NGAY SAU — đảm bảo APK build ra
   luôn từ code thật.
3. ~~`file_picker` gây lỗi build (đòi compileSdk 36, project auto-gen ở
   34)~~ — **ĐÃ SỬA**: xoá `file_picker` + `flutter_highlight` khỏi
   `pubspec.yaml` (cả 2 đều KHÔNG được dùng trong code, an toàn khi xoá).
4. ~~`flutter_launcher_icons` gây lỗi Gradle~~ — **ĐÃ SỬA** (build #15
   fail với lỗi `Could not find method kotlin()` trên project `:jni`, do
   dependency `jni` của package này đụng độ với cách Flutter mới build
   Kotlin/KGP): bỏ hẳn package `flutter_launcher_icons`. Thay bằng: tự
   generate sẵn 5 file PNG kích thước chuẩn (mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi)
   ngay trong `assets/icon/mipmap-*/ic_launcher.png` lúc soạn code (không
   sinh trên CI), workflow chỉ COPY file thẳng vào
   `android/app/src/main/res/mipmap-*/` + xoá `mipmap-anydpi-v26` (icon
   adaptive mặc định) — không thêm dependency Dart/Gradle nào nên không
   thể vỡ theo kiểu tương tự. Icon gốc (1024×1024) vẫn giữ ở
   `assets/icon/app_icon.png` để tái sinh size khác nếu cần (dùng PIL/
   ImageMagick, không phải Flutter).
5. ~~Build #16 vẫn ra lỗi `jni` y hệt build #15 dù đã xoá
   `flutter_launcher_icons`~~ — **ĐÃ SỬA**: nguyên nhân là bước tự giải nén
   dùng `cp -rn` (no-clobber) — nếu repo đã có sẵn `pubspec.yaml`/file cũ
   nằm thẳng ở gốc (ví dụ do từng làm theo hướng dẫn cũ "di chuyển file thủ
   công" ở các lượt build đầu tiên), file đó KHÔNG BAO GIỜ bị ghi đè dù zip
   mới có nội dung khác — build luôn dùng nhầm bản pubspec cũ. Đổi sang
   `cp -rf` (force overwrite, zip luôn thắng) + luôn `rm -rf android` trước
   khi `flutter create` lại (không còn kiểu "chỉ tạo nếu chưa có") + thêm
   `cat pubspec.yaml` vào cuối bước giải nén để LOG BUILD hiện rõ nội dung
   pubspec thực sự dùng — nếu lỗi tái diễn, đọc đoạn log này trước tiên
   thay vì đoán tiếp.
6. ~~Build #22 vẫn ra lỗi `jni` y hệt dù đã sửa mục (4) và (5)~~ — **ĐÃ TÌM
   ĐÚNG NGUYÊN NHÂN THẬT**: KHÔNG phải do `flutter_launcher_icons` (bỏ
   package đó ở mục 4 không sai nhưng không phải nguyên nhân chính, chỉ là
   phòng ngừa thêm). Thủ phạm thật là **`share_plus: ^9.0.0`** (bản rất cũ)
   — chính package này áp dụng Kotlin Gradle Plugin theo cách cũ, kéo theo
   dependency `jni` gây lỗi `Could not find method kotlin()`. Manh mối đã
   nằm sẵn trong MỌI log lỗi từ build #9 tới giờ (dòng "WARNING: ... plugins
   that apply Kotlin Gradle Plugin (KGP): share_plus") nhưng bị bỏ qua vì
   tưởng chỉ là warning không quan trọng — bài học: dòng WARNING chỉ đích
   danh tên package luôn đáng đọc kỹ trước khi đoán nguyên nhân khác.
   **ĐÃ SỬA**: nâng `share_plus` lên `^13.0.0` (bản cũ 9.0.0 → mới nhất tại
   thời điểm build #22 là 13.3.0, đã fix compileSdk/Gradle config theo
   chính changelog của package). API `Share.shareXFiles` dùng trong
   `file_saver.dart` vẫn hoạt động ở bản 13.x (deprecated nhưng chưa bị
   xoá) — KHÔNG cần sửa code, chỉ cần bump version trong `pubspec.yaml`.
7. **Trạng thái build hiện tại**: đã sửa xong lỗi (3), (4), (5) và (6),
   người dùng ĐANG chờ kết quả lần chạy tiếp theo sau khi thay file zip mới
   nhất — **CHƯA XÁC NHẬN build thành công**. Việc đầu tiên khi tiếp tục:
   hỏi/kiểm tra log Actions mới nhất trước khi sửa thêm bất cứ gì. Nếu vẫn
   lỗi `jni`/Gradle sau bản sửa này, nghi ngờ tiếp theo nên là các package
   Android khác chưa nâng cấp (`path_provider`, `hive_flutter`) — kiểm tra
   dòng WARNING nêu tên package trước, đừng đoán mò lại từ đầu.
8. **GithubBuildService chưa có màn hình UI** — code service đã xong
   (push file, trigger workflow, poll, đọc log lỗi, nhờ AI tự sửa, lặp tối
   đa N lần, tải artifact). Cần: 1 màn hình nhập PAT/owner/repo + nút chạy +
   hiển thị log tiến trình.
9. **Enhanced docx cho luận văn/tài liệu kỹ thuật** (bìa, mục lục thật,
   header/footer đánh số trang, đánh số chương) — ĐÃ HỨA nhưng CHƯA làm,
   chờ người dùng cho chuẩn định dạng cụ thể trước khi code.

## 7. Bối cảnh vận hành — QUAN TRỌNG, ảnh hưởng cách hỗ trợ tiếp theo

- **Người dùng CHỈ dùng điện thoại, KHÔNG có máy tính** — mọi hướng dẫn
  KHÔNG được yêu cầu chạy lệnh local (Termux là phương án cuối, không phải
  mặc định). Toàn bộ luồng phải làm được qua GitHub web mobile.
- **Luồng deploy hiện tại đã chốt** (đừng đề xuất lại cách khác trừ khi
  luồng này thất bại hẳn):
  1. Tạo file `.github/workflows/build_apk.yml` bằng **"Create new file"**
     trên GitHub mobile (gõ path đầy đủ, dán nội dung — không cần thư mục
     có sẵn).
  2. Upload **1 file `.zip` duy nhất** (không giải nén tay) bằng
     **"Upload files"** — mobile chỉ chọn được file lẻ, không chọn được cả
     cây thư mục, nên đây là cách duy nhất khả thi.
  3. Workflow tự tìm bất kỳ file `*.zip` nào ở gốc repo, tự giải nén, tự bóc
     lớp thư mục `ai_chat_app/` bên trong ra gốc.
  4. Vào Actions → Run workflow → tải APK ở Artifacts khi xong.
- Repo hiện tại của người dùng tên **AgentAIChat**, đã chạy build đến lần
  #9. Lịch sử lỗi đã qua: (a) chỉ upload zip không giải nén → lỗi thiếu
  `lib` → đã có bước tự giải nén; (b) `flutter create` đè code thật thành
  app đếm số mặc định → đã có backup/restore; (c) `file_picker` đòi
  compileSdk 36 → đã xoá dependency.
- Người dùng đã khá bực vì phải thử đi thử lại nhiều lần — **ưu tiên đưa
  giải pháp làm được ngay trên điện thoại, tránh hỏi lại các bước đã xác
  nhận, và xin log thật thay vì đoán khi có lỗi mới.**

## 8. Bẫy/lỗi kỹ thuật đã gặp — TRÁNH LẶP LẠI

- **Hive adapter viết tay**: mỗi lần thêm field mới vào model phải sửa
  ĐỒNG BỘ 2 chỗ — field trong class VÀ `writeByte(N)`/danh sách field đọc
  trong `.g.dart` tương ứng (N = tổng số field, đếm từ 0). Quên 1 trong 2
  chỗ → lỗi runtime hoặc mất dữ liệu khi đọc box cũ. TypeId đã dùng: 1–6
  (MessageRole, ChatMessage, ApiFormat, ProviderConfig, Conversation,
  ChatFolder) — model mới phải dùng `typeId` từ 7 trở lên.
- **Trường "thinking"/"reasoning" không bao giờ được lẫn vào nội dung hiển
  thị**: code parse response CHỈ đọc field `content`/`text`, cố tình bỏ qua
  `reasoning_content`/block type `thinking` — nếu sửa hàm
  `_extractDeltaText`/`_extractFullText` trong `api_service.dart`, phải giữ
  nguyên tính chọn lọc này, không gộp chung.
- **Anthropic format hiện hardcode `max_tokens: 4096`** trong
  `_buildBody` — nếu người dùng cần output dài hơn, đây là chỗ cần sửa
  thành field cấu hình được, chưa làm.
- **Không thể build APK ngay trong môi trường tạo code** (không có Android
  SDK/mạng) — đừng cố "tự build trực tiếp trong chat", luôn cần 1 trong 2:
  build tay bằng Flutter SDK, hoặc CI qua `.github/workflows/build_apk.yml`
  (đã có sẵn trong project) hoặc `GithubBuildService`.
- **Đã xoá `file_picker`, `flutter_highlight`** khỏi `pubspec.yaml` (không
  dùng trong code + `file_picker` gây lỗi compileSdk) — ĐỪNG thêm lại
  `file_picker` mà không đồng thời set `compileSdk`/`targetSdk` phù hợp
  trong `android/app/build.gradle.kts` sau khi `flutter create` sinh ra.
- **`flutter create` có thể ghi đè `lib/`+`pubspec.yaml` bằng app mẫu** nếu
  không backup/restore trước — xem cơ chế đã vá ở mục 6.2, đừng bỏ 2 bước
  đó nếu sửa lại workflow.

- **Đã đổi `name:` trong `pubspec.yaml` từ `ai_chat_app` → `agent_ai_chat`**
  (Dart package name, snake_case) — đã đồng bộ với `--project-name
  agent_ai_chat` trong CI. Nếu sửa 1 trong 2 chỗ mà quên chỗ kia, project
  name lệch nhau có thể gây lỗi khi `flutter create` sinh `android/`. Toàn
  bộ code trong `lib/` dùng import tương đối (không dùng `package:
  agent_ai_chat/...`) nên đổi tên này KHÔNG ảnh hưởng gì tới import — an
  toàn để đổi tiếp nếu cần.
- **Icon** sinh bằng `flutter_launcher_icons` đọc từ
  `assets/icon/app_icon.png` — nếu đổi icon, chỉ cần thay file PNG này
  (giữ tỉ lệ vuông, khuyến nghị ≥512×512), không cần sửa gì khác.

## 9. File đã gửi cho người dùng

`ai_chat_app_source.zip` — toàn bộ `lib/` + `pubspec.yaml` (đã xoá
file_picker/flutter_highlight) + README + `.github/workflows/build_apk.yml`
(đã có đủ: tự giải nén zip, backup/restore code thật, tự sinh `android/`,
tự thêm quyền Internet). CHƯA có `android/`, `ios/` thật trong zip — do CI
tự sinh lúc build, KHÔNG cần thêm vào zip.

## 10. Cập nhật 29/07/2026 — Thư ký AI + Tài liệu nguồn + Sửa source code zip

**Bối cảnh:** người dùng cần (a) đăng nhập vào hệ thống web công ty ngay
trong app để lấy nội dung thay vì tự copy/export thủ công, (b) tổng hợp
nhiều tài liệu thành docx/pptx/xlsx theo yêu cầu, (c) upload 1 zip source
code bất kỳ để AI sửa và trả lại zip hoàn chỉnh — và MUỐN TIẾT KIỆM TOKEN
(không gọi API cho bước không cần thiết).

**KHÔNG làm** (và tại sao): tự động đăng nhập + đọc tin nhắn riêng tư của
người khác từ Facebook/Zalo/Messenger. Các nền tảng này chủ động chặn việc
đọc nội dung qua WebView (CSP, phát hiện script lạ) và việc này có thể làm
khoá tài khoản thật của người dùng; hơn nữa tin nhắn liên quan đến người
khác vẫn cần họ đồng ý mới nên tự động hoá trích xuất/lưu trữ ngoài ý muốn
của họ. Nếu người dùng thật sự cần dữ liệu Facebook/Zalo, hướng dẫn dùng
tính năng "Tải xuống thông tin của bạn" chính chủ của nền tảng đó, rồi
upload file kết quả vào mục 10.2 bên dưới.

### 10.1. lib/screens/sources/webview_capture_screen.dart (MỚI)
Trình duyệt nhúng (webview_flutter) để đăng nhập BẤT KỲ hệ thống web nào
(web nội bộ công ty, ...) bằng chính phiên đăng nhập thật của người dùng.
Nút "Trích xuất nội dung trang" chạy document.body.innerText — thuần JS,
KHÔNG gọi API model, không tốn token ở bước này.

### 10.2. lib/models/source_document.dart (+ .g.dart, typeId 8, MỚI)
Lưu tài liệu nguồn (origin = 'upload' | 'webview') vào box Hive mới
source_documents (đăng ký trong storage_service.dart).

### 10.3. lib/screens/sources/source_documents_screen.dart (MỚI)
Danh sách tài liệu nguồn, upload file (txt/md/csv/json/...), mở webview
capture, chọn nhiều tài liệu, bottom sheet nhập yêu cầu + chọn định dạng,
gọi ChatProvider.compileSources (secretary_prompt_builder.dart dựng prompt)
- ĐÚNG 1 LẦN GỌI API (sendMessageOnce, không streaming) cho toàn bộ việc
tổng hợp, bất kể có bao nhiêu tài liệu nguồn. Kết quả được thêm vào đoạn
chat như 1 cặp tin nhắn user/assistant bình thường (minh bạch token đã
dùng) rồi tái dùng ExportRunner có sẵn để xuất docx/pptx/xlsx.

### 10.4. lib/screens/code/zip_edit_screen.dart (MỚI)
Upload 1 file .zip bất kỳ, giải nén bằng ZipDecoder (đã có sẵn qua archive),
lọc file text (bỏ qua file nhị phân), người dùng tick chọn file cần AI xem,
1 LẦN GỌI API yêu cầu AI CHỈ trả về các file thay đổi/thêm mới theo đúng cú
pháp CodeZipExporter đã hỗ trợ, merge với file gốc không đổi, xuất zip hoàn
chỉnh bằng CodeZipExporter.export (tái dùng, không viết exporter mới).

### 10.5. Đã THÊM LẠI file_picker (khác lần trước!)
Lần này có kèm bước ép compileSdk/targetSdk = 36 trong
.github/workflows/build_apk.yml (bước "Ép compileSdk/targetSdk = 36" ngay
sau khi sinh android/) - đúng điều kiện mà mục 8 ở trên yêu cầu. Nếu build
CI vẫn lỗi liên quan compileSdk/AGP/Kotlin, kiểm tra log ở đúng bước này
trước - có thể cần đổi số 36 sang version SDK khác tuỳ bản file_picker/
Flutter tại thời điểm build (không kiểm chứng được bằng cách build thật
trong môi trường tạo code, vì môi trường đó không có mạng/Android SDK).

### 10.6. CHƯA làm (còn nợ, người dùng chưa xác nhận ưu tiên)
"Chat nhóm nội bộ" nhiều người dùng thật cùng vào 1 đoạn chat trong chính
app (không phải nhiều AI model thảo luận - cái đó đã có qua
discussionProviderIds) - cần thêm 1 lớp đồng bộ dữ liệu giữa các thiết bị
(hiện app 100% local Hive, không có backend), nên đây là thay đổi kiến trúc
lớn, chưa làm vội để tránh phá vỡ nguyên tắc "không cần backend" của app.

## 11. Cập nhật 29/07/2026 (bổ sung) — Tải file thật qua link download trong WebView

Bổ sung cho mục 10.1: trước đây `webview_capture_screen.dart` chỉ trích
xuất được TEXT hiển thị trên trang (`document.body.innerText`) — không lấy
được nếu code/tài liệu nằm trong 1 FILE THẬT (zip/docx/pdf...) mà trang chỉ
cho bấm link tải xuống, vì WebView (giống Chrome/Safari) không tự tải file
đính kèm.

**Đã thêm:** `onNavigationRequest` chặn các URL có đuôi file
(zip/rar/7z/docx/pdf/xlsx/pptx/csv/...) trước khi WebView load, rồi tự tải
bằng `http` GET kèm cookie phiên đăng nhập THẬT lấy qua package
`webview_cookie_manager` (đọc CookieManager gốc của Android/iOS — khác
`document.cookie` trong JS vì đọc được cả cookie đánh dấu HttpOnly, mà
cookie session/đăng nhập thường bị đánh dấu HttpOnly vì lý do bảo mật).

- Nếu file tải về là `.zip` → tự động mở luôn màn `ZipEditScreen` (đã sửa
  để nhận `initialBytes`/`initialName`), không cần chọn lại file lần 2.
- Nếu là `.txt/.md/.csv/.json/.html/.xml/.log` → lưu thẳng thành
  `SourceDocument` (giống upload file thường).
- Nếu là `.docx/.pdf/.xlsx/.pptx/.doc/.ppt/.xls` → ĐÃ TẢI ĐƯỢC FILE nhưng
  CHƯA đọc được nội dung text bên trong (đây là định dạng nhị phân có cấu
  trúc riêng, cần parser riêng cho từng loại — chưa làm, báo nếu cần).

**CHƯA kiểm chứng được bằng build thật** (môi trường tạo code không có
mạng/Android SDK) — 2 điểm rủi ro cao nhất cần xem log CI đầu tiên nếu lỗi:
1. API chính xác của `webview_cookie_manager` (`getCookies(url)` trả về
   `List<Cookie>` từ `dart:io`) có thể lệch nhẹ theo version — nếu lỗi biên
   dịch ở đây, kiểm tra README của package trên pub.dev đúng version đã ghim
   trong `pubspec.yaml`.
2. `onNavigationRequest` trả `NavigationDecision` đồng bộ (không `Future`) —
   nếu SDK version yêu cầu `FutureOr<NavigationDecision>`, có thể cần bọc
   `async` (không đổi tôi hành vi vì `_downloadFile` tự chạy async bên trong,
   không cần `await` trước khi return `NavigationDecision.prevent`).

## 12. FIX build lỗi #28 (29/07/2026) — sai version webview_cookie_manager

**Lỗi thật đã xảy ra:** `webview_cookie_manager ^3.0.1 doesn't match any versions`
- Nguyên nhân: tôi ghim version `^3.0.1` cho package này mà KHÔNG kiểm chứng
  được (môi trường code không có mạng để tra pub.dev), và con số đó sai —
  package không có bản 3.x.

**Đã sửa:** đổi 3 dependency mới thêm (mục 10-11) từ ghim đúng patch version
sang RANGE rộng hơn, để `pub get` tự chọn bản thực sự tồn tại thay vì lỗi
version-solving nếu tôi đoán sai số:
- `webview_cookie_manager: ">=1.0.0 <4.0.0"`
- `webview_flutter: ">=4.7.0 <5.0.0"`
- `file_picker: ">=8.0.0 <10.0.0"`

Nếu build vẫn báo lỗi version-solving ở 1 trong 3 dòng này, nghĩa là ngay
cả range trên cũng không khớp bản thật đang có trên pub.dev tại thời điểm
build — mở log, đọc chính xác thông báo "version solving failed" (nó luôn
liệt kê constraint đang xung đột), rồi báo lại cho tôi đúng tên package +
thông báo lỗi để tôi sửa đúng con số.
