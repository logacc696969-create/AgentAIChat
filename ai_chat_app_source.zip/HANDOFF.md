# HANDOFF: AI Chat App (Flutter) — Trạng thái & tiếp tục từ đây

> Đọc file này thay vì đọc lại hội thoại gốc. Mục tiêu: build app Android
> hoàn chỉnh từ source đã có, KHÔNG lặp lại các quyết định/lỗi bên dưới.

## 1. Mục tiêu sản phẩm (yêu cầu gốc của người dùng)

- Tên app: **AgentAiChat** (đổi từ "ai_chat_app" theo yêu cầu), icon riêng
  đã tạo (`assets/icon/app_icon.png`, tự sinh mọi size qua
  `flutter_launcher_icons` trên CI).
- App chat AI kiểu Claude/ChatGPT, gọi **API model bất kỳ do người dùng tự
  cấu hình** — **tuyệt đối không hardcode hãng/model nào**.
- Quản lý nhiều đoạn chat như app chat khác: folder, ghim, đổi tên, xóa.
- **Ưu tiên #1 xuyên suốt dự án: tối ưu token khi chat dài/phức tạp.**
- Xuất file từ câu trả lời AI: docx, pptx, xlsx, zip source code (để push
  GitHub build).
- Chuyển model giữa chừng 1 đoạn chat, tiếp tục mạch, **không đốt token**
  để "giải thích lại ngữ cảnh".
- **Thảo luận nhóm nhiều model**: chọn ≥2 provider cùng tham gia 1 đoạn
  chat, mỗi model lần lượt trả lời, thấy được ý kiến model nói trước (xem
  mục 4.8).
- (Đề xuất, chưa hoàn thiện) Tự động build APK qua GitHub Actions, tự đọc
  lỗi và tự sửa bằng AI.

## 2. Stack & lý do chọn

| Quyết định | Lý do |
|---|---|
| Flutter | 1 codebase → APK, CI build dễ nhất qua GitHub Actions |
| Hive (không phải sqflite) | NoSQL nhẹ, không cần server, đủ cho local storage |
| `provider` package | State management đơn giản, đủ dùng |
| `archive` package tự dựng XML | docx/pptx/xlsx đều là zip+XML — tự viết để tránh phụ thuộc thư viện Office nặng/trả phí |
| Hive adapters **viết tay**, KHÔNG dùng `build_runner` | Môi trường dev lúc viết code không có mạng để chạy codegen — đã viết `.g.dart` thủ công khớp 100% với model |

## 3. Kiến trúc thư mục (đã code xong, nằm trong `ai_chat_app_source.zip` đã gửi)

```
lib/
  models/         ChatMessage, Conversation, ChatFolder, ProviderConfig (+ .g.dart tay)
  services/
    api_service.dart        gọi API 3 định dạng: openaiCompatible / anthropicCompatible / custom
    context_manager.dart     LÕI tối ưu token (xem mục 4)
    token_estimator.dart     ước lượng token (không có tokenizer thật vì đa hãng)
    usage_service.dart       lưu token THẬT (từ field usage của API) theo ngày/provider
    storage_service.dart     Hive boxes
    github_build_service.dart  auto-build qua GitHub API (CHƯA có UI, xem mục 6)
    export/{docx,pptx,xlsx,code_zip}_export.dart
  providers/chat_provider.dart   ChangeNotifier trung tâm, nối tất cả service trên
  screens/  chat/ home/ settings/(provider_settings, provider_edit, usage_stats)
  widgets/  message_bubble, chat_input_bar, token_usage_bar, export_menu
```

## 4. Cơ chế tối ưu token (đã implement, ĐỪNG thiết kế lại từ đầu)

1. **Sliding window** 12 tin nhắn gần nhất giữ nguyên văn.
2. **Auto-summarize**: khi tổng token ước tính > 65% `maxContextTokens` của
   provider đang dùng → gọi chính model đó tóm tắt phần cũ, thay thế lịch sử
   gốc bằng bản tóm tắt (message có `isSummary=true`; message gốc đánh dấu
   `collapsedIntoSummary=true`, vẫn hiển thị UI nhưng không gửi API nữa).
3. **Incremental summary**: tóm tắt lần sau = tóm tắt cũ + tin mới, không
   tóm tắt lại từ đầu.
4. Safety margin 15% — không bao giờ build context sát giới hạn.
5. **Usage THẬT từ API** (`ApiUsage` parse từ field `usage` trong response,
   kể cả streaming qua `stream_options.include_usage`/Anthropic
   `message_delta`) ghi đè lên số ước lượng ngay khi có, để các quyết định
   sau chính xác hơn.
6. **Chuyển model giữa chừng** (`ContextManager.switchModel`): chèn 1
   message `isSystemNote=true` (không tính token, không gửi API) đánh dấu
   mốc chuyển; nếu model mới có `maxContextTokens` ≥ model cũ → **tái dùng
   nguyên bản tóm tắt cũ, KHÔNG gọi thêm request tóm tắt nào**; chỉ tóm tắt
   nén thêm khi model mới có ngữ cảnh nhỏ hơn hẳn.
7. **Thinking/reasoning_effort** (field `reasoningEffort` trên
   ProviderConfig): map sang `reasoning_effort` (OpenAI-compat/Gemini) hoặc
   `thinking.budget_tokens` (Anthropic: low=2000/medium=8000/high=16000).
   Bật cao hơn tốn thêm completion token — đánh đổi có chủ đích, không phải
   bug.
8. **Thảo luận nhóm nhiều model** (`Conversation.discussionProviderIds`,
   `ChatMessage.speakerProviderId/speakerName`, `ChatProvider.
   sendDiscussionMessage`): mỗi model trong danh sách lần lượt trả lời 1
   câu hỏi, context của model sau có prefix `[Tên model]: ` trên các tin
   nhắn assistant trước đó (xử lý trong `ContextManager.buildContext`) để
   nó hiểu đó là phát biểu của model KHÁC, không phải lượt trả lời cũ của
   chính nó. Token vẫn tối ưu riêng theo `maxContextTokens` của TỪNG model
   tham gia — không dùng chung 1 ngân sách.
9. **Override riêng theo từng đoạn chat** (`Conversation.
   reasoningEffortOverride`/`temperatureOverride`/`webSearchOverride`,
   `ChatProvider._effectiveProvider`/`setChatOverrides`, UI:
   `chat_quick_settings_sheet.dart`, icon ⚙️ trên chat_screen):
   Thinking/Temperature/System prompt/Web search giờ đổi được NGAY TRONG
   LÚC CHAT, riêng cho từng đoạn chat, không cần vào lại Cài đặt Provider —
   khắc phục hạn chế "cài đặt chết" mà người dùng phản ánh. `temperature`
   cũng đã có UI (slider) ở màn hình sửa Provider — trước đó field có
   trong model nhưng bị thiếu UI, đã bổ sung.
10. **Tìm kiếm web** (`ProviderConfig.webSearchEnabled`,
    `Conversation.webSearchOverride`, xử lý trong `api_service.dart
    _buildBody`): Anthropic dùng tool chính thức `web_search_20250305`
    (ổn định, có tài liệu). OpenAI-compatible/Custom gửi
    `web_search_options: {}` — CHỈ có tác dụng thật với model dòng search
    của OpenAI (gpt-4o-search-preview, gpt-5-search-api); với Gemini qua
    endpoint OpenAI-compat, tài liệu Google hiện KHÔNG xác nhận field
    tương đương cho chat/completions (chỉ thấy cho ảnh/video) — đã tra
    cứu kỹ, không đoán mò, ghi rõ mức độ tin cậy khác nhau theo từng
    provider trong cả README lẫn UI. Không phải scraping/browser — chỉ là
    bật đúng field API.
11. **Panel "File đã tạo"** (`models/generated_file.dart` typeId=7,
    `Conversation.generatedFiles`, `widgets/generated_files_panel.dart`,
    `widgets/export_runner.dart` — logic xuất file dùng chung, tách khỏi
    `export_menu.dart` để panel "xuất lại" gọi lại được y hệt): icon 📁 mở
    endDrawer liệt kê file đã xuất, có nút chia sẻ lại (regenerate từ
    `sourceMessageId`, KHÔNG lưu bytes lâu dài) và xoá khỏi danh sách.
12. **Liên kết đoạn chat** (`Conversation.linkedConversationIds` +
    `linkedContextCache`/`linkedContextCacheVersion`, `ContextManager.
    refreshLinkedContext`, UI: `widgets/link_conversations_sheet.dart`,
    icon 🔗): BẮT BUỘC theo yêu cầu người dùng — không phình token dù đoạn
    chat liên kết dài bao nhiêu. Cơ chế: tái dùng summary có sẵn của đoạn
    chat kia (0 request) → nếu ngắn thì lấy nguyên văn (0 request) → chỉ
    khi dài mà chưa từng tóm tắt mới gọi 1 request tóm tắt ≤100 từ → MỌI
    kết quả bị cắt cứng ≤600 ký tự trước khi cache → cache chỉ tính lại khi
    đoạn chat kia có thêm ≥5 tin nhắn mới (`linkedRefreshThreshold`). Nếu
    sửa lại cơ chế này, PHẢI giữ nguyên tinh thần "chặn trên cố định, không
    tỉ lệ thuận độ dài nguồn" — đây là yêu cầu tường minh của người dùng,
    không phải tối ưu tuỳ chọn.

## 5. Cấu hình API đã xác nhận hoạt động (điền trực tiếp, không cần đoán)

| Provider | Base URL | Format | Ghi chú |
|---|---|---|---|
| Gemini (free tier) | `https://generativelanguage.googleapis.com/v1beta/openai` | openaiCompatible | Giới hạn request/phút chặt ở free tier; dữ liệu free tier có thể bị dùng train trừ khi trả phí |
| DeepSeek chính thức | `https://api.deepseek.com` | openaiCompatible | model: `deepseek-chat` / `deepseek-reasoner`, rẻ |
| Anthropic | chuẩn `/v1/messages` | anthropicCompatible | cần `x-api-key` + header `anthropic-version` |

## 6. Việc CÒN DANG DỞ — làm tiếp từ đây, đúng thứ tự ưu tiên

1. ~~Tạo phần khung Android~~ — **ĐÃ SỬA**: workflow tự chạy
   `flutter create --platforms=android .` trên CI nếu chưa có `android/`.
2. ~~Auto-generate ghi đè code thật bằng app đếm số mẫu~~ — **ĐÃ SỬA**:
   thêm bước backup `lib/`+`pubspec.yaml` ra `/tmp` TRƯỚC khi chạy
   `flutter create`, rồi phục hồi đè lại NGAY SAU — đảm bảo APK build ra
   luôn từ code thật.
3. ~~`file_picker` gây lỗi build (đòi compileSdk 36, project auto-gen ở
   34)~~ — **ĐÃ SỬA**: xoá `file_picker` + `flutter_highlight` khỏi
   `pubspec.yaml` (cả 2 đều KHÔNG được dùng trong code, an toàn khi xoá).
4. ~~`flutter_launcher_icons` gây lỗi Gradle~~ — **ĐÃ SỬA** (build #15
   fail với lỗi `Could not find method kotlin()` trên project `:jni`, do
   dependency `jni` của package này đụng độ với cách Flutter mới build
   Kotlin/KGP): bỏ hẳn package `flutter_launcher_icons`. Thay bằng: tự
   generate sẵn 5 file PNG kích thước chuẩn (mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi)
   ngay trong `assets/icon/mipmap-*/ic_launcher.png` lúc soạn code (không
   sinh trên CI), workflow chỉ COPY file thẳng vào
   `android/app/src/main/res/mipmap-*/` + xoá `mipmap-anydpi-v26` (icon
   adaptive mặc định) — không thêm dependency Dart/Gradle nào nên không
   thể vỡ theo kiểu tương tự. Icon gốc (1024×1024) vẫn giữ ở
   `assets/icon/app_icon.png` để tái sinh size khác nếu cần (dùng PIL/
   ImageMagick, không phải Flutter).
5. ~~Build #16 vẫn ra lỗi `jni` y hệt build #15 dù đã xoá
   `flutter_launcher_icons`~~ — **ĐÃ SỬA**: nguyên nhân là bước tự giải nén
   dùng `cp -rn` (no-clobber) — nếu repo đã có sẵn `pubspec.yaml`/file cũ
   nằm thẳng ở gốc (ví dụ do từng làm theo hướng dẫn cũ "di chuyển file thủ
   công" ở các lượt build đầu tiên), file đó KHÔNG BAO GIỜ bị ghi đè dù zip
   mới có nội dung khác — build luôn dùng nhầm bản pubspec cũ. Đổi sang
   `cp -rf` (force overwrite, zip luôn thắng) + luôn `rm -rf android` trước
   khi `flutter create` lại (không còn kiểu "chỉ tạo nếu chưa có") + thêm
   `cat pubspec.yaml` vào cuối bước giải nén để LOG BUILD hiện rõ nội dung
   pubspec thực sự dùng — nếu lỗi tái diễn, đọc đoạn log này trước tiên
   thay vì đoán tiếp.
6. ~~Build #22 vẫn ra lỗi `jni` y hệt dù đã sửa mục (4) và (5)~~ — **ĐÃ TÌM
   ĐÚNG NGUYÊN NHÂN THẬT**: KHÔNG phải do `flutter_launcher_icons` (bỏ
   package đó ở mục 4 không sai nhưng không phải nguyên nhân chính, chỉ là
   phòng ngừa thêm). Thủ phạm thật là **`share_plus: ^9.0.0`** (bản rất cũ)
   — chính package này áp dụng Kotlin Gradle Plugin theo cách cũ, kéo theo
   dependency `jni` gây lỗi `Could not find method kotlin()`. Manh mối đã
   nằm sẵn trong MỌI log lỗi từ build #9 tới giờ (dòng "WARNING: ... plugins
   that apply Kotlin Gradle Plugin (KGP): share_plus") nhưng bị bỏ qua vì
   tưởng chỉ là warning không quan trọng — bài học: dòng WARNING chỉ đích
   danh tên package luôn đáng đọc kỹ trước khi đoán nguyên nhân khác.
   **ĐÃ SỬA**: nâng `share_plus` lên `^13.0.0` (bản cũ 9.0.0 → mới nhất tại
   thời điểm build #22 là 13.3.0, đã fix compileSdk/Gradle config theo
   chính changelog của package). API `Share.shareXFiles` dùng trong
   `file_saver.dart` vẫn hoạt động ở bản 13.x (deprecated nhưng chưa bị
   xoá) — KHÔNG cần sửa code, chỉ cần bump version trong `pubspec.yaml`.
7. **Trạng thái build hiện tại**: đã sửa xong lỗi (3), (4), (5) và (6),
   người dùng ĐANG chờ kết quả lần chạy tiếp theo sau khi thay file zip mới
   nhất — **CHƯA XÁC NHẬN build thành công**. Việc đầu tiên khi tiếp tục:
   hỏi/kiểm tra log Actions mới nhất trước khi sửa thêm bất cứ gì. Nếu vẫn
   lỗi `jni`/Gradle sau bản sửa này, nghi ngờ tiếp theo nên là các package
   Android khác chưa nâng cấp (`path_provider`, `hive_flutter`) — kiểm tra
   dòng WARNING nêu tên package trước, đừng đoán mò lại từ đầu.
8. **GithubBuildService chưa có màn hình UI** — code service đã xong
   (push file, trigger workflow, poll, đọc log lỗi, nhờ AI tự sửa, lặp tối
   đa N lần, tải artifact). Cần: 1 màn hình nhập PAT/owner/repo + nút chạy +
   hiển thị log tiến trình.
9. **Enhanced docx cho luận văn/tài liệu kỹ thuật** (bìa, mục lục thật,
   header/footer đánh số trang, đánh số chương) — ĐÃ HỨA nhưng CHƯA làm,
   chờ người dùng cho chuẩn định dạng cụ thể trước khi code.

## 7. Bối cảnh vận hành — QUAN TRỌNG, ảnh hưởng cách hỗ trợ tiếp theo

- **Người dùng CHỈ dùng điện thoại, KHÔNG có máy tính** — mọi hướng dẫn
  KHÔNG được yêu cầu chạy lệnh local (Termux là phương án cuối, không phải
  mặc định). Toàn bộ luồng phải làm được qua GitHub web mobile.
- **Luồng deploy hiện tại đã chốt** (đừng đề xuất lại cách khác trừ khi
  luồng này thất bại hẳn):
  1. Tạo file `.github/workflows/build_apk.yml` bằng **"Create new file"**
     trên GitHub mobile (gõ path đầy đủ, dán nội dung — không cần thư mục
     có sẵn).
  2. Upload **1 file `.zip` duy nhất** (không giải nén tay) bằng
     **"Upload files"** — mobile chỉ chọn được file lẻ, không chọn được cả
     cây thư mục, nên đây là cách duy nhất khả thi.
  3. Workflow tự tìm bất kỳ file `*.zip` nào ở gốc repo, tự giải nén, tự bóc
     lớp thư mục `ai_chat_app/` bên trong ra gốc.
  4. Vào Actions → Run workflow → tải APK ở Artifacts khi xong.
- Repo hiện tại của người dùng tên **AgentAIChat**, đã chạy build đến lần
  #9. Lịch sử lỗi đã qua: (a) chỉ upload zip không giải nén → lỗi thiếu
  `lib` → đã có bước tự giải nén; (b) `flutter create` đè code thật thành
  app đếm số mặc định → đã có backup/restore; (c) `file_picker` đòi
  compileSdk 36 → đã xoá dependency.
- Người dùng đã khá bực vì phải thử đi thử lại nhiều lần — **ưu tiên đưa
  giải pháp làm được ngay trên điện thoại, tránh hỏi lại các bước đã xác
  nhận, và xin log thật thay vì đoán khi có lỗi mới.**

## 8. Bẫy/lỗi kỹ thuật đã gặp — TRÁNH LẶP LẠI

- **Hive adapter viết tay**: mỗi lần thêm field mới vào model phải sửa
  ĐỒNG BỘ 2 chỗ — field trong class VÀ `writeByte(N)`/danh sách field đọc
  trong `.g.dart` tương ứng (N = tổng số field, đếm từ 0). Quên 1 trong 2
  chỗ → lỗi runtime hoặc mất dữ liệu khi đọc box cũ. TypeId đã dùng: 1–6
  (MessageRole, ChatMessage, ApiFormat, ProviderConfig, Conversation,
  ChatFolder) — model mới phải dùng `typeId` từ 7 trở lên.
- **Trường "thinking"/"reasoning" không bao giờ được lẫn vào nội dung hiển
  thị**: code parse response CHỈ đọc field `content`/`text`, cố tình bỏ qua
  `reasoning_content`/block type `thinking` — nếu sửa hàm
  `_extractDeltaText`/`_extractFullText` trong `api_service.dart`, phải giữ
  nguyên tính chọn lọc này, không gộp chung.
- **Anthropic format hiện hardcode `max_tokens: 4096`** trong
  `_buildBody` — nếu người dùng cần output dài hơn, đây là chỗ cần sửa
  thành field cấu hình được, chưa làm.
- **Không thể build APK ngay trong môi trường tạo code** (không có Android
  SDK/mạng) — đừng cố "tự build trực tiếp trong chat", luôn cần 1 trong 2:
  build tay bằng Flutter SDK, hoặc CI qua `.github/workflows/build_apk.yml`
  (đã có sẵn trong project) hoặc `GithubBuildService`.
- **Đã xoá `file_picker`, `flutter_highlight`** khỏi `pubspec.yaml` (không
  dùng trong code + `file_picker` gây lỗi compileSdk) — ĐỪNG thêm lại
  `file_picker` mà không đồng thời set `compileSdk`/`targetSdk` phù hợp
  trong `android/app/build.gradle.kts` sau khi `flutter create` sinh ra.
- **`flutter create` có thể ghi đè `lib/`+`pubspec.yaml` bằng app mẫu** nếu
  không backup/restore trước — xem cơ chế đã vá ở mục 6.2, đừng bỏ 2 bước
  đó nếu sửa lại workflow.

- **Đã đổi `name:` trong `pubspec.yaml` từ `ai_chat_app` → `agent_ai_chat`**
  (Dart package name, snake_case) — đã đồng bộ với `--project-name
  agent_ai_chat` trong CI. Nếu sửa 1 trong 2 chỗ mà quên chỗ kia, project
  name lệch nhau có thể gây lỗi khi `flutter create` sinh `android/`. Toàn
  bộ code trong `lib/` dùng import tương đối (không dùng `package:
  agent_ai_chat/...`) nên đổi tên này KHÔNG ảnh hưởng gì tới import — an
  toàn để đổi tiếp nếu cần.
- **Icon** sinh bằng `flutter_launcher_icons` đọc từ
  `assets/icon/app_icon.png` — nếu đổi icon, chỉ cần thay file PNG này
  (giữ tỉ lệ vuông, khuyến nghị ≥512×512), không cần sửa gì khác.

## 9. File đã gửi cho người dùng

`ai_chat_app_source.zip` — toàn bộ `lib/` + `pubspec.yaml` (đã xoá
file_picker/flutter_highlight) + README + `.github/workflows/build_apk.yml`
(đã có đủ: tự giải nén zip, backup/restore code thật, tự sinh `android/`,
tự thêm quyền Internet). CHƯA có `android/`, `ios/` thật trong zip — do CI
tự sinh lúc build, KHÔNG cần thêm vào zip.

## 10. Cập nhật 29/07/2026 — Thư ký AI + Tài liệu nguồn + Sửa source code zip

**Bối cảnh:** người dùng cần (a) đăng nhập vào hệ thống web công ty ngay
trong app để lấy nội dung thay vì tự copy/export thủ công, (b) tổng hợp
nhiều tài liệu thành docx/pptx/xlsx theo yêu cầu, (c) upload 1 zip source
code bất kỳ để AI sửa và trả lại zip hoàn chỉnh — và MUỐN TIẾT KIỆM TOKEN
(không gọi API cho bước không cần thiết).

**KHÔNG làm** (và tại sao): tự động đăng nhập + đọc tin nhắn riêng tư của
người khác từ Facebook/Zalo/Messenger. Các nền tảng này chủ động chặn việc
đọc nội dung qua WebView (CSP, phát hiện script lạ) và việc này có thể làm
khoá tài khoản thật của người dùng; hơn nữa tin nhắn liên quan đến người
khác vẫn cần họ đồng ý mới nên tự động hoá trích xuất/lưu trữ ngoài ý muốn
của họ. Nếu người dùng thật sự cần dữ liệu Facebook/Zalo, hướng dẫn dùng
tính năng "Tải xuống thông tin của bạn" chính chủ của nền tảng đó, rồi
upload file kết quả vào mục 10.2 bên dưới.

### 10.1. lib/screens/sources/webview_capture_screen.dart (MỚI)
Trình duyệt nhúng (webview_flutter) để đăng nhập BẤT KỲ hệ thống web nào
(web nội bộ công ty, ...) bằng chính phiên đăng nhập thật của người dùng.
Nút "Trích xuất nội dung trang" chạy document.body.innerText — thuần JS,
KHÔNG gọi API model, không tốn token ở bước này.

### 10.2. lib/models/source_document.dart (+ .g.dart, typeId 8, MỚI)
Lưu tài liệu nguồn (origin = 'upload' | 'webview') vào box Hive mới
source_documents (đăng ký trong storage_service.dart).

### 10.3. lib/screens/sources/source_documents_screen.dart (MỚI)
Danh sách tài liệu nguồn, upload file (txt/md/csv/json/...), mở webview
capture, chọn nhiều tài liệu, bottom sheet nhập yêu cầu + chọn định dạng,
gọi ChatProvider.compileSources (secretary_prompt_builder.dart dựng prompt)
- ĐÚNG 1 LẦN GỌI API (sendMessageOnce, không streaming) cho toàn bộ việc
tổng hợp, bất kể có bao nhiêu tài liệu nguồn. Kết quả được thêm vào đoạn
chat như 1 cặp tin nhắn user/assistant bình thường (minh bạch token đã
dùng) rồi tái dùng ExportRunner có sẵn để xuất docx/pptx/xlsx.

### 10.4. lib/screens/code/zip_edit_screen.dart (MỚI)
Upload 1 file .zip bất kỳ, giải nén bằng ZipDecoder (đã có sẵn qua archive),
lọc file text (bỏ qua file nhị phân), người dùng tick chọn file cần AI xem,
1 LẦN GỌI API yêu cầu AI CHỈ trả về các file thay đổi/thêm mới theo đúng cú
pháp CodeZipExporter đã hỗ trợ, merge với file gốc không đổi, xuất zip hoàn
chỉnh bằng CodeZipExporter.export (tái dùng, không viết exporter mới).

### 10.5. Đã THÊM LẠI file_picker (khác lần trước!)
Lần này có kèm bước ép compileSdk/targetSdk = 36 trong
.github/workflows/build_apk.yml (bước "Ép compileSdk/targetSdk = 36" ngay
sau khi sinh android/) - đúng điều kiện mà mục 8 ở trên yêu cầu. Nếu build
CI vẫn lỗi liên quan compileSdk/AGP/Kotlin, kiểm tra log ở đúng bước này
trước - có thể cần đổi số 36 sang version SDK khác tuỳ bản file_picker/
Flutter tại thời điểm build (không kiểm chứng được bằng cách build thật
trong môi trường tạo code, vì môi trường đó không có mạng/Android SDK).

### 10.6. CHƯA làm (còn nợ, người dùng chưa xác nhận ưu tiên)
"Chat nhóm nội bộ" nhiều người dùng thật cùng vào 1 đoạn chat trong chính
app (không phải nhiều AI model thảo luận - cái đó đã có qua
discussionProviderIds) - cần thêm 1 lớp đồng bộ dữ liệu giữa các thiết bị
(hiện app 100% local Hive, không có backend), nên đây là thay đổi kiến trúc
lớn, chưa làm vội để tránh phá vỡ nguyên tắc "không cần backend" của app.

## 11. Cập nhật 29/07/2026 (bổ sung) — Tải file thật qua link download trong WebView

Bổ sung cho mục 10.1: trước đây `webview_capture_screen.dart` chỉ trích
xuất được TEXT hiển thị trên trang (`document.body.innerText`) — không lấy
được nếu code/tài liệu nằm trong 1 FILE THẬT (zip/docx/pdf...) mà trang chỉ
cho bấm link tải xuống, vì WebView (giống Chrome/Safari) không tự tải file
đính kèm.

**Đã thêm:** `onNavigationRequest` chặn các URL có đuôi file
(zip/rar/7z/docx/pdf/xlsx/pptx/csv/...) trước khi WebView load, rồi tự tải
bằng `http` GET kèm cookie phiên đăng nhập THẬT lấy qua package
`webview_cookie_manager` (đọc CookieManager gốc của Android/iOS — khác
`document.cookie` trong JS vì đọc được cả cookie đánh dấu HttpOnly, mà
cookie session/đăng nhập thường bị đánh dấu HttpOnly vì lý do bảo mật).

- Nếu file tải về là `.zip` → tự động mở luôn màn `ZipEditScreen` (đã sửa
  để nhận `initialBytes`/`initialName`), không cần chọn lại file lần 2.
- Nếu là `.txt/.md/.csv/.json/.html/.xml/.log` → lưu thẳng thành
  `SourceDocument` (giống upload file thường).
- Nếu là `.docx/.pdf/.xlsx/.pptx/.doc/.ppt/.xls` → ĐÃ TẢI ĐƯỢC FILE nhưng
  CHƯA đọc được nội dung text bên trong (đây là định dạng nhị phân có cấu
  trúc riêng, cần parser riêng cho từng loại — chưa làm, báo nếu cần).

**CHƯA kiểm chứng được bằng build thật** (môi trường tạo code không có
mạng/Android SDK) — 2 điểm rủi ro cao nhất cần xem log CI đầu tiên nếu lỗi:
1. API chính xác của `webview_cookie_manager` (`getCookies(url)` trả về
   `List<Cookie>` từ `dart:io`) có thể lệch nhẹ theo version — nếu lỗi biên
   dịch ở đây, kiểm tra README của package trên pub.dev đúng version đã ghim
   trong `pubspec.yaml`.
2. `onNavigationRequest` trả `NavigationDecision` đồng bộ (không `Future`) —
   nếu SDK version yêu cầu `FutureOr<NavigationDecision>`, có thể cần bọc
   `async` (không đổi tôi hành vi vì `_downloadFile` tự chạy async bên trong,
   không cần `await` trước khi return `NavigationDecision.prevent`).

## 12. FIX build lỗi #28 (29/07/2026) — sai version webview_cookie_manager

**Lỗi thật đã xảy ra:** `webview_cookie_manager ^3.0.1 doesn't match any versions`
- Nguyên nhân: tôi ghim version `^3.0.1` cho package này mà KHÔNG kiểm chứng
  được (môi trường code không có mạng để tra pub.dev), và con số đó sai —
  package không có bản 3.x.

**Đã sửa:** đổi 3 dependency mới thêm (mục 10-11) từ ghim đúng patch version
sang RANGE rộng hơn, để `pub get` tự chọn bản thực sự tồn tại thay vì lỗi
version-solving nếu tôi đoán sai số:
- `webview_cookie_manager: ">=1.0.0 <4.0.0"`
- `webview_flutter: ">=4.7.0 <5.0.0"`
- `file_picker: ">=8.0.0 <10.0.0"`

Nếu build vẫn báo lỗi version-solving ở 1 trong 3 dòng này, nghĩa là ngay
cả range trên cũng không khớp bản thật đang có trên pub.dev tại thời điểm
build — mở log, đọc chính xác thông báo "version solving failed" (nó luôn
liệt kê constraint đang xung đột), rồi báo lại cho tôi đúng tên package +
thông báo lỗi để tôi sửa đúng con số.

## 13. FIX build lỗi #31 (29/07/2026) — xung đột win32 giữa file_picker và share_plus

**Lỗi thật:** không phải sai version, mà là XUNG ĐỘT PHỤ THUỘC BẮC CẦU:
- `file_picker` bản < 8.3.3 cần `win32 ^5.x`
- `share_plus` (đã dùng sẵn trong app từ trước, cho tính năng chia sẻ file
  xuất ra) bản ^13.0.0 cần `win32 ^6.x`
- Range tôi ghim trước đó (`<10.0.0`) vô tình chặn mất các bản file_picker
  đủ mới (8.3.3+, có cả bản 12.x) — mà log build đã chỉ đích danh các bản
  đó mới dùng `win32 ^6.x` tương thích với `share_plus`.

**Đã sửa:** `file_picker: ">=8.3.3"` — bỏ hẳn trần trên, để pub tự chọn bản
mới nhất tương thích thay vì tôi đoán số trần rồi lại chặn nhầm bản cần
dùng. Không đụng vào `share_plus` vì đây là dependency ĐÃ CÓ SẴN, đang được
dùng cho tính năng chia sẻ file khác trong app — hạ nó xuống có thể phá
tính năng cũ.

**Bài học chung cho các lần build sau:** khi thêm 1 package mới, rủi ro lớn
nhất không phải version của chính nó, mà là xung đột phụ thuộc bắc cầu (như
win32 ở đây) với package ĐÃ CÓ SẴN trong app. Cách xử lý đúng: đọc kỹ dòng
"Because ... requires ... And because ... requires ..." trong log — pub
luôn liệt kê chuỗi suy luận đầy đủ, chỉ cần nới đúng trần constraint đang
chặn nhầm, không cần hạ dependency cũ.

## 14. FIX build lỗi #34 (29/07/2026) — plugin cũ thiếu namespace (AGP 8+)

**Lỗi thật:** `webview_cookie_manager-2.0.6` (nằm trong pub-cache) không khai
báo `namespace` trong `android/build.gradle` — bắt buộc từ Android Gradle
Plugin 8+, còn plugin này viết từ trước khi có yêu cầu đó. Rất phổ biến với
plugin lâu không cập nhật, không phải lỗi trong code app.

**Đã sửa:** thêm bước "Vá namespace cho plugin Android cũ chưa khai báo"
trong `.github/workflows/build_apk.yml`, chạy NGAY SAU `flutter pub get`
(để package đã có trong pub-cache) và TRƯỚC `flutter build apk`. Bước này
**tự động, không hardcode tên plugin** — dò mọi thư mục `android/` trong
pub-cache, nếu thiếu `namespace` thì lấy `package="..."` từ chính
`AndroidManifest.xml` cũ của plugin đó và khai báo lại thành `namespace`
trong `build.gradle`/`build.gradle.kts` — nên nếu sau này thêm plugin KHÁC
bị lỗi y hệt, cũng tự vá được, không cần sửa workflow lần nữa.

**Nếu build vẫn lỗi liên quan namespace ở đúng bước này:** khả năng cao là
plugin đó không có `AndroidManifest.xml` với `package="..."` (một số dùng
cấu trúc project khác) — cần xem log để biết chính xác path rồi vá tay
riêng cho plugin đó.

## 15. FIX build lỗi #37 (29/07/2026) — bỏ hẳn webview_cookie_manager, tự viết MethodChannel

**Xác nhận:** bước "vá namespace" ở mục 14 KHÔNG giải quyết được (log #37
giống hệt #34) — `webview_cookie_manager` là package bỏ hoang, rủi ro tiếp
tục gây lỗi Gradle khác nếu cứ vá tiếp.

**Đã sửa tận gốc:** BỎ HẲN dependency `webview_cookie_manager` khỏi
`pubspec.yaml`. Thay bằng 1 MethodChannel (`agent_ai_chat/cookies`) tự viết
thẳng vào `MainActivity.kt` — gọi `android.webkit.CookieManager` có sẵn
trong Android SDK, KHÔNG cần thêm bất kỳ dependency Gradle nào nữa nên
KHÔNG THỂ tái diễn lỗi kiểu "namespace/AGP" này được nữa.

Vì `android/` luôn bị `flutter create` sinh lại từ đầu mỗi lần build (xem
mục thiết kế gốc), `MainActivity.kt` cũng bị ghi đè mỗi lần — nên bước mới
"Thêm MethodChannel lấy cookie WebView vào MainActivity.kt" trong
`build_apk.yml` sẽ TỰ GHI LẠI file này sau khi `flutter create` chạy xong,
mỗi lần build, không cần lưu file android riêng trong repo.

**Lưu ý kỹ thuật quan trọng đã tự kiểm chứng được (không cần đoán):** lúc
đầu tôi định dùng `python3 -c "<code nhiều dòng>"` để sinh nội dung
`MainActivity.kt`, nhưng gặp đúng 2 lỗi liên tiếp khi tự mô phỏng chạy thử
(không cần chờ CI thật):
1. Heredoc (`<< EOF`) lồng trong khối YAML `run: |` bị thụt lề → dòng kết
   thúc heredoc dính khoảng trắng → bash không nhận diện được delimiter →
   script vỡ. (Nguyên nhân gốc của việc bước vá ở mục 14 không chạy đúng.)
2. Đổi sang `python3 -c` nhiều dòng thì lại dính `IndentationError` vì
   Python bắt buộc dòng đầu ở cột 0, xung đột với yêu cầu thụt lề tối thiểu
   của YAML block scalar.

**Giải pháp cuối cùng — dùng chuỗi lệnh `echo` bash** (không phải heredoc,
không phải python) — bash hoàn toàn không quan tâm khoảng trắng thụt lề
trước mỗi lệnh, nên tương thích 100% với yêu cầu thụt lề của YAML. Đã tự
trích xuất chính xác script từ YAML bằng PyYAML và CHẠY THỬ THẬT trên 1
`MainActivity.kt` giả lập — xác nhận sinh ra đúng nội dung Kotlin mong
muốn, và `bash -n` xác nhận toàn bộ 12 bước script trong file đều hợp lệ cú
pháp — trước khi gửi bản này, chứ không chỉ đoán.

**Điều duy nhất CHƯA kiểm chứng được** (vì không có Android SDK/Gradle
thật trong môi trường code): bản thân đoạn Kotlin có compile được với
`FlutterActivity`/`FlutterEngine`/`MethodChannel` API đúng hay không —
đây là API rất ổn định, ít thay đổi qua các bản Flutter, nên rủi ro thấp
hơn hẳn so với dùng package ngoài, nhưng nếu build vẫn lỗi ở bước Gradle
liên quan `MainActivity.kt`, gửi log để tôi xem chính xác.

## 16. Cập nhật 29/07/2026 — Dán nội dung vào ô đang chọn (thay cho "auto detect + auto gửi")

**Yêu cầu gốc:** JS tự học/heuristic dò input box + send button trên BẤT KỲ
trang nào (bình luận blog, chat, diễn đàn...), dán code vào, không hardcode
selector.

**Đã làm khác đi có chủ đích** (đã hỏi lại người dùng trước khi làm): thay
vì "dò input box + send button rồi TỰ BẤM GỬI" (rủi ro cao — nếu là ô chat
người thật hoặc form đăng công khai, tool tự gửi thay nghĩa là nội dung đi
luôn mà không ai kịp xem lại, và có thể bị nền tảng coi là hành vi bot), đã
dùng `document.activeElement` (phần tử người dùng ĐANG bấm/focus) để xác
định "ô nào" — không cần dò/hardcode selector, tổng quát với mọi trang —
NHƯNG dừng lại sau khi dán, KHÔNG tự bấm Gửi/Đăng. Người dùng luôn tự xem
lại và bấm gửi bằng tay.

### `lib/screens/sources/webview_capture_screen.dart` (cập nhật)
- Nút "Dán nội dung" (icon paste) trên AppBar → mở bottom sheet chọn 1 Tài
  liệu nguồn có sẵn HOẶC gõ văn bản tuỳ ý → `_pasteIntoFocusedElement`
  chạy JS dán vào `document.activeElement`.
- Dùng NATIVE SETTER qua `Object.getOwnPropertyDescriptor` (không gán
  `el.value = ...` trực tiếp) rồi bắn sự kiện `input`/`change` — cần thiết
  vì các trang viết bằng React/Vue (rất phổ biến cho chat/comment hiện đại)
  ghi đè setter mặc định để tự quản lý state nội bộ; gán trực tiếp sẽ không
  được framework nhận diện là có thay đổi.
- Hỗ trợ cả `<textarea>`/`<input>` VÀ phần tử `contenteditable` (nhiều ô
  chat hiện đại như Messenger/Slack web dùng div contenteditable thay vì
  textarea thật).

**CHƯA làm** (và sẽ không làm trừ khi người dùng xác nhận rõ ràng và hiểu
rủi ro): tự động dò "send button" rồi tự bấm — nếu người dùng sau này thật
sự cần tự động gửi hàng loạt (ví dụ auto-reply), đây là mức rủi ro cao hơn
hẳn (auto-posting/spam khả năng cao), cần cân nhắc riêng, không nên bật mặc
định.

## 17. Cập nhật 29/07/2026 — Hoàn thiện luồng "upload zip → bên kia sửa → tải zip đã sửa"

Trả lời câu hỏi: bottom sheet "Dán nội dung" (mục 16) giờ CHỌN ĐƯỢC file
.zip trực tiếp, và luồng ngược lại (nhận bản đã sửa, tải zip) đã có đủ 2
cách.

### 17.1. `lib/services/export/code_zip_export.dart` — thêm `formatForSharing`
Ghép nhiều file thành 1 chuỗi text theo ĐÚNG cú pháp
```đường/dẫn/file.ext ... ``` mà `extractFiles` đọc lại được — vòng lặp
tròn: format ra → gửi cho bên ngoài → nhận lại → extractFiles → export zip.

### 17.2. `lib/screens/sources/webview_capture_screen.dart` — bottom sheet dán nội dung
Thêm nút "Chọn file .zip (source code)" — đọc toàn bộ file text trong zip,
ghép bằng `formatForSharing`, rồi dán vào ô đang chọn trên trang (dùng
`document.activeElement`, không tự bấm gửi — xem mục 16).

### 17.3. `lib/screens/code/zip_edit_screen.dart` — thêm "Cách 2"
Trước đây chỉ có 1 cách (AI trong app tự sửa, tốn 1 lần API). Giờ có thêm
"Cách 2 — đã có bản sửa từ nơi khác (0 token)": nút "Copy X file đã chọn"
(copy ra clipboard theo cú pháp chuẩn để gửi cho AI khác/người khác), và ô
"Dán kết quả đã sửa" + nút "Ghép & tải zip (không gọi AI)" — parse trực
tiếp bằng `CodeZipExporter.extractFiles` rồi merge + xuất zip, HOÀN TOÀN
KHÔNG gọi `sendMessageOnce` — đúng yêu cầu "bên kia chỉnh sửa, app chỉ tải
lại zip đã sửa", không tốn token của chính app cho bước này.

**Luồng đầy đủ giờ đã khép kín:**
1. `ZipEditScreen`: upload zip, tick file, bấm "Copy X file đã chọn".
2. Mở `WebviewCaptureScreen`, vào trang AI khác/chat người khác, bấm/chạm
   vào ô nhập, bấm 📋 "Dán nội dung" (hoặc dán trực tiếp bằng clipboard hệ
   thống) → tự bấm Gửi.
3. Chờ bên kia trả lời → bấm "Trích xuất nội dung trang" để lưu câu trả
   lời thành Tài liệu nguồn (hoặc copy tay).
4. Quay lại `ZipEditScreen` → dán câu trả lời vào ô "Cách 2" → "Ghép & tải
   zip (không gọi AI)".

Giao diện `ZipEditScreen` đã bọc lại trong `SingleChildScrollView` (danh
sách file giới hạn cao 220px cuộn riêng) để tránh tràn màn hình khi có
thêm nhiều control mới trên máy nhỏ.

## 18. KHÔNG làm (29/07/2026) — network interception / proxy-VPN / giả lập clipboard

Người dùng đề xuất tích hợp thêm: (1) patch `window.fetch`/`XMLHttpRequest`
để đọc request/response ngầm, (2) giả lập sự kiện Ctrl+C để tự copy nội
dung vào clipboard, (3) `shouldInterceptRequest` (WebViewClient) bắt toàn
bộ request native, (4) proxy/VPN local bắt toàn bộ traffic thiết bị — làm
fallback khi JS trích xuất DOM "không ăn thua" với web React.

**KHÔNG làm cả 4 cái này.** Lý do cốt lõi: khác với những gì đã build
(trích xuất DOM hiển thị, dán vào ô đang focus, tải file qua link — đều chỉ
lấy ĐÚNG CÁI người dùng đang nhìn thấy, TẠI ĐÚNG LÚC họ chủ động bấm), cả 4
cơ chế trên đều chạy NGẦM và bắt được NHIỀU HƠN những gì hiển thị trên màn
hình — kể cả dữ liệu người khác (ví dụ 1 trang chat nhóm tải ngầm dữ liệu
của người khác trong nhóm dù chưa hiển thị). Proxy/VPN local đặc biệt là
đúng hạ tầng nền tảng của spyware/stalkerware bất kể mục đích ban đầu, và
không thể giới hạn phạm vi chỉ "đọc code" mà không đồng thời đọc được mọi
traffic khác của thiết bị (mật khẩu, ngân hàng, tin nhắn riêng...).

**Lý do kỹ thuật "React DOM hay đổi" không thực sự đúng:** đã giải thích
cho người dùng — `document.body.innerText` đọc DOM ĐÃ RENDER cuối cùng,
không quan tâm framework nào tạo ra (React/Vue đều ra HTML thật cuối cùng).
Vấn đề thật có thể gặp là TIMING (bấm trích xuất khi trang đang stream dở),
không phải do React.

**Đã làm thay vào đó (vẫn chỉ đọc DOM hiển thị, không đụng network):**
`_extractAndSave` trong `webview_capture_screen.dart` giờ tự đọc lại DOM
tối đa 5 lần (mỗi 500ms), nếu nội dung NGỪNG THAY ĐỔI giữa 2 lần đọc liên
tiếp (dấu hiệu trang đã stream/render xong) thì dừng sớm và dùng bản đó;
nếu sau ~2.5s vẫn còn đổi thì dùng bản cuối cùng. Xử lý đúng ca dùng thật
(bấm trích xuất khi AI web đang gõ dở câu trả lời) mà không cần bất kỳ cơ
chế can thiệp mạng nào.

## 19. Cập nhật 29/07/2026 — OCR cho trang canvas + phản hồi về network interception

**Phản hồi lại 2 điểm người dùng nêu:**

1. *"Mật khẩu/dữ liệu khác là của mình, dữ liệu người khác đâu có trên máy
   mình"* — công nhận 1 phần: patch fetch/XHR chỉ trong 1 tab thì đúng là
   không đụng traffic của app khác. Nhưng nêu rõ 1 điểm KỸ THUẬT cụ thể
   (không phải nguyên tắc chung): request/response NGẦM của 1 trang (ví dụ
   trang chat nhóm) thường tải về nguyên object thông tin TẤT CẢ thành viên
   nhóm (tên/id/avatar/trạng thái) để hiển thị, dù màn hình chỉ render vài
   dòng — patch fetch/XHR bắt được nguyên object đó, DOM-extract thì không.
   Đây là lý do KHÔNG làm fetch/XHR patch, không phải vì nguyên tắc mơ hồ.
   Riêng PROXY/VPN LOCAL thì khác hẳn về kiến trúc: `VPNService` trên
   Android THEO THIẾT KẾ là toàn hệ thống, không thể giới hạn chỉ 1 tab —
   đây là lý do kỹ thuật cứng, không phải lựa chọn của tôi.

2. *"Trang dùng canvas thì bó tay"* — ĐÚNG, đây là giới hạn thật của
   `document.body.innerText` (canvas chỉ là pixel, không có text node).

**Đã thêm để giải quyết điểm 2** (không cần network interception):
`lib/screens/sources/webview_capture_screen.dart` — nút OCR (icon máy quét)
trên AppBar:
- Bọc `WebViewWidget` trong `RepaintBoundary` (key `_webviewKey`).
- Chụp ảnh đúng khung hình đang hiển thị (`boundary.toImage()`) — bao gồm
  cả nội dung vẽ bằng canvas/WebGL, vì đây là ảnh chụp pixel thật, không
  phải đọc DOM.
- Chạy `google_mlkit_text_recognition` (`TextRecognizer`) để nhận diện chữ
  trong ảnh — **xử lý HOÀN TOÀN TRÊN MÁY, không upload ảnh lên server nào**.
  Lưu ý nhỏ (để chính xác, không phóng đại): lần ĐẦU TIÊN dùng, Google Play
  Services có thể cần tải xuống 1 lần bộ model nhận diện chữ (vài MB) —
  BẢN THÂN ẢNH CHỤP thì không rời khỏi máy, chỉ có bước tải model dùng
  mạng, không phải gửi dữ liệu.
- Lưu kết quả thành `SourceDocument` như bình thường, kèm cảnh báo "OCR có
  thể nhận nhầm ký tự, xem lại trước khi dùng" vì OCR không chính xác 100%.

**Dependency mới, RỦI RO BUILD chưa kiểm chứng được** (như các lần trước,
môi trường code không có mạng): `google_mlkit_text_recognition` — thêm
`path_provider` (đã có sẵn), `path` không cần thêm. Nếu build lỗi, khả năng
cao nhất là (a) version không khớp (đã để range rộng
`">=0.13.0 <1.0.0"` để giảm rủi ro), hoặc (b) thiếu cấu hình
Google Play Services / minSdkVersion — gửi log để xử lý tiếp, đây LÀ MỘT
package phổ biến, ổn định hơn `webview_cookie_manager` (đội ngũ
`flutter-mlkit` maintain tích cực), nhưng vẫn cần build thật để xác nhận.

## 20. Cập nhật 29/07/2026 — Giải quyết 4/5 giới hạn đã liệt kê ở mục 19

Người dùng yêu cầu giải quyết luôn 5 giới hạn đã nêu. Kết quả:

### #1 — Trang chặn WebView (SSO/2FA) — CHỈ giải quyết 1 PHẦN
Thêm `setUserAgent(...)` giả 1 chuỗi Chrome mobile chuẩn trong `initState`
của `webview_capture_screen.dart`. Việc này giúp được với hệ thống NỘI BỘ
đơn giản chỉ kiểm tra UA có phải "trình duyệt hiện đại" hay không.
**CỐ Ý KHÔNG nhắm tới việc lách qua chặn OAuth WebView có chủ đích của
Google/Meta** — đó là biện pháp chống lừa đảo bảo vệ chính người dùng
(chống app giả mạo/keylogger đội lốt màn hình đăng nhập), không nằm trong
phạm vi hỗ trợ. Nếu gặp, cách duy nhất đáng tin cậy vẫn là đăng nhập bằng
trình duyệt thật ngoài app trước.

### #2 — Infinite scroll — ĐÃ GIẢI QUYẾT
Hàm `_extractInfiniteScroll` (nút icon mũi tên tròn trên AppBar): tự cuộn
`window.scrollBy` nhiều lần (tối đa 30, dừng sớm nếu `scrollHeight` không
tăng thêm 2 lần liên tiếp), đọc lại DOM sau mỗi lần cuộn, gộp các DÒNG mới
xuất hiện vào `LinkedHashSet` (giữ thứ tự, tự loại trùng). Vẫn chỉ đọc DOM
hiển thị tại mỗi bước.

### #3 — File tải qua `blob:` URL — ĐÃ GIẢI QUYẾT
- Tiêm script ghi đè `URL.createObjectURL` ngay sau mỗi lần trang load xong
  (`onPageFinished`) để "nhớ" lại đối tượng `Blob` gốc ứng với mỗi blob URL
  trang tự sinh ra.
- `onNavigationRequest` bắt link bắt đầu bằng `blob:` → gọi
  `_downloadBlobFile` → đọc lại Blob qua `FileReader.readAsDataURL`, nhận
  base64 qua `JavaScriptChannel` tên `BlobChannel` (dùng `Completer` để chờ
  kết quả bất đồng bộ, timeout 15s).
- Nếu bytes có chữ ký `PK\x03\x04` (zip thật) → mở luôn `ZipEditScreen`.
  Không nhận diện được → lưu vào thư mục Documents của app rồi báo đường
  dẫn.
- Đây vẫn là dữ liệu DO CHÍNH HÀNH ĐỘNG người dùng (bấm nút tải trên trang)
  sinh ra, không phải bắt traffic ngầm.

### #4 — OCR đa ngôn ngữ — ĐÃ GIẢI QUYẾT
Nút OCR trên AppBar đổi thành `PopupMenuButton` chọn
`TextRecognitionScript`: Latin (mặc định, đọc tốt tiếng Việt có dấu),
Trung, Nhật, Hàn, Devanagari (Ấn Độ) — chọn xong chạy OCR luôn với ngôn ngữ
đó.

### #5 — OCR không chính xác 100% — KHÔNG THỂ GIẢI QUYẾT TRIỆT ĐỂ
Giới hạn cố hữu của mọi công nghệ OCR (font quá cách điệu, chữ quá nhỏ,
tương phản thấp). Đã có cảnh báo "xem lại trước khi dùng" trong snackbar
kết quả OCR (mục 19) — không thể làm gì thêm ngoài việc đó.

**Dependency KHÔNG có thêm** — chỉ dùng lại `path_provider` (đã có),
`dart:async`/`dart:collection` (built-in), không tăng thêm rủi ro build so
với mục 19.

**Điểm chưa kiểm chứng được (như thường lệ, không có Android SDK để build
thật):** tên enum `TextRecognitionScript.devanagiri` — package
`google_mlkit_text_recognition` có 1 lỗi chính tả nổi tiếng trong tên enum
này (viết "devanagiri" thay vì "devanagari" đúng chính tả tiếng Phạn), tôi
nhớ là vậy nhưng không có mạng để tra lại chắc chắn — nếu build lỗi đúng
dòng này, đổi thử sang `devanagari` (không có "i" cuối "gi").

## 21. Cập nhật 29/07/2026 — Đọc chữ canvas CHÍNH XÁC (thay thế OCR khi áp dụng được)

Trả lời: "còn cách nào giải quyết ngoài OCR" cho vấn đề #5 (OCR không chính
xác 100%) — CÓ, với 1 giới hạn rõ ràng.

**Kỹ thuật:** khi trang vẽ chữ lên `<canvas>`, phần lớn dùng đúng API chuẩn
`ctx.fillText(text, x, y)` / `ctx.strokeText(...)` — hàm này nhận CHUỖI TEXT
làm tham số, TRƯỚC KHI biến thành pixel. Ghi đè (`override`) 2 hàm này qua
JS tiêm vào NGAY KHI trang bắt đầu load (`onPageStarted`, sớm hơn hẳn
`onPageFinished` để giảm khả năng bỏ lỡ lần vẽ đầu tiên) → lưu mọi chuỗi
text bị vẽ vào `window.__canvasTextLog`. Đây là dữ liệu CHÍNH XÁC 100%
(không qua bước "đoán chữ trong ảnh" như OCR).

Kèm bonus: đọc luôn `aria-label`/`aria-describedby` trên trang — text mà
chính trang cung cấp cho screen reader (accessibility), cũng chính xác
100% cho nội dung canvas/hình ảnh.

### `lib/screens/sources/webview_capture_screen.dart` (cập nhật)
- Script override `fillText`/`strokeText` tiêm trong `onPageStarted`.
- Hàm `_extractCanvasText`: đọc lại `window.__canvasTextLog` + quét
  `aria-label`, gộp lại, lưu thành `SourceDocument`.
- Nút mới trên AppBar (icon "Aa") — đặt TRƯỚC nút OCR, vì nên thử cách này
  trước (chính xác hơn, chỉ khi không ăn thua mới dùng OCR).

**Giới hạn rõ ràng (không phải mọi canvas đều bắt được):**
- Trang vẽ chữ kiểu "sprite ảnh" (mỗi chữ là 1 hình có sẵn, hay gặp ở game)
  → không gọi `fillText` → không bắt được gì → quay lại OCR.
- WebGL thường không có API text chuẩn tương đương → cũng không bắt được
  → chỉ OCR mới xử lý được.
- Injection tại `onPageStarted` là điểm sớm nhất `webview_flutter` cho phép,
  nhưng vẫn có thể có 1 khoảng trễ nhỏ (race condition) nếu trang vẽ NGAY
  LẬP TỨC trong lúc parse HTML — trường hợp thường gặp hơn là canvas vẽ lại
  liên tục (chat, animation), nên phần lớn nội dung vẫn được bắt kể cả có
  bỏ lỡ vài khung hình đầu.

## 22. FIX build lỗi #40 (29/07/2026) — bug import có sẵn từ code gốc, mới lộ ra

**Lỗi thật:** `lib/widgets/export_runner.dart` import tương đối
`'export/docx_export.dart'` (và pptx/xlsx/code_zip tương tự) — nghĩa là kỳ
vọng các file đó nằm ở `lib/widgets/export/`. Nhưng vị trí THẬT của các
exporter là `lib/services/export/` (đã xác nhận bằng `find`). Đây là **bug
có sẵn từ code gốc của dự án, không phải do các thay đổi ở mục 10-21 gây
ra** — nó chỉ chưa từng lộ ra vì các lần build trước đó ĐỀU fail sớm hơn ở
bước Gradle (webview_cookie_manager, version file_picker...) nên trình biên
dịch Dart chưa bao giờ chạy tới đủ xa để phát hiện.

**Đã sửa:** đổi 4 dòng import trong `export_runner.dart` từ
`'export/xxx.dart'` → `'../services/export/xxx.dart'`.

**Về lỗi "Member not found: 'platform'" ở 3 file khác** (source_documents_
screen.dart, zip_edit_screen.dart, webview_capture_screen.dart) — đã kiểm
tra: `FilePicker.platform.pickFiles(...)` là API CHUẨN, đúng, ổn định của
package `file_picker` từ rất lâu, và cả 3 file đều import đúng
`package:file_picker/file_picker.dart`. Nhiều khả năng đây là LỖI DÂY
CHUYỀN (cascading error) — khi trình biên dịch Dart gặp lỗi fatal ở
import của `export_runner.dart`, nó có thể báo sai lệch ở các file khác
trong cùng đồ thị biên dịch. Dự đoán: lỗi này sẽ TỰ BIẾN MẤT sau khi sửa
import ở trên — nếu build #41 vẫn còn báo lỗi `FilePicker.platform` y hệt,
đây là dấu hiệu thật cần điều tra riêng (không phải cascading nữa).

## 23. FIX build lỗi #43 (29/07/2026) — file_picker bị pub chọn nhầm bản beta

**Xác nhận:** lỗi `export_runner.dart` ở mục 22 đã hết hẳn (fix đúng). Lỗi
`FilePicker.platform` ("Member not found") vẫn còn Y HỆT → xác nhận đây
KHÔNG phải cascading error như dự đoán ở mục 22, mà là lỗi thật.

**Nguyên nhân xác định được:** ở mục 17/23 tôi để `file_picker: ">=8.3.3"`
KHÔNG có trần trên (để giải quyết xung đột win32 với `share_plus ^13`, xem
mục 13). Nhưng Dart pub CÓ CHẤP NHẬN bản beta/prerelease khi không loại trừ
tường minh — và theo đúng log lỗi ở build #31 (mục 13), chuỗi bản `file_
picker` dùng `win32 ^6.x` (khớp với `share_plus ^13`) chỉ bắt đầu từ
`12.0.0-beta.1` — TỨC LÀ BẢN BETA, chưa ổn định, API có thể đổi/thiếu so
với bản ổn định 8.x-11.x. Rất có khả năng bản beta này thiếu hẳn getter
`.platform` hoặc cấu trúc lại chưa hoàn thiện.

**Đã sửa tận gốc — bỏ hẳn nhu cầu cần bản beta:**
- `file_picker: ">=8.3.3 <12.0.0"` — chặn cứng, không cho pub chọn bất kỳ
  bản 12.x/beta nào nữa, chỉ dùng dòng ổn định 8.3.3–11.x.
- `share_plus: ^12.0.2` (hạ từ `^13.0.0`, đúng gợi ý CHÍNH THỨC trong log
  lỗi build #31: "Consider downgrading your constraint on share_plus:
  flutter pub add share_plus:^12.0.2") — dòng 12.x của share_plus dùng
  `win32 ^5.x`, khớp với dòng ổn định của file_picker, không còn xung đột.
- Đã kiểm tra `file_saver.dart` chỉ dùng `Share.shareXFiles`/`XFile` — API
  rất ổn định, có từ lâu, chắc chắn còn nguyên trong `share_plus ^12.0.2`,
  không ảnh hưởng chức năng chia sẻ file hiện có.

**Bài học:** khi 1 dependency cần bản MỚI HƠN để giải quyết xung đột phụ
thuộc bắc cầu (như win32), cần kiểm tra kỹ xem bản "mới hơn" đó có phải bản
ỔN ĐỊNH hay chỉ là prerelease/beta — nếu là beta, ưu tiên hạ dependency BÊN
KIA (share_plus) xuống thay vì chấp nhận API chưa ổn định của bản beta.

## 24. FIX build lỗi #46 (29/07/2026) — bỏ hẳn file_picker, chuyển sang file_selector

**Xác nhận quan trọng:** giả thuyết "bản beta" ở mục 23 SAI. Log build #46
cho thấy `share_plus 12.0.2` và `win32 5.15.0` đều là bản ỔN ĐỊNH (không
phải beta/prerelease) — vậy mà lỗi `FilePicker.platform` ("Member not
found") vẫn Y HỆT. Nghĩa là đã đoán sai nguyên nhân 2 LẦN LIÊN TIẾP (mục
23 và giờ). Không đoán tiếp lần 3 nữa.

**Quyết định:** bỏ HẲN `file_picker` khỏi dự án, chuyển toàn bộ 3 chỗ dùng
sang `file_selector` — plugin CHÍNH THỨC do chính đội ngũ Flutter maintain
(nằm trong flutter.dev/packages, cùng nhóm với `path_provider`,
`shared_preferences`...), API tối giản hơn hẳn (`openFile(acceptedTypeGroups:
[XTypeGroup(extensions: [...])])` trả về `XFile?`, chỉ cần `.name` và
`.readAsBytes()`), ít bề mặt để hỏng hơn nhiều so với `file_picker` (vốn hỗ
trợ rất nhiều tính năng phức tạp — multi-pick, custom UI, compression...
mà app này không dùng tới).

### Đã sửa 3 file:
- `lib/screens/sources/source_documents_screen.dart` — `_uploadFile`
- `lib/screens/code/zip_edit_screen.dart` — `_pickZip`
- `lib/screens/sources/webview_capture_screen.dart` — `_pickZipAndPaste`

Cả 3 đổi từ `FilePicker.platform.pickFiles(type: FileType.custom,
allowedExtensions: [...], withData: true)` → `openFile(acceptedTypeGroups:
[XTypeGroup(extensions: [...])])`, và từ `PlatformFile` (có `.bytes`,
`.name`) → `XFile` (dùng `await f.readAsBytes()` + `.name`).

### `pubspec.yaml`
- Bỏ `file_picker`, thêm `file_selector: ">=1.0.0 <2.0.0"`.
- GIỮ NGUYÊN `share_plus: ^12.0.2` (không cần đổi lại — vẫn hoạt động tốt,
  không có lý do để đổi thêm biến số khi đang cố ổn định build).

**Rủi ro còn lại (thành thật, không phóng đại):** đây là lần đầu dùng
`file_selector` trong dự án này, dù tôi tự tin về API hơn `file_picker`
(đơn giản, ít thay đổi, đội Flutter chính thức maintain), vẫn CHƯA kiểm
chứng được bằng build thật. Nếu build #47 vẫn lỗi liên quan `file_selector`
hoặc `XTypeGroup`/`openFile`, gửi log ngay — đây sẽ là dấu hiệu vấn đề nằm
ở chỗ khác hoàn toàn (ví dụ cấu hình Android chung, không phải riêng 1
package nào), cần điều tra theo hướng khác hẳn.

## 25. FIX build lỗi #49 (29/07/2026) — R8 thiếu class ML Kit ngôn ngữ + đơn giản hoá OCR

**Tin tốt trước:** lỗi Dart compile (`FilePicker.platform`) đã HẾT HOÀN
TOÀN sau khi chuyển sang `file_selector` ở mục 24 — xác nhận đúng nguyên
nhân, build tiến xa hơn hẳn (qua hết bước Dart compile, resolve dependency,
tới tận bước R8 minify — bước gần cuối cùng của quy trình build).

**Lỗi mới (khác hẳn, ở tầng R8/ProGuard):**
`google_mlkit_text_recognition` có code Kotlin đã biên dịch sẵn tham chiếu
tới 4 lớp nhận diện chữ Trung/Nhật/Hàn/Devanagari (`ChineseTextRecognizerOptions`,
`JapaneseTextRecognizerOptions`, `KoreanTextRecognizerOptions`,
`DevanagariTextRecognizerOptions`), BẤT KỂ app Dart có thực sự gọi tới các
ngôn ngữ đó hay không — vì code Kotlin của chính plugin có nhánh xử lý cho
cả 4, và R8 (bước thu gọn code khi build release) phân tích TOÀN BỘ nhánh
đó, báo lỗi vì các lớp tương ứng không có trong classpath (app không khai
báo thêm module ngôn ngữ đó, mặc định `google_mlkit_text_recognition` chỉ
có sẵn module Latin).

**Đã sửa 2 phần cùng lúc:**

1. **Đơn giản hoá UI OCR** (`webview_capture_screen.dart`, mục 20 trước đó
   thêm menu chọn ngôn ngữ) — BỎ menu Trung/Nhật/Hàn/Devanagari, chỉ còn
   OCR Latin (đúng nhu cầu thật của người dùng — tiếng Việt dùng bảng chữ
   Latin). Lý do bỏ thay vì thêm dependency ngôn ngữ: thêm dependency thật
   cho 4 ngôn ngữ đó sẽ tăng thêm rủi ro Gradle (kích thước APK, thêm native
   module) mà người dùng không thực sự cần — ĐÚNG nguyên tắc "cái gì tiết
   kiệm được thì tiết kiệm" người dùng đã nói ở đầu phiên làm việc này.

2. **Thêm bước CI ghi `android/app/proguard-rules.pro`** với `-dontwarn`
   cho 4 package Kotlin đó — an toàn vì đã bỏ hẳn khả năng gọi tới các nhánh
   code đó từ Dart (mục 1 ở trên), nên `-dontwarn` không che giấu rủi ro
   crash runtime thật nào. Bước này CŨNG tự kiểm tra và thêm dòng
   `proguardFiles(...)` vào `buildTypes.release` trong `build.gradle.kts`
   NẾU bản Flutter đang dùng chưa tự có sẵn — đã tự mô phỏng chạy thử bằng
   `sed` thật trên file giả lập (không đoán), xác nhận chèn đúng vị trí và
   không chèn trùng lần 2 nếu đã có sẵn.

**Nếu build #50 vẫn lỗi R8** (dù đã thêm dontwarn) — khả năng là còn thiếu
class khác chưa liệt kê hết trong `missing_rules.txt` (log build luôn ghi
đường dẫn file này) — gửi thêm nội dung file đó nếu build tiếp tục lỗi R8.

## 26. FIX build lỗi #52 (29/07/2026) — bước vá proguardFiles ở mục 25 ÂM THẦM THẤT BẠI

**Xác nhận bằng test thật (không đoán):** lỗi R8 ở build #52 GIỐNG HỆT 100%
build #49 (từng dòng, từng class) dù đã thêm bước vá ở mục 25 — nghĩa là
bước đó đã KHÔNG CÓ TÁC DỤNG GÌ. Tự dựng lại file `build.gradle.kts` giả
lập GIỐNG NHƯ THẬT (có `buildTypes { getByName("release") { isMinifyEnabled
= true } } }`, KHÔNG có dòng `signingConfig`) và chạy thử ĐÚNG script trong
mục 25 → xác nhận: sed neo vào `/signingConfig/a\...` bên trong 1 range
`/getByName("release")/,/}/` sẽ ÂM THẦM KHÔNG CHÈN ĐƯỢC GÌ nếu range đó
không có dòng "signingConfig" — không báo lỗi, chỉ đơn giản là không làm
gì, nên trước đó tưởng đã sửa nhưng thực ra vô tác dụng.

**Đã sửa (đã tự test cả 2 kịch bản trước khi gửi):**
- Đổi neo sang chính dòng MỞ `getByName("release") {` — chèn ngay sau dòng
  này bất kể bên trong release{} có gì, không phụ thuộc "signingConfig"
  có tồn tại hay không. Test với file giả lập KHÔNG có signingConfig →
  chèn đúng.
- Thêm fallback: nếu cách trên vẫn không chèn được (ví dụ bản Flutter nào
  đó dùng cú pháp Kotlin DSL rút gọn `release { }` thay vì
  `getByName("release") { }`), thử neo vào đúng cú pháp rút gọn đó. Test
  với file giả lập dùng cú pháp rút gọn → chèn đúng.
- Thêm cảnh báo rõ ràng ra log nếu CẢ 2 cách đều thất bại (thay vì âm thầm
  im lặng như lần trước).
- LUÔN in ra TOÀN BỘ nội dung `build.gradle.kts` cuối bước, để lần build
  sau (nếu vẫn lỗi) có thể đọc thẳng log và biết chính xác file thật trông
  như thế nào, không cần đoán/dựng lại file giả lập nữa.

**Bài học:** khi patch file bằng sed dựa trên "neo vào 1 dòng cụ thể", luôn
tự dựng file giả lập THEO ĐÚNG kịch bản THIẾU dòng neo đó để kiểm tra sed
có ÂM THẦM THẤT BẠI hay không — sed không match thì không báo lỗi gì cả,
rất dễ tưởng đã sửa xong nhưng thực ra không có tác dụng.

## 27. FIX build lỗi #55 (29/07/2026) — tắt R8 full mode thay vì tiếp tục vá -dontwarn

Người dùng đã đúng khi phản đối việc tôi đề xuất bỏ tính năng thay vì cố
tìm cách giải quyết — xin ghi nhận lại rõ ràng hướng xử lý đã áp dụng.

**Đã xác nhận:** người dùng dùng ĐÚNG bản zip mới nhất (mục 26) khi build
#55, vậy mà lỗi R8 vẫn giống hệt 100%. Có 2 khả năng: (a) bước chèn
`proguardFiles` vẫn chưa hoạt động vì lý do khác chưa lường tới, hoặc (b)
`-dontwarn` đơn thuần không đủ vì R8 "full mode" (mặc định từ AGP 7+) nâng
lỗi "missing class" lên thành LỖI CỨNG bất kể có `-dontwarn` hay không.

**Đã thêm (không bỏ tính năng OCR):** bước CI mới "Tắt R8 full mode" — ghi
`android.enableR8.fullMode=false` vào `android/gradle.properties` (tự kiểm
tra, không thêm trùng nếu đã có). Đây là cách xử lý CHÍNH THỨC được Google
tài liệu hoá riêng cho đúng nhóm lỗi "thư viện bên thứ 3 đóng gói không
nhất quán giữa các module" — khác hẳn việc tắt hẳn minify: app vẫn được
thu gọn/obfuscate bình thường, chỉ nới lỏng đúng phần R8 phân tích nghiêm
ngặt toàn chương trình gây ra lỗi cứng này. Giữ nguyên `-dontwarn` ở bước
trước làm lớp phòng thủ thứ 2.

Đã tự test trên file `gradle.properties` giả lập (cả lần đầu ghi và lần 2
kiểm tra không ghi trùng) trước khi gửi.

**Nếu build #56 vẫn lỗi y hệt:** đây sẽ là dấu hiệu RẤT RÕ rằng nguyên nhân
không nằm ở tầng ProGuard/R8 nữa mà ở việc dependency `com.google.mlkit:
text-recognition-chinese/-japanese/-korean/-devanagari` (các module ngôn
ngữ) thực sự KHÔNG được `google_mlkit_text_recognition` tự động kéo về —
lúc đó cách xử lý đúng sẽ khác hẳn: thêm thẳng các dependency Android gốc
đó vào `android/app/build.gradle.kts` (cần biết đúng version tương thích,
rủi ro cao hơn vì đụng trực tiếp vào Maven artifact gốc của Google, không
qua Flutter/Dart nữa).

## 28. FIX build lỗi #58 (29/07/2026) — thêm thẳng dependency ML Kit ngôn ngữ + lưu chẩn đoán

**Xác nhận:** lỗi R8 vẫn Y HỆT sau CẢ 3 cách "ẩn cảnh báo" (dontwarn, sửa
neo sed, tắt full mode) — đúng như dự đoán ở mục 27, chuyển hướng xử lý:
class thực sự KHÔNG có trong classpath, không phải R8 xử lý sai.

**Đã làm (đồng thời 2 việc):**

1. **Thêm thẳng dependency Android gốc** cho 4 module ngôn ngữ ML Kit
   (`com.google.mlkit:text-recognition-chinese/-japanese/-korean/-devanagari`)
   vào `android/app/build.gradle.kts` — bước "Thêm thẳng dependency ML Kit
   ngôn ngữ" trong `build_apk.yml`, đặt ngay sau "Get dependencies". Dùng
   `awk` (KHÔNG dùng heredoc python — lần đầu viết bằng heredoc đã LẶP LẠI
   đúng lỗi thụt lề YAML ở mục 25, đã tự phát hiện bằng cách parse YAML lại
   trước khi gửi và sửa ngay). Đã tự test cả 2 kịch bản (có sẵn
   `dependencies {}` / chưa có) + test idempotent (chạy 2 lần không lặp)
   trên file giả lập, đều đúng.

2. **Luôn lưu lại `missing_rules.txt`** làm artifact GitHub Actions (bước
   "Luôn lưu lại missing_rules.txt...", `if: always()`) — kể cả khi build
   fail. Nếu cách 1 vẫn không đủ, đây là lưới an toàn để LẦN SAU đọc được
   CHÍNH XÁC Google gợi ý gì, thay vì tiếp tục đoán mù.

**Rủi ro đã biết trước (thành thật):** version `16.0.1` cho 4 dependency
trên là phỏng đoán hợp lý (dựa trên các version phổ biến của họ ML Kit text
recognition), CHƯA kiểm chứng bằng build thật. Nếu Gradle báo lỗi resolve
version cho các dependency này, đó là dấu hiệu cần đổi số version — khác
hẳn với việc R8 báo "Missing class" (2 loại lỗi khác nhau, dễ phân biệt
trong log).

## 29. Build lỗi #61 — 5 lần liên tiếp lỗi Y HỆT dù đã đổi 4 chiến lược khác nhau

**Vấn đề nghiêm trọng nhất hiện tại: không phải kỹ thuật, mà là XÁC MINH.**
Lỗi R8 giống hệt byte-by-byte qua build #49, #52, #55, #58, #61 — kể cả sau
khi thêm THẲNG dependency Maven thật (mục 28, đáng lẽ phải giải quyết được
nếu áp dụng đúng). Khả năng cao nhất lúc này KHÔNG còn là "đoán sai kỹ
thuật" nữa, mà là các thay đổi trong workflow CHƯA THỰC SỰ được build sử
dụng (có thể do: build lại từ 1 commit cũ qua nút "Re-run", cache Gradle
cũ, hoặc quy trình đưa code lên repo có vấn đề — đã hỏi người dùng nhưng
chưa có câu trả lời rõ).

**Đã thêm (mã đánh dấu FIX-v28):** bước "Build APK (release)" — bước DUY
NHẤT người dùng luôn dán log của nó — giờ IN RA BẰNG CHỨNG TRỰC TIẾP ngay
trước khi build thật:
- Nội dung `proguard-rules.pro`
- Có dòng `proguardFiles` trong `build.gradle.kts` không
- Có dependency ML Kit ngôn ngữ (chinese/japanese/korean/devanagari) trong
  `build.gradle.kts` không
- Có dòng tắt R8 full mode trong `gradle.properties` không

**Nếu build sau vẫn lỗi:** nhìn NGAY đoạn "XÁC NHẬN CÁC BƯỚC VÁ TRƯỚC ĐÓ"
ở đầu log bước Build APK — nếu bất kỳ dòng nào báo "!!! KHÔNG ... !!!", đó
là bằng chứng CHẮC CHẮN các bước vá trước không chạy/không tới nơi, và vấn
đề nằm ở QUY TRÌNH đưa code lên repo hoặc cách trigger build, KHÔNG PHẢI ở
nội dung các bước vá (vốn đã tự test kỹ trước khi gửi qua nhiều mục 15, 25,
26, 27, 28). Nếu tất cả các dòng đều xác nhận CÓ đầy đủ nhưng build vẫn
lỗi y hệt — lúc đó mới quay lại xem xét vấn đề kỹ thuật sâu hơn (ví dụ
version 16.0.1 sai, hoặc cần version khác của các dependency ML Kit).
