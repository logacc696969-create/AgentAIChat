import '../models/source_document.dart';

/// Dựng prompt cho tác vụ "thư ký AI": đọc N tài liệu nguồn (upload hoặc
/// trích xuất từ webview) + yêu cầu của người dùng, rồi sinh MỘT bản trả
/// lời cuối cùng theo ĐÚNG cú pháp mà các exporter sẵn có (DocxExporter/
/// PptxExporter/XlsxExporter/CodeZipExporter) hiểu được — để không cần viết
/// thêm exporter mới, và chỉ tốn 1 lần gọi API cho toàn bộ việc tổng hợp.
class SecretaryPromptBuilder {
  static String build({
    required List<SourceDocument> sources,
    required String instruction,
    required String outputFormat, // 'docx' | 'pptx' | 'xlsx' | 'zip'
  }) {
    final buffer = StringBuffer();

    buffer.writeln('Bạn là thư ký tổng hợp tài liệu. Dưới đây là các tài liệu nguồn '
        'do người dùng cung cấp (upload hoặc trích xuất từ trang web họ đang xem). '
        'Đọc kỹ toàn bộ rồi thực hiện đúng yêu cầu bên dưới.');
    buffer.writeln();

    for (var i = 0; i < sources.length; i++) {
      final s = sources[i];
      buffer.writeln('--- TÀI LIỆU NGUỒN ${i + 1}: "${s.title}" (nguồn: ${s.sourceLabel}) ---');
      buffer.writeln(s.content);
      buffer.writeln();
    }

    buffer.writeln('--- YÊU CẦU CỦA NGƯỜI DÙNG ---');
    buffer.writeln(instruction.trim().isEmpty
        ? 'Tổng hợp lại toàn bộ nội dung trên thành 1 tài liệu rõ ràng, đầy đủ.'
        : instruction.trim());
    buffer.writeln();

    buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
    switch (outputFormat) {
      case 'docx':
        buffer.writeln('Chỉ trả lời bằng nội dung tài liệu văn bản, dùng markdown rút gọn:\n'
            '# Tiêu đề lớn\n## Tiêu đề nhỏ\n- gạch đầu dòng\ndòng thường = đoạn văn.\n'
            'KHÔNG thêm lời dẫn/giải thích ngoài nội dung tài liệu.');
        break;
      case 'pptx':
        buffer.writeln('Chỉ trả lời bằng nội dung các slide, mỗi slide cách nhau bằng dòng '
            'riêng chứa "---". Trong mỗi slide: dòng đầu "# Tiêu đề slide", các dòng '
            'sau bắt đầu bằng "- " là nội dung gạch đầu dòng. KHÔNG thêm lời dẫn.');
        break;
      case 'xlsx':
        buffer.writeln('Chỉ trả lời bằng dữ liệu dạng bảng, mỗi dòng là 1 hàng, các cột '
            'cách nhau bằng ký tự "|". Dòng đầu tiên là tiêu đề cột. KHÔNG thêm lời dẫn.');
        break;
      case 'zip':
        buffer.writeln('Chỉ trả lời bằng các code block, MỖI file 1 block, đường dẫn file '
            'đặt ngay sau dấu ``` (ví dụ ```lib/main.dart), nội dung file đầy đủ bên trong. '
            'KHÔNG thêm lời dẫn ngoài các code block.');
        break;
    }

    return buffer.toString();
  }
}
