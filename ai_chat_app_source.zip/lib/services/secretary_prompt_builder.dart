import '../models/source_document.dart';

/// Dựng prompt cho tác vụ "thư ký AI": đọc N tài liệu nguồn (upload hoặc
/// trích xuất từ webview) + yêu cầu của người dùng, rồi sinh MỘT bản trả
/// lời cuối cùng theo ĐÚNG cú pháp mà các exporter sẵn có (DocxExporter/
/// PptxExporter/XlsxExporter/CodeZipExporter) hiểu được — để không cần viết
/// thêm exporter mới, và chỉ tốn 1 lần gọi API cho toàn bộ việc tổng hợp.
class SecretaryPromptBuilder {
  /// Chỉ phần "định dạng trả lời bắt buộc" — PUBLIC để dùng làm prompt
  /// "mồi" copy ra ngoài (dán cho 1 AI khác/người khác đọc TRƯỚC KHI họ trả
  /// lời), giống hệt cách CodeZipExporter.formatInstructionPrompt làm cho
  /// riêng zip — giờ áp dụng chung cho cả docx/pptx/xlsx, để nếu bên ngoài
  /// đã trả lời đúng định dạng sẵn, app xuất file THẲNG (0 token), khỏi cần
  /// tự gọi AI để "dịch lại" định dạng.
  /// TIER 3 — dùng khi JSON DSL (Tier 1) không đủ biểu đạt yêu cầu (ví dụ
  /// định dạng quá đặc thù, cần logic phức tạp JSON tĩnh không tả được).
  /// Nhờ 1 AI CÓ SẴN khả năng chạy code (Claude.ai, ChatGPT Code
  /// Interpreter, Google Colab...) tự viết VÀ TỰ CHẠY Python (python-docx/
  /// pptx/openpyxl) trên hạ tầng CỦA HỌ, rồi đưa link tải file kết quả —
  /// app chỉ tải file đã hoàn thiện về (dùng lại đúng cơ chế tải file qua
  /// link ở WebviewCaptureScreen). KHÔNG có bước nào app tự chạy code lạ.
  static String tier3PythonPrompt(String outputFormat) {
    final lib = switch (outputFormat) {
      'docx' => 'python-docx',
      'pptx' => 'python-pptx',
      'xlsx' => 'openpyxl',
      _ => 'thư viện phù hợp',
    };
    return 'Tôi cần 1 file .$outputFormat với nội dung/định dạng phức tạp mà '
        'JSON mô tả tĩnh không đủ biểu đạt. Bạn hãy TỰ VIẾT VÀ TỰ CHẠY code '
        'Python (dùng $lib) ngay trên môi trường thực thi code của bạn để tạo '
        'ra file đó, rồi đưa cho tôi LINK TẢI XUỐNG file đã hoàn thiện '
        '(không phải đưa code cho tôi tự chạy — tôi không có môi trường '
        'chạy Python). Yêu cầu cụ thể: ';
  }

  static String formatInstruction(String outputFormat) {
    switch (outputFormat) {
      case 'docx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất (không thêm '
            'chữ nào khác ngoài JSON) theo đúng schema sau:\n'
            '{"title": "...", "blocks": [\n'
            '  {"type":"heading","level":1,"text":"..."},\n'
            '  {"type":"paragraph","runs":[{"text":"...","bold":true,"italic":false,"color":"#RRGGBB"}]},\n'
            '  {"type":"bullet_list","items":["...","..."]},\n'
            '  {"type":"numbered_list","items":["...","..."]},\n'
            '  {"type":"table","headers":["...","..."],"rows":[["...","..."]]},\n'
            '  {"type":"image","url":"https://...(nếu có ảnh sẵn phù hợp)","prompt":"mô tả ảnh cần tạo (chỉ điền nếu KHÔNG có url sẵn)","caption":"..."},\n'
            '  {"type":"chart","chartType":"bar","title":"...","data":[{"label":"Q1","value":120}]},\n'
            '  {"type":"diagram","shapes":[{"id":1,"label":"Bắt đầu","x":0,"y":0}],"connectors":[{"from":1,"to":2}]},\n'
            '  {"type":"toc"},\n'
            '  {"type":"page_break"}\n'
            ']}\n'
            'Dùng "chart"/"diagram" cho biểu đồ/sơ đồ minh hoạ (tự vẽ ra ảnh, '
            'không cần bạn vẽ). "runs" dùng để in đậm/nghiêng/màu 1 phần câu.';
      case 'pptx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất theo schema:\n'
            '{"slides": [{"title":"...", "bullets":["...","..."], '
            '"images":[{"type":"chart","chartType":"bar","data":[{"label":"Q1","value":120}]}, '
            '{"url":"https://...(nếu có ảnh sẵn)"}, {"prompt":"mô tả ảnh cần tạo (chỉ khi không có url)"}]}]}\n'
            'Mỗi phần tử trong "slides" là 1 slide. "images" tuỳ chọn, dùng '
            '"chart"/"diagram" để tự vẽ biểu đồ/sơ đồ minh hoạ, hoặc "url"/"prompt" cho ảnh minh hoạ khác.';
      case 'xlsx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất theo schema:\n'
            '{"sheets": [{"name":"Sheet1", "rows":[{"cells":[{"value":"Tên","bold":true},{"value":10}]}], '
            '"merges":["A1:B1"]}]}\n'
            'Có thể dùng {"formula":"=SUM(A1:A10)"} thay cho "value" để Excel '
            'tự tính (không tự tính hộ, chỉ ghi công thức vào ô).';
      case 'zip':
        return 'Khi trả lời, với MỖI file dùng đúng cú pháp sau: đặt đường '
            'dẫn file NGAY SAU dấu ``` mở đầu (ví dụ ```lib/main.dart), nội '
            'dung file đầy đủ bên trong khối. KHÔNG thêm lời dẫn ngoài các '
            'code block.';
      default:
        return '';
    }
  }

  static String build({
    required List<SourceDocument> sources,
    required String instruction,
    required String outputFormat, // 'docx' | 'pptx' | 'xlsx' | 'zip'
  }) {
    final buffer = StringBuffer();

    buffer.writeln('Bạn là thư ký tổng hợp tài liệu. Dưới đây là các tài liệu nguồn '
        'do người dùng cung cấp (upload hoặc trích xuất từ trang web họ đang xem). '
        'Đọc kỹ toàn bộ rồi thực hiện đúng yêu cầu bên dưới.');
    buffer.writeln();

    for (var i = 0; i < sources.length; i++) {
      final s = sources[i];
      buffer.writeln('--- TÀI LIỆU NGUỒN ${i + 1}: "${s.title}" (nguồn: ${s.sourceLabel}) ---');
      buffer.writeln(s.content);
      buffer.writeln();
    }

    buffer.writeln('--- YÊU CẦU CỦA NGƯỜI DÙNG ---');
    buffer.writeln(instruction.trim().isEmpty
        ? 'Tổng hợp lại toàn bộ nội dung trên thành 1 tài liệu rõ ràng, đầy đủ.'
        : instruction.trim());
    buffer.writeln();

    buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
    buffer.writeln(formatInstruction(outputFormat));

    return buffer.toString();
  }
}
