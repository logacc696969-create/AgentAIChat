import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';
import 'api_service.dart';
import 'storage_service.dart';
import 'token_estimator.dart';

/// Kết quả build ngữ cảnh: danh sách message thực sự sẽ gửi lên API,
/// kèm số liệu để hiển thị cho người dùng biết app đang "tiết kiệm" bao nhiêu.
class BuiltContext {
  final List<ApiMessage> messages;
  final int estimatedTokens;
  final bool wasSummarized;
  BuiltContext(this.messages, this.estimatedTokens, this.wasSummarized);
}

/// Chiến lược tối ưu token khi hội thoại dài dần / công việc phức tạp dần:
///
/// 1. SLIDING WINDOW: luôn giữ nguyên văn N tin nhắn gần nhất (mặc định 12)
///    để model có đủ ngữ cảnh "nóng" cho lượt trả lời tiếp theo.
///
/// 2. AUTO-SUMMARIZE: khi tổng token ước tính của toàn hội thoại vượt quá
///    một ngưỡng (mặc định 65% maxContextTokens của provider đang dùng),
///    các tin nhắn cũ hơn cửa sổ trượt sẽ được gộp lại và gọi chính model
///    đó để tóm tắt thành 1 đoạn "summary" ngắn gọn, giữ lại các quyết định/
///    dữ kiện quan trọng. Từ lần gửi sau, các tin nhắn gốc đã tóm tắt sẽ
///    KHÔNG được gửi lại nữa — chỉ gửi bản tóm tắt (đánh dấu
///    [collapsedIntoSummary] = true trên message gốc để UI vẫn hiển thị được
///    lịch sử đầy đủ cho người dùng xem lại, nhưng không tốn token API nữa).
///
/// 3. INCREMENTAL SUMMARY: nếu hội thoại tiếp tục dài ra sau khi đã có 1 bản
///    tóm tắt, lần tóm tắt sau sẽ gộp "bản tóm tắt cũ + các tin nhắn mới cũ
///    hơn cửa sổ trượt" thành 1 bản tóm tắt mới duy nhất, tránh tình trạng
///    chồng nhiều summary chunk chiếm token.
///
/// 4. SAFETY MARGIN: luôn chừa 15% ngân sách token cho câu trả lời & sai số
///    ước lượng, không bao giờ build ngữ cảnh sát 100% giới hạn.
class ContextManager {
  static const int slidingWindowSize = 12;
  static const double summarizeTriggerRatio = 0.65;
  static const double safetyMarginRatio = 0.85;

  /// Giới hạn CỨNG độ dài (ký tự) của bản tóm tắt cho MỖI đoạn chat được
  /// liên kết — đảm bảo liên kết không bao giờ đốt token tỉ lệ thuận với độ
  /// dài đoạn chat kia, dù nó dài bao nhiêu.
  static const int linkedSummaryMaxChars = 600;

  /// Chỉ tính lại tóm tắt của 1 link khi đoạn chat kia đã có thêm ÍT NHẤT
  /// ngần này tin nhắn mới kể từ lần cache trước — tránh gọi API tóm tắt
  /// lại liên tục mỗi khi người dùng gõ thêm 1 câu ở đoạn chat được liên kết.
  static const int linkedRefreshThreshold = 5;

  final ApiService _apiService;
  ContextManager(this._apiService);

  /// Kiểm tra xem có cần tóm tắt trước khi gửi lượt tiếp theo không.
  bool needsSummarization(Conversation conversation, ProviderConfig config) {
    final total = _estimateTotal(conversation);
    return total > config.maxContextTokens * summarizeTriggerRatio;
  }

  /// Thực hiện tóm tắt các tin nhắn cũ (nếu cần) rồi cập nhật vào conversation.
  /// Trả về true nếu đã thực hiện tóm tắt.
  Future<bool> summarizeIfNeeded(
    Conversation conversation,
    ProviderConfig config, {
    void Function(ApiUsage usage)? onUsage,
  }) async {
    if (!needsSummarization(conversation, config)) return false;

    final active = conversation.messages.where((m) => !m.collapsedIntoSummary).toList();
    if (active.length <= slidingWindowSize + 1) return false; // chưa đủ dài để tóm tắt

    final toCollapse = active.sublist(0, active.length - slidingWindowSize);
    final existingSummary = toCollapse.firstWhere(
      (m) => m.isSummary,
      orElse: () => ChatMessage(
        id: '',
        role: MessageRole.system,
        content: '',
        createdAt: DateTime.now(),
      ),
    );

    final transcript = toCollapse
        .where((m) => !m.isSummary)
        .map((m) => '${_roleLabel(m.role)}: ${m.content}')
        .join('\n\n');

    final prompt = '''
Hãy tóm tắt đoạn hội thoại sau thành một bản tóm tắt NGẮN GỌN nhưng đầy đủ,
giữ lại: quyết định đã chốt, dữ kiện/số liệu quan trọng, yêu cầu của người
dùng chưa được giải quyết, và ngữ cảnh cần thiết để tiếp tục hội thoại một
cách mạch lạc. Không thêm bình luận, chỉ trả về nội dung tóm tắt.

${existingSummary.content.isNotEmpty ? "BẢN TÓM TẮT TRƯỚC ĐÓ:\n${existingSummary.content}\n\n" : ""}
HỘI THOẠI CẦN TÓM TẮT THÊM:
$transcript
''';

    final summaryText = await _apiService.sendMessageOnce(
      config: config,
      messages: [ApiMessage('user', prompt)],
      onUsage: onUsage,
    );

    // Đánh dấu toàn bộ tin nhắn cũ đã bị gấp vào summary (vẫn giữ trong list
    // để người dùng xem lại lịch sử, nhưng không gửi lên API nữa).
    for (final m in toCollapse) {
      m.collapsedIntoSummary = true;
    }

    conversation.messages.removeWhere((m) => m.isSummary);
    conversation.messages.insert(
      0,
      ChatMessage(
        id: 'summary-${DateTime.now().millisecondsSinceEpoch}',
        role: MessageRole.system,
        content: summaryText,
        createdAt: DateTime.now(),
        isSummary: true,
        approxTokens: TokenEstimator.estimate(summaryText),
      ),
    );

    conversation.liveTokenEstimate = _estimateTotal(conversation);
    return true;
  }

  /// Build danh sách message thực sự sẽ gửi lên API cho lượt hiện tại,
  /// đã áp dụng cửa sổ trượt + safety margin. Gọi HÀM NÀY thay vì gửi thẳng
  /// toàn bộ conversation.messages để tiết kiệm token tối đa.
  BuiltContext buildContext(Conversation conversation, ProviderConfig config) {
    final budget = (config.maxContextTokens * safetyMarginRatio).floor();

    final systemMsg = ApiMessage('system', conversation.systemPrompt);
    int used = TokenEstimator.estimateMessage(conversation.systemPrompt);

    final summary = conversation.messages.where((m) => m.isSummary).toList();
    final active = conversation.messages
        .where((m) => !m.collapsedIntoSummary && !m.isSummary && !m.isSystemNote)
        .toList();

    final result = <ApiMessage>[systemMsg];

    if (summary.isNotEmpty) {
      final s = summary.first;
      result.add(ApiMessage(
        'system',
        'Tóm tắt phần đầu hội thoại (đã lược bớt để tiết kiệm ngữ cảnh):\n${s.content}',
      ));
      used += s.approxTokens ?? TokenEstimator.estimate(s.content);
    }

    // Bối cảnh từ các đoạn chat LIÊN KẾT — luôn ở dạng đã rút gọn cứng
    // (xem refreshLinkedContext), không bao giờ là nội dung gốc đầy đủ.
    if (conversation.linkedContextCache.isNotEmpty) {
      final linkedBlock = conversation.linkedContextCache.values.join('\n\n');
      result.add(ApiMessage(
        'system',
        'Bối cảnh tham khảo từ (các) đoạn chat liên kết (đã rút gọn để tiết kiệm token):\n$linkedBlock',
      ));
      used += TokenEstimator.estimate(linkedBlock);
    }

    // Giữ nguyên văn các tin nhắn gần nhất, tính ngược từ cuối lên cho tới
    // khi chạm ngân sách token còn lại.
    final keep = <ChatMessage>[];
    for (final m in active.reversed) {
      final t = m.approxTokens ?? TokenEstimator.estimateMessage(m.content);
      if (used + t > budget && keep.length >= 2) break; // luôn giữ tối thiểu 2 tin gần nhất
      keep.insert(0, m);
      used += t;
    }

    result.addAll(keep.map((m) {
      // Nếu tin nhắn có gắn tên "người nói" (chế độ nhiều model thảo luận),
      // thêm tiền tố tên vào nội dung để model đang được gọi hiểu đây là
      // phát biểu của MỘT model khác, không phải lượt trả lời trước của
      // chính nó — tránh nhầm lẫn danh tính trong hội thoại nhiều bên.
      final content = m.speakerName != null ? '[${m.speakerName}]: ${m.content}' : m.content;
      return ApiMessage(_roleKey(m.role), content);
    }));

    return BuiltContext(result, used, summary.isNotEmpty);
  }

  /// Cập nhật cache tóm tắt cho MỌI đoạn chat đang được liên kết tới
  /// [conversation] — đây là cơ chế BẮT BUỘC đảm bảo việc liên kết đoạn
  /// chat KHÔNG BAO GIỜ làm phình to token, bất kể đoạn chat được liên kết
  /// dài cỡ nào:
  ///
  /// 1. Nếu đoạn chat kia ĐÃ có sẵn bản tóm tắt tự động của riêng nó (do nó
  ///    đủ dài để tự kích hoạt auto-summarize) → TÁI SỬ DỤNG NGUYÊN VẸN,
  ///    không tốn thêm request nào.
  /// 2. Nếu đoạn chat kia còn ngắn (≤4 tin nhắn) → lấy nguyên văn (đã ngắn
  ///    sẵn), cũng không cần gọi API.
  /// 3. Chỉ khi đoạn chat kia dài nhưng CHƯA từng tự tóm tắt, mới gọi 1 API
  ///    request tóm tắt cực ngắn (≤100 từ) — và kết quả được CACHE lại.
  /// 4. Mọi bản tóm tắt (dù lấy từ đâu) đều bị CẮT CỨNG còn tối đa
  ///    [linkedSummaryMaxChars] ký tự trước khi lưu vào cache.
  /// 5. Cache chỉ được tính lại khi đoạn chat kia đã có thêm ≥
  ///    [linkedRefreshThreshold] tin nhắn mới kể từ lần cache trước — nếu
  ///    không, dùng lại cache cũ, HOÀN TOÀN không gọi API.
  ///
  /// Kết quả: chi phí token cho việc liên kết bị chặn trên ở một hằng số cố
  /// định nhân với số lượng đoạn chat được liên kết — KHÔNG BAO GIỜ tỉ lệ
  /// thuận với độ dài từng đoạn chat đó.
  Future<void> refreshLinkedContext(
    Conversation conversation,
    StorageService storage,
    ProviderConfig config,
  ) async {
    // Dọn cache của các link đã bị gỡ khỏi danh sách.
    conversation.linkedContextCache.removeWhere(
      (id, _) => !conversation.linkedConversationIds.contains(id),
    );
    conversation.linkedContextCacheVersion.removeWhere(
      (id, _) => !conversation.linkedConversationIds.contains(id),
    );

    for (final linkedId in conversation.linkedConversationIds) {
      Conversation? linked;
      try {
        linked = storage.conversations.get(linkedId);
      } catch (_) {
        linked = null;
      }
      if (linked == null) {
        conversation.linkedContextCache.remove(linkedId);
        conversation.linkedContextCacheVersion.remove(linkedId);
        continue;
      }

      final currentCount = linked.messages.length;
      final cachedCount = conversation.linkedContextCacheVersion[linkedId] ?? -1;
      final hasCache = conversation.linkedContextCache.containsKey(linkedId);

      if (hasCache && (currentCount - cachedCount) < linkedRefreshThreshold) {
        continue; // cache còn dùng tốt, không gọi API
      }

      String summaryText;
      final existingSummary = linked.messages.where((m) => m.isSummary).toList();
      if (existingSummary.isNotEmpty) {
        summaryText = existingSummary.first.content;
      } else if (currentCount <= 4) {
        summaryText = linked.messages
            .where((m) => !m.isSystemNote)
            .map((m) => '${_roleLabel(m.role)}: ${m.content}')
            .join('\n');
      } else {
        final transcript = linked.messages
            .where((m) => !m.isSystemNote && !m.collapsedIntoSummary)
            .map((m) => '${_roleLabel(m.role)}: ${m.content}')
            .join('\n');
        try {
          summaryText = await _apiService.sendMessageOnce(
            config: config,
            messages: [
              ApiMessage(
                'user',
                'Tóm tắt CỰC NGẮN GỌN (tối đa 100 từ) đoạn hội thoại sau, chỉ '
                    'giữ đúng ý chính/kết luận, không thêm bình luận:\n$transcript',
              ),
            ],
          );
        } catch (_) {
          // Lỗi mạng khi tóm tắt link -> bỏ qua lần này, giữ cache cũ nếu có
          continue;
        }
      }

      final capped = summaryText.length > linkedSummaryMaxChars
          ? '${summaryText.substring(0, linkedSummaryMaxChars)}...'
          : summaryText;
      conversation.linkedContextCache[linkedId] = '### Liên kết "${linked.title}":\n$capped';
      conversation.linkedContextCacheVersion[linkedId] = currentCount;
    }
  }

  int _estimateTotal(Conversation conversation) {
    int total = TokenEstimator.estimate(conversation.systemPrompt);
    for (final linkedText in conversation.linkedContextCache.values) {
      total += TokenEstimator.estimate(linkedText);
    }
    for (final m in conversation.messages) {
      if (m.isSystemNote) continue; // mốc chuyển model: hiển thị UI, không tốn token
      if (m.collapsedIntoSummary && !m.isSummary) continue;
      total += m.approxTokens ?? TokenEstimator.estimateMessage(m.content);
    }
    return total;
  }

  /// Gọi khi người dùng CHUYỂN SANG MODEL KHÁC giữa chừng đoạn chat.
  ///
  /// Điểm mấu chốt tiết kiệm token: hàm này KHÔNG gửi lại toàn bộ lịch sử
  /// cho model mới. Nó chỉ:
  ///   1. Chèn 1 tin nhắn "mốc" (isSystemNote) để người dùng thấy trực quan
  ///      điểm chuyển đổi — tin nhắn này không được tính token.
  ///   2. Kiểm tra bản tóm tắt hiện có (nếu có) còn phù hợp với giới hạn
  ///      ngữ cảnh của model MỚI hay không:
  ///      - Nếu model mới có ngữ cảnh lớn hơn hoặc bằng model cũ: TÁI SỬ
  ///        DỤNG NGUYÊN VẸN bản tóm tắt đã có, không tốn thêm 1 token API
  ///        nào để tóm tắt lại.
  ///      - Nếu model mới có ngữ cảnh nhỏ hơn đáng kể (ví dụ chuyển từ model
  ///        200K xuống model 8K), mới cần tóm tắt lại (nén thêm) — và khi đó
  ///        sẽ tóm tắt DỰA TRÊN bản tóm tắt cũ (rẻ hơn nhiều so với tóm tắt
  ///        lại từ đầu toàn bộ lịch sử gốc).
  /// Nhờ vậy, lượt gửi đầu tiên cho model mới có chi phí token tương đương
  /// (hoặc RẺ HƠN) lượt gửi cuối cùng cho model cũ — không bao giờ "đốt"
  /// nhiều token hơn để tiếp tục.
  Future<void> switchModel(
    Conversation conversation,
    ProviderConfig oldProvider,
    ProviderConfig newProvider,
  ) async {
    final noteId = 'switch-${DateTime.now().millisecondsSinceEpoch}';
    conversation.messages.add(ChatMessage(
      id: noteId,
      role: MessageRole.system,
      content: 'Đã chuyển từ "${oldProvider.name}" sang "${newProvider.name}" — '
          'tiếp tục nguyên ngữ cảnh, không phải giải thích lại.',
      createdAt: DateTime.now(),
      isSystemNote: true,
    ));

    // Nếu model mới có ngữ cảnh nhỏ hơn hẳn (< 90% model cũ) và hội thoại
    // hiện đã vượt ngưỡng tóm tắt của model mới, thì tóm tắt (nén thêm) NGAY
    // trước khi người dùng nhắn tiếp — để lượt gửi đầu tiên cho model mới
    // không bị lỗi "vượt giới hạn ngữ cảnh" và vẫn tối ưu token nhất có thể.
    final newBudgetSmaller = newProvider.maxContextTokens < oldProvider.maxContextTokens * 0.9;
    if (newBudgetSmaller && needsSummarization(conversation, newProvider)) {
      await summarizeIfNeeded(conversation, newProvider);
    }
    // Ngược lại (model mới >= model cũ): CHỦ ĐỘNG KHÔNG gọi tóm tắt lại —
    // bản tóm tắt + sliding window hiện có được tái sử dụng nguyên vẹn ở
    // buildContext(), tiết kiệm toàn bộ chi phí token của một lượt tóm tắt.
  }

  String _roleKey(MessageRole r) {
    switch (r) {
      case MessageRole.system:
        return 'system';
      case MessageRole.user:
        return 'user';
      case MessageRole.assistant:
        return 'assistant';
    }
  }

  String _roleLabel(MessageRole r) {
    switch (r) {
      case MessageRole.system:
        return 'Hệ thống';
      case MessageRole.user:
        return 'Người dùng';
      case MessageRole.assistant:
        return 'Trợ lý';
    }
  }
}
