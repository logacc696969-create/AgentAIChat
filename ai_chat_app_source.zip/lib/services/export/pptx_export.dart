import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .pptx tối giản nhưng hợp lệ.
///
/// CÓ 2 CÁCH GỌI:
///  1. [export] — cú pháp markdown rút gọn cũ (giữ nguyên).
///  2. [exportJson] — JSON DSL MỚI: mỗi slide có title/bullets/images.
///     {"slides": [{"title":"...", "bullets":["...","..."], "images":[{"imageId":"img1","widthCm":10}]}]}
class PptxExporter {
  static List<int> export(String slidesMarkdown) {
    final rawSlides = slidesMarkdown.split(RegExp(r'\n-{3,}\n'));
    final slides = rawSlides.where((s) => s.trim().isNotEmpty).toList();
    if (slides.isEmpty) slides.add('# (Trống)');

    final parsed = <_SlideData>[];
    for (final s in slides) {
      final lines = s.trim().split('\n');
      final title = lines.isNotEmpty && lines.first.startsWith('#')
          ? lines.first.replaceFirst(RegExp(r'^#+\s*'), '')
          : 'Slide';
      final bullets = lines
          .skip(lines.first.startsWith('#') ? 1 : 0)
          .where((l) => l.trim().isNotEmpty)
          .map((l) => l.trim().replaceFirst(RegExp(r'^-\s*'), ''))
          .toList();
      parsed.add(_SlideData(title: title, bullets: bullets, imageIds: const []));
    }
    return _buildPptx(parsed, images: const {});
  }

  /// [images]: map từ id ảnh (khớp với "imageId" trong JSON) sang bytes PNG.
  static List<int>? exportJson(Map<String, dynamic> pres, {Map<String, List<int>> images = const {}}) {
    try {
      final slidesRaw = (pres['slides'] as List?) ?? const [];
      final slides = <_SlideData>[];
      for (final raw in slidesRaw) {
        if (raw is! Map) continue;
        final title = raw['title']?.toString() ?? 'Slide';
        final bullets = (raw['bullets'] as List? ?? const []).map((e) => e.toString()).toList();
        final imgList = (raw['images'] as List? ?? const [])
            .map((e) => (e as Map)['imageId']?.toString() ?? '')
            .where((s) => s.isNotEmpty)
            .toList();
        slides.add(_SlideData(title: title, bullets: bullets, imageIds: imgList));
      }
      if (slides.isEmpty) return null;
      return _buildPptx(slides, images: images);
    } catch (_) {
      return null;
    }
  }

  static String _esc(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static List<int> _buildPptx(List<_SlideData> slides, {required Map<String, List<int>> images}) {
    final archive = Archive();
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    final usesImages = images.isNotEmpty;
    add('[Content_Types].xml', _contentTypes(slides.length, usesImages));
    add('_rels/.rels', _rootRels);
    add('ppt/presentation.xml', _presentationXml(slides.length));
    add('ppt/_rels/presentation.xml.rels', _presentationRels(slides.length));

    var imgCounter = 0;
    final usedImageNames = <String>{};
    for (int i = 0; i < slides.length; i++) {
      final slide = slides[i];
      final slideImageRels = <String>[];
      final slidePics = StringBuffer();
      for (final imgId in slide.imageIds) {
        final bytes = images[imgId];
        if (bytes == null) continue;
        imgCounter++;
        final name = 'image$imgCounter.png';
        if (!usedImageNames.contains(name)) {
          archive.addFile(ArchiveFile('ppt/media/$name', bytes.length, bytes));
          usedImageNames.add(name);
        }
        final rId = 'rIdImg$imgCounter';
        slideImageRels.add(
          '<Relationship Id="$rId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/$name"/>',
        );
        slidePics.write(_pictureShape(rId, 100 + imgCounter));
      }

      add('ppt/slides/slide${i + 1}.xml', _slideXml(slide.title, slide.bullets, slidePics.toString()));
      add('ppt/slides/_rels/slide${i + 1}.xml.rels', _slideRels(slideImageRels));
    }

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }

  static String _contentTypes(int n, bool usesImages) {
    final overrides = List.generate(
      n,
      (i) => '<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>',
    ).join();
    final pngDefault = usesImages ? '<Default Extension="png" ContentType="image/png"/>' : '';
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  $pngDefault
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  $overrides
</Types>''';
  }

  static const _rootRels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>''';

  static String _presentationXml(int n) {
    final sldIds = List.generate(
      n,
      (i) => '<p:sldId id="${256 + i}" r:id="rId${i + 2}"/>',
    ).join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:sldIdLst>$sldIds</p:sldIdLst>
  <p:sldSz cx="9144000" cy="6858000"/>
  <p:notesSz cx="6858000" cy="9144000"/>
</p:presentation>''';
  }

  static String _presentationRels(int n) {
    final rels = List.generate(
      n,
      (i) => '<Relationship Id="rId${i + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>',
    ).join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$rels</Relationships>''';
  }

  static String _slideRels(List<String> imageRels) {
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${imageRels.join()}</Relationships>''';
  }

  static String _pictureShape(String rId, int shapeId) {
    // Đặt ảnh dưới phần bullet, kích thước vừa phải mặc định — người dùng
    // có thể tự kéo chỉnh lại trong PowerPoint sau khi mở.
    return '''<p:pic>
      <p:nvPicPr><p:cNvPr id="$shapeId" name="Picture$shapeId"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr>
      <p:blipFill><a:blip r:embed="$rId"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>
      <p:spPr><a:xfrm><a:off x="1600200" y="3500000"/><a:ext cx="5943600" cy="3200400"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>
    </p:pic>''';
  }

  static String _slideXml(String title, List<String> bullets, String picsXml) {
    final bulletParas = bullets
        .map((b) => '<a:p><a:r><a:rPr lang="vi-VN" sz="2000"/><a:t>${_esc(b)}</a:t></a:r></a:p>')
        .join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr/>
      <p:sp>
        <p:nvSpPr><p:cNvPr id="2" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="457200" y="274638"/><a:ext cx="8229600" cy="1143000"/></a:xfrm></p:spPr>
        <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="vi-VN" sz="3200" b="1"/><a:t>${_esc(title)}</a:t></a:r></a:p></p:txBody>
      </p:sp>
      <p:sp>
        <p:nvSpPr><p:cNvPr id="3" name="Content"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="457200" y="1600200"/><a:ext cx="8229600" cy="1700000"/></a:xfrm></p:spPr>
        <p:txBody><a:bodyPr/><a:lstStyle/>$bulletParas</p:txBody>
      </p:sp>
      $picsXml
    </p:spTree>
  </p:cSld>
</p:sld>''';
  }
}

class _SlideData {
  final String title;
  final List<String> bullets;
  final List<String> imageIds;
  _SlideData({required this.title, required this.bullets, required this.imageIds});
}
