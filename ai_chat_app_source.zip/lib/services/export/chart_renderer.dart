import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

/// Vẽ biểu đồ (cột/đường) và sơ đồ khối (box + mũi tên) bằng
/// [CustomPainter] THUẦN HÌNH HỌC — chỉ vẽ hình chữ nhật/đường thẳng/text
/// theo toạ độ và số liệu trong JSON, KHÔNG có bước nào "thực thi" nội dung
/// nào cả, nên an toàn dù dữ liệu đầu vào có sai/lạ tới đâu (cùng mức an
/// toàn như đọc 1 file ảnh bất kỳ).
///
/// Dùng [RepaintBoundary.toImage] (kỹ thuật đã dùng cho tính năng OCR ở
/// WebviewCaptureScreen) để chụp widget đã vẽ thành PNG — cần 1
/// [BuildContext] đang có [Overlay] (ví dụ từ 1 màn hình thật đang mở),
/// vì Flutter cần thực sự render 1 frame để chụp được.
class ChartRenderer {
  /// Render 1 block chart/diagram thành PNG bytes. [block] là Map JSON
  /// dạng {"type":"chart","chartType":"bar","data":[{"label":"Q1","value":120}]}
  /// hoặc {"type":"diagram","shapes":[...],"connectors":[...]}.
  static Future<Uint8List?> renderToPng(BuildContext context, Map<String, dynamic> block) async {
    final type = block['type'] as String?;
    Widget painterWidget;
    const size = Size(900, 560);

    if (type == 'chart') {
      final chartType = block['chartType'] as String? ?? 'bar';
      final data = (block['data'] as List? ?? const [])
          .map((e) => _ChartPoint(
                label: (e as Map)['label']?.toString() ?? '',
                value: (e['value'] as num?)?.toDouble() ?? 0,
              ))
          .toList();
      painterWidget = CustomPaint(
        size: size,
        painter: _ChartPainter(chartType: chartType, points: data, title: block['title']?.toString()),
      );
    } else if (type == 'diagram') {
      final shapes = (block['shapes'] as List? ?? const [])
          .map((e) => _DiagramShape(
                id: (e as Map)['id'] as int? ?? 0,
                label: e['label']?.toString() ?? '',
                x: (e['x'] as num?)?.toDouble() ?? 0,
                y: (e['y'] as num?)?.toDouble() ?? 0,
              ))
          .toList();
      final connectors = (block['connectors'] as List? ?? const [])
          .map((e) => _DiagramConnector(
                from: (e as Map)['from'] as int? ?? 0,
                to: e['to'] as int? ?? 0,
              ))
          .toList();
      painterWidget = CustomPaint(
        size: size,
        painter: _DiagramPainter(shapes: shapes, connectors: connectors),
      );
    } else {
      return null;
    }

    return _captureWidget(context, painterWidget, size);
  }

  /// Chèn widget vào 1 [OverlayEntry] TẠM THỜI (đặt hẳn ra ngoài vùng hiển
  /// thị — người dùng không thấy gì nhấp nháy), đợi vài frame để Flutter
  /// render xong, chụp bằng [RepaintBoundary], rồi gỡ overlay ra ngay.
  static Future<Uint8List?> _captureWidget(BuildContext context, Widget child, Size size) async {
    final key = GlobalKey();
    final overlay = Overlay.of(context, rootOverlay: true);
    late OverlayEntry entry;
    final completer = Completer<Uint8List?>();

    entry = OverlayEntry(
      builder: (_) => Positioned(
        left: -size.width - 100,
        top: 0,
        child: Material(
          color: Colors.white,
          child: RepaintBoundary(
            key: key,
            child: SizedBox(width: size.width, height: size.height, child: child),
          ),
        ),
      ),
    );
    overlay.insert(entry);

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(milliseconds: 100));
      try {
        final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
        if (boundary == null) {
          completer.complete(null);
        } else {
          final image = await boundary.toImage(pixelRatio: 2.0);
          final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
          completer.complete(byteData?.buffer.asUint8List());
        }
      } catch (_) {
        completer.complete(null);
      } finally {
        entry.remove();
      }
    });

    return completer.future;
  }
}

class _ChartPoint {
  final String label;
  final double value;
  _ChartPoint({required this.label, required this.value});
}

class _DiagramShape {
  final int id;
  final String label;
  final double x, y;
  _DiagramShape({required this.id, required this.label, required this.x, required this.y});
}

class _DiagramConnector {
  final int from, to;
  _DiagramConnector({required this.from, required this.to});
}

class _ChartPainter extends CustomPainter {
  final String chartType;
  final List<_ChartPoint> points;
  final String? title;
  _ChartPainter({required this.chartType, required this.points, this.title});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = Colors.white);
    if (points.isEmpty) return;

    const padding = 60.0;
    final topOffset = title != null ? 50.0 : padding;
    final chartArea = Rect.fromLTWH(padding, topOffset, size.width - padding * 2, size.height - padding - topOffset);
    final maxValue = points.map((p) => p.value).reduce((a, b) => a > b ? a : b);
    final safeMax = maxValue <= 0 ? 1.0 : maxValue;

    if (title != null) {
      _drawText(canvas, title!, Offset(size.width / 2, 24), fontSize: 22, bold: true, center: true);
    }

    final axisPaint = Paint()
      ..color = Colors.black87
      ..strokeWidth = 2;
    canvas.drawLine(Offset(chartArea.left, chartArea.top), Offset(chartArea.left, chartArea.bottom), axisPaint);
    canvas.drawLine(Offset(chartArea.left, chartArea.bottom), Offset(chartArea.right, chartArea.bottom), axisPaint);

    final colors = [Colors.blue, Colors.orange, Colors.green, Colors.purple, Colors.red, Colors.teal];

    if (chartType == 'line') {
      final stepX = chartArea.width / (points.length > 1 ? points.length - 1 : 1);
      final path = Path();
      for (var i = 0; i < points.length; i++) {
        final x = chartArea.left + stepX * i;
        final y = chartArea.bottom - (points[i].value / safeMax) * chartArea.height;
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
        canvas.drawCircle(Offset(x, y), 5, Paint()..color = Colors.blue);
        _drawText(canvas, points[i].label, Offset(x, chartArea.bottom + 8), fontSize: 14, center: true);
        _drawText(canvas, points[i].value.toStringAsFixed(0), Offset(x, y - 22), fontSize: 13, center: true);
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = Colors.blue
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      );
    } else {
      final stepX = chartArea.width / points.length;
      final barWidth = stepX * 0.6;
      for (var i = 0; i < points.length; i++) {
        final barHeight = (points[i].value / safeMax) * chartArea.height;
        final left = chartArea.left + stepX * i + (stepX - barWidth) / 2;
        final rect = Rect.fromLTWH(left, chartArea.bottom - barHeight, barWidth, barHeight);
        canvas.drawRect(rect, Paint()..color = colors[i % colors.length]);
        _drawText(canvas, points[i].label, Offset(left + barWidth / 2, chartArea.bottom + 8), fontSize: 14, center: true);
        _drawText(canvas, points[i].value.toStringAsFixed(0), Offset(left + barWidth / 2, chartArea.bottom - barHeight - 20), fontSize: 13, center: true);
      }
    }
  }

  void _drawText(Canvas canvas, String text, Offset pos, {double fontSize = 14, bool bold = false, bool center = false}) {
    final painter = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: Colors.black87, fontSize: fontSize, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout();
    final offset = center ? Offset(pos.dx - painter.width / 2, pos.dy) : pos;
    painter.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class _DiagramPainter extends CustomPainter {
  final List<_DiagramShape> shapes;
  final List<_DiagramConnector> connectors;
  _DiagramPainter({required this.shapes, required this.connectors});

  static const boxW = 160.0, boxH = 60.0;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = Colors.white);
    final byId = {for (final s in shapes) s.id: s};

    final linePaint = Paint()
      ..color = Colors.black54
      ..strokeWidth = 2;
    for (final c in connectors) {
      final from = byId[c.from];
      final to = byId[c.to];
      if (from == null || to == null) continue;
      final p1 = Offset(from.x + boxW / 2, from.y + boxH);
      final p2 = Offset(to.x + boxW / 2, to.y);
      canvas.drawLine(p1, p2, linePaint);
      _drawArrowHead(canvas, p1, p2, linePaint);
    }

    for (final s in shapes) {
      final rect = Rect.fromLTWH(s.x, s.y, boxW, boxH);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(8)),
        Paint()..color = Colors.blue.shade50,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(8)),
        Paint()
          ..color = Colors.blue.shade700
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
      final painter = TextPainter(
        text: TextSpan(text: s.label, style: const TextStyle(color: Colors.black87, fontSize: 15)),
        textDirection: TextDirection.ltr,
        textAlign: TextAlign.center,
      )..layout(maxWidth: boxW - 16);
      painter.paint(canvas, Offset(rect.center.dx - painter.width / 2, rect.center.dy - painter.height / 2));
    }
  }

  void _drawArrowHead(Canvas canvas, Offset from, Offset to, Paint paint) {
    final angle = (to - from).direction;
    const arrowSize = 10.0;
    final p1 = to - Offset.fromDirection(angle - 0.5, arrowSize);
    final p2 = to - Offset.fromDirection(angle + 0.5, arrowSize);
    canvas.drawLine(to, p1, paint);
    canvas.drawLine(to, p2, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
