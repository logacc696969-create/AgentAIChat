import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .docx hợp lệ (định dạng OOXML) mà KHÔNG cần thư viện Word nào,
/// bằng cách tự dựng cấu trúc zip + XML tối thiểu mà Word/LibreOffice/Google
/// Docs đều đọc được.
///
/// CÓ 2 CÁCH GỌI:
///  1. [export] — cú pháp markdown rút gọn cũ (giữ nguyên, không đổi, các
///     nơi đang dùng không bị ảnh hưởng).
///  2. [exportJson] — JSON DSL MỚI, giàu định dạng hơn hẳn: đậm/nghiêng/màu
///     chữ trong 1 đoạn, bảng thật (không phải text `|`), chèn ảnh, mục lục
///     tự động (Word tự tính số trang). Vẫn 100% KHAI BÁO (declarative) —
///     JSON chỉ mô tả NỘI DUNG cần có, không có chỗ nào "thực thi" gì cả,
///     nên an toàn y hệt cách cũ dù nội dung JSON có sai/lạ tới đâu.
///
/// Schema JSON DSL (xem thêm doc_dsl_notes.md nếu cần):
/// {
///   "title": "...",
///   "blocks": [
///     {"type": "heading", "level": 1, "text": "..."},
///     {"type": "paragraph", "runs": [{"text":"...", "bold":true, "italic":false, "color":"#RRGGBB"}]},
///     {"type": "bullet_list", "items": ["...", "..."]},
///     {"type": "numbered_list", "items": ["...", "..."]},
///     {"type": "table", "headers": ["...", "..."], "rows": [["...", "..."]]},
///     {"type": "image", "base64": "...", "caption": "...", "widthCm": 12},
///     {"type": "toc"},
///     {"type": "page_break"}
///   ]
/// }
class DocxExporter {
  static List<int> export({required String title, required String markdownLike}) {
    final bodyXml = StringBuffer();

    for (final rawLine in markdownLike.split('\n')) {
      final line = rawLine.trimRight();
      if (line.trim().isEmpty) {
        bodyXml.write('<w:p/>');
        continue;
      }
      if (line.startsWith('## ')) {
        bodyXml.write(_paragraph(_esc(line.substring(3)), style: 'Heading2'));
      } else if (line.startsWith('# ')) {
        bodyXml.write(_paragraph(_esc(line.substring(2)), style: 'Heading1'));
      } else if (line.trimLeft().startsWith('- ')) {
        bodyXml.write(_paragraph('•  ${_esc(line.trimLeft().substring(2))}'));
      } else if (RegExp(r'^\d+\.\s').hasMatch(line.trimLeft())) {
        bodyXml.write(_paragraph(_esc(line.trimLeft())));
      } else {
        bodyXml.write(_paragraph(_esc(line)));
      }
    }

    final documentXml = _wrapDocument(_paragraph(_esc(title), style: 'Title') + bodyXml.toString());
    return _buildZip(documentXml, images: const {});
  }

  /// [images]: map từ id ảnh (dùng nội bộ, ví dụ "img1") sang bytes PNG —
  /// lấy từ block {"type":"image", ...} đã được xử lý trước đó (giải mã
  /// base64 hoặc tải về từ URL) rồi truyền vào đây.
  static List<int>? exportJson(Map<String, dynamic> doc, {Map<String, List<int>> images = const {}}) {
    try {
      final title = (doc['title'] as String?) ?? 'Tài liệu';
      final blocks = (doc['blocks'] as List?) ?? const [];
      final bodyXml = StringBuffer();
      bodyXml.write(_paragraph(_esc(title), style: 'Title'));

      var imgCounter = 0;
      var hasToc = false;
      final relationships = <String>[]; // XML <Relationship .../> cho mỗi ảnh
      final contentTypeOverrides = <String>[];
      final mediaFiles = <String, List<int>>{};

      for (final raw in blocks) {
        if (raw is! Map) continue;
        final block = raw;
        final type = block['type'] as String? ?? '';
        switch (type) {
          case 'heading':
            final level = (block['level'] as num?)?.toInt() ?? 1;
            final style = level <= 1 ? 'Heading1' : 'Heading2';
            bodyXml.write(_paragraph(_esc(block['text']?.toString() ?? ''), style: style));
            break;
          case 'paragraph':
            bodyXml.write(_paragraphWithRuns(block['runs']));
            break;
          case 'bullet_list':
            for (final item in (block['items'] as List? ?? const [])) {
              bodyXml.write(_paragraph('•  ${_esc(item.toString())}'));
            }
            break;
          case 'numbered_list':
            final items = (block['items'] as List? ?? const []);
            for (var i = 0; i < items.length; i++) {
              bodyXml.write(_paragraph('${i + 1}.  ${_esc(items[i].toString())}'));
            }
            break;
          case 'table':
            bodyXml.write(_table(
              (block['headers'] as List? ?? const []).map((e) => e.toString()).toList(),
              (block['rows'] as List? ?? const [])
                  .map((r) => (r as List).map((c) => c.toString()).toList())
                  .toList(),
            ));
            break;
          case 'image':
            imgCounter++;
            final id = 'img$imgCounter';
            final bytes = images[block['imageId']] ?? images[id];
            if (bytes != null) {
              mediaFiles['word/media/$id.png'] = bytes;
              final rId = 'rIdImg$imgCounter';
              relationships.add(
                '<Relationship Id="$rId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/$id.png"/>',
              );
              if (imgCounter == 1) {
                contentTypeOverrides.add('<Default Extension="png" ContentType="image/png"/>');
              }
              final widthCm = (block['widthCm'] as num?)?.toDouble() ?? 14.0;
              final emu = (widthCm * 360000).round(); // 1cm = 360000 EMU
              bodyXml.write(_imageParagraph(rId, emu, id));
              final caption = block['caption']?.toString();
              if (caption != null && caption.isNotEmpty) {
                bodyXml.write(_paragraph(_esc(caption), style: 'Caption'));
              }
            }
            break;
          case 'toc':
            hasToc = true;
            bodyXml.write(_tocField());
            break;
          case 'page_break':
            bodyXml.write('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
            break;
        }
      }

      final documentXml = _wrapDocument(bodyXml.toString());
      return _buildZip(
        documentXml,
        images: mediaFiles,
        extraImageRelationships: relationships,
        extraContentTypeOverrides: contentTypeOverrides,
        hasToc: hasToc,
      );
    } catch (_) {
      return null;
    }
  }

  static String _wrapDocument(String bodyXml) {
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    $bodyXml
    <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417"/></w:sectPr>
  </w:body>
</w:document>''';
  }

  static String _paragraph(String text, {String? style}) {
    final styleTag = style != null ? '<w:pPr><w:pStyle w:val="$style"/></w:pPr>' : '';
    return '<w:p>$styleTag<w:r><w:t xml:space="preserve">$text</w:t></w:r></w:p>';
  }

  /// Đoạn văn với nhiều "run" (đoạn chữ nhỏ có định dạng riêng: đậm/nghiêng/
  /// màu) trong CÙNG 1 dòng — ví dụ "Đây là **quan trọng** cần chú ý."
  static String _paragraphWithRuns(dynamic runsRaw) {
    if (runsRaw is! List || runsRaw.isEmpty) return '<w:p/>';
    final runsXml = StringBuffer();
    for (final r in runsRaw) {
      if (r is! Map) continue;
      final text = _esc(r['text']?.toString() ?? '');
      final bold = r['bold'] == true;
      final italic = r['italic'] == true;
      final color = r['color']?.toString();
      final rPr = StringBuffer();
      if (bold || italic || color != null) {
        rPr.write('<w:rPr>');
        if (bold) rPr.write('<w:b/>');
        if (italic) rPr.write('<w:i/>');
        if (color != null) rPr.write('<w:color w:val="${color.replaceAll('#', '')}"/>');
        rPr.write('</w:rPr>');
      }
      runsXml.write('<w:r>$rPr<w:t xml:space="preserve">$text</w:t></w:r>');
    }
    return '<w:p>$runsXml</w:p>';
  }

  /// Bảng THẬT (w:tbl) — khác hẳn cách cũ ghi text có dấu `|`, đây là cấu
  /// trúc bảng chuẩn OOXML, Word hiển thị đúng như bảng thật, kẻ được viền.
  static String _table(List<String> headers, List<List<String>> rows) {
    final buf = StringBuffer();
    buf.write('<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/></w:tblPr>');
    if (headers.isNotEmpty) {
      buf.write('<w:tr>');
      for (final h in headers) {
        buf.write('<w:tc><w:tcPr><w:shd w:fill="D9D9D9"/></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">${_esc(h)}</w:t></w:r></w:p></w:tc>');
      }
      buf.write('</w:tr>');
    }
    for (final row in rows) {
      buf.write('<w:tr>');
      for (final cell in row) {
        buf.write('<w:tc><w:p><w:r><w:t xml:space="preserve">${_esc(cell)}</w:t></w:r></w:p></w:tc>');
      }
      buf.write('</w:tr>');
    }
    buf.write('</w:tbl><w:p/>');
    return buf.toString();
  }

  static String _imageParagraph(String rId, int emuWidth, String docPrName) {
    // Giữ tỉ lệ đơn giản: chiều cao = 2/3 chiều rộng (đủ dùng cho hầu hết
    // ảnh minh hoạ/biểu đồ — không cần biết trước kích thước ảnh gốc).
    final emuHeight = (emuWidth * 2 / 3).round();
    return '''<w:p><w:r><w:drawing>
      <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">
        <wp:extent cx="$emuWidth" cy="$emuHeight"/>
        <wp:docPr id="1" name="$docPrName"/>
        <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
          <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
            <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:nvPicPr><pic:cNvPr id="0" name="$docPrName"/><pic:cNvPicPr/></pic:nvPicPr>
              <pic:blipFill><a:blip r:embed="$rId"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>
              <pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$emuWidth" cy="$emuHeight"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>
            </pic:pic>
          </a:graphicData>
        </a:graphic>
      </wp:inline>
    </w:drawing></w:r></w:p>''';
  }

  /// Trường Mục lục (TOC field) — Word TỰ tính số trang và cập nhật khi mở
  /// file (chỉ Word mới biết chính xác ngắt trang ở đâu, app không thể tự
  /// đoán). Word sẽ hỏi "Cập nhật trường?" khi mở, hoặc tự cập nhật tuỳ cấu
  /// hình — đây là hành vi chuẩn, không phải lỗi.
  static String _tocField() {
    return '''<w:p><w:r><w:fldChar w:fldCharType="begin"/></w:r>
      <w:r><w:instrText xml:space="preserve"> TOC \\o "1-3" \\h \\z \\u </w:instrText></w:r>
      <w:r><w:fldChar w:fldCharType="separate"/></w:r>
      <w:r><w:t>Nhấn F9 hoặc mở bằng Word để cập nhật Mục lục</w:t></w:r>
      <w:r><w:fldChar w:fldCharType="end"/></w:r>
    </w:p>''';
  }

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static List<int> _buildZip(
    String documentXml, {
    required Map<String, List<int>> images,
    List<String> extraImageRelationships = const [],
    List<String> extraContentTypeOverrides = const [],
    bool hasToc = false,
  }) {
    final archive = Archive();
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    add('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  ${extraContentTypeOverrides.join()}
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>''');

    add('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''');

    add('word/_rels/document.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  ${extraImageRelationships.join()}
</Relationships>''');

    add('word/styles.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:rPr><w:b/><w:sz w:val="48"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="Heading 1"/><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="Heading 2"/><w:rPr><w:b/><w:sz w:val="26"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Caption"><w:name w:val="Caption"/><w:rPr><w:i/><w:sz w:val="20"/><w:color w:val="595959"/></w:rPr></w:style>
  <w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:tblPr><w:tblBorders>
    <w:top w:val="single" w:sz="4" w:color="auto"/><w:left w:val="single" w:sz="4" w:color="auto"/>
    <w:bottom w:val="single" w:sz="4" w:color="auto"/><w:right w:val="single" w:sz="4" w:color="auto"/>
    <w:insideH w:val="single" w:sz="4" w:color="auto"/><w:insideV w:val="single" w:sz="4" w:color="auto"/>
  </w:tblBorders></w:tblPr></w:style>
</w:styles>''');

    add('word/document.xml', documentXml);

    for (final entry in images.entries) {
      archive.addFile(ArchiveFile(entry.key, entry.value.length, entry.value));
    }

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }
}
