import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../models/provider_config.dart';
import '../image_gen_service.dart';
import 'chart_renderer.dart';
import 'docx_export.dart';
import 'pptx_export.dart';
import 'xlsx_export.dart';

/// Tiền xử lý JSON DSL trước khi đưa cho exporter: với mỗi block
/// {"type":"chart"/"diagram"} → vẽ bằng [ChartRenderer] thành PNG; với
/// block {"type":"image", ...} → lấy ảnh theo ĐÚNG THỨ TỰ ƯU TIÊN (để tiết
/// kiệm token/chi phí):
///   1. "base64" có sẵn → giải mã trực tiếp (miễn phí, tức thời).
///   2. "url" có sẵn → TẢI ảnh qua HTTP GET bình thường (miễn phí, chỉ tải
///      bytes ảnh, không thực thi gì).
///   3. CHỈ KHI 2 CÁCH TRÊN không có/thất bại VÀ có "prompt" mô tả ảnh cần
///      tạo VÀ đã cấu hình [ProviderConfig] sinh ảnh → gọi [ImageGenService]
///      (tốn tiền/token thật của provider đó) làm phương án CUỐI CÙNG.
///
/// Đây là lớp DUY NHẤT cần [BuildContext] (để [ChartRenderer] render off-
/// screen) — [DocxExporter]/[PptxExporter]/[XlsxExporter] bản thân chúng
/// không cần context, chỉ nhận sẵn bytes ảnh.
class DslDocumentBuilder {
  static Future<List<int>?> buildDocx(
    BuildContext context,
    String jsonText, {
    ProviderConfig? imageGenProvider,
  }) async {
    Map<String, dynamic> doc;
    try {
      doc = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
    final blocks = (doc['blocks'] as List?)?.toList() ?? [];
    final images = <String, List<int>>{};
    var chartCounter = 0;

    for (var i = 0; i < blocks.length; i++) {
      final block = blocks[i];
      if (block is! Map) continue;
      final type = block['type'] as String?;
      if (type == 'chart' || type == 'diagram') {
        chartCounter++;
        final id = 'chart$chartCounter';
        final png = await ChartRenderer.renderToPng(context, Map<String, dynamic>.from(block));
        if (png != null) {
          images[id] = png;
          blocks[i] = {'type': 'image', 'imageId': id, 'caption': block['title'], 'widthCm': 15};
        } else {
          blocks[i] = {
            'type': 'paragraph',
            'runs': [
              {'text': '[Không vẽ được biểu đồ/sơ đồ "${block['title'] ?? type}"]', 'italic': true}
            ]
          };
        }
      } else if (type == 'image') {
        final bytes = await _resolveImageBytes(Map<String, dynamic>.from(block), imageGenProvider);
        if (bytes != null) {
          final id = 'img${images.length + 1}';
          images[id] = bytes;
          final result = Map<String, dynamic>.from(block);
          result['imageId'] = id;
          blocks[i] = result;
        }
      }
    }

    doc['blocks'] = blocks;
    return DocxExporter.exportJson(doc, images: images);
  }

  static Future<List<int>?> buildPptx(
    BuildContext context,
    String jsonText, {
    ProviderConfig? imageGenProvider,
  }) async {
    Map<String, dynamic> pres;
    try {
      pres = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
    final images = <String, List<int>>{};
    var chartCounter = 0;
    final slides = (pres['slides'] as List?)?.toList() ?? [];

    for (var i = 0; i < slides.length; i++) {
      final slide = slides[i];
      if (slide is! Map) continue;
      final imgList = (slide['images'] as List?)?.toList() ?? [];
      for (var j = 0; j < imgList.length; j++) {
        final img = imgList[j];
        if (img is! Map) continue;
        if (img['type'] == 'chart' || img['type'] == 'diagram') {
          chartCounter++;
          final id = 'chart$chartCounter';
          final png = await ChartRenderer.renderToPng(context, Map<String, dynamic>.from(img));
          if (png != null) {
            images[id] = png;
            imgList[j] = {'imageId': id};
          }
        } else {
          final bytes = await _resolveImageBytes(Map<String, dynamic>.from(img), imageGenProvider);
          if (bytes != null) {
            final id = 'img${images.length + 1}';
            images[id] = bytes;
            imgList[j] = {'imageId': id};
          }
        }
      }
      slide['images'] = imgList;
      slides[i] = slide;
    }

    pres['slides'] = slides;
    return PptxExporter.exportJson(pres, images: images);
  }

  static Future<List<int>?> buildXlsx(String jsonText) async {
    Map<String, dynamic> workbook;
    try {
      workbook = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
    return XlsxExporter.exportJson(workbook);
  }

  /// Lấy bytes ảnh theo ĐÚNG thứ tự ưu tiên: base64 → url (tải, miễn phí) →
  /// prompt + imageGenProvider (gọi API sinh ảnh, tốn phí — chỉ khi 2 cách
  /// trên không có/thất bại).
  static Future<Uint8List?> _resolveImageBytes(
    Map<String, dynamic> block,
    ProviderConfig? imageGenProvider,
  ) async {
    if (block['base64'] != null) {
      try {
        return base64Decode(block['base64'] as String);
      } catch (_) {}
    }
    if (block['url'] != null) {
      final bytes = await _downloadImage(block['url'] as String);
      if (bytes != null) return bytes;
    }
    final prompt = block['prompt']?.toString();
    if (prompt != null && prompt.isNotEmpty && imageGenProvider != null) {
      return ImageGenService.generate(imageGenProvider, prompt);
    }
    return null;
  }

  static Future<Uint8List?> _downloadImage(String url) async {
    try {
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode >= 200 && resp.statusCode < 300) return resp.bodyBytes;
    } catch (_) {}
    return null;
  }
}
