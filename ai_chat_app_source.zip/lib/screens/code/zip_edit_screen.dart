import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../services/api_service.dart';
import '../../services/export/code_zip_export.dart';
import '../../utils/file_saver.dart';

/// Cho phép upload 1 file .zip source code BẤT KỲ (không nhất thiết là dự án
/// do chính app này tạo ra), chọn những file cần AI đọc/sửa, gõ yêu cầu, rồi
/// nhận lại 1 file .zip HOÀN CHỈNH (giữ nguyên các file không đổi, chỉ thay
/// những file AI chỉnh sửa/thêm mới) — tái dùng đúng cú pháp
/// ```đường/dẫn/file.ext ... ``` mà [CodeZipExporter] đã hỗ trợ sẵn cho
/// tính năng "xuất source code" trong chat, nên chỉ cần 1 lần gọi API.
///
/// Chỉ các file dạng text (đuôi phổ biến: dart/yaml/json/md/kts/gradle/xml/
/// html/js/css/txt/gitignore/properties) được đưa vào ngữ cảnh — file nhị
/// phân (ảnh, font, .g.dart quá dài, ...) bị bỏ qua để tránh vỡ encoding và
/// tốn token vô ích. Người dùng tick chọn thêm/bớt nếu cần.
///
/// [initialBytes]/[initialName]: cho phép nạp sẵn 1 file .zip đã tải về từ
/// nơi khác (ví dụ vừa tải bằng link download trong WebviewCaptureScreen),
/// bỏ qua bước phải tự chọn file lại lần 2.
class ZipEditScreen extends StatefulWidget {
  final Uint8List? initialBytes;
  final String? initialName;
  const ZipEditScreen({super.key, this.initialBytes, this.initialName});

  @override
  State<ZipEditScreen> createState() => _ZipEditScreenState();
}

const _textExtensions = {
  'dart', 'yaml', 'yml', 'json', 'md', 'kts', 'gradle', 'xml', 'html', 'js',
  'css', 'txt', 'properties', 'gitignore', 'toml', 'lock', 'sh',
};

class _ZipEditScreenState extends State<ZipEditScreen> {
  Map<String, String> _allFiles = {}; // path -> nội dung text
  final Set<String> _skippedBinary = {};
  final Set<String> _selectedPaths = {};
  final _instructionController = TextEditingController();
  String? _zipName;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialBytes != null) {
      // Đợi 1 frame để context/Provider sẵn sàng trước khi có thể show SnackBar.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadZipBytes(widget.initialBytes!, widget.initialName ?? 'downloaded.zip');
      });
    }
  }

  void _loadZipBytes(Uint8List bytes, String name) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final files = <String, String>{};
    final skipped = <String>{};
    for (final entry in archive) {
      if (!entry.isFile) continue;
      final ext = entry.name.contains('.') ? entry.name.split('.').last.toLowerCase() : '';
      if (_textExtensions.contains(ext)) {
        try {
          files[entry.name] = utf8.decode(entry.content as List<int>, allowMalformed: true);
        } catch (_) {
          skipped.add(entry.name);
        }
      } else {
        skipped.add(entry.name);
      }
    }
    setState(() {
      _zipName = name;
      _allFiles = files;
      _skippedBinary
        ..clear()
        ..addAll(skipped);
      _selectedPaths
        ..clear()
        ..addAll(files.keys);
    });
  }

  Future<void> _pickZip() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.single;
    if (f.bytes == null) return;
    _loadZipBytes(f.bytes!, f.name);
  }

  Future<void> _runEdit(ChatProvider chat) async {
    if (chat.current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hãy mở hoặc tạo 1 đoạn chat trước.')),
      );
      return;
    }
    final provider = chat.storage.providerFor(chat.current!);
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chưa cấu hình Provider API. Vào Cài đặt để thêm.')),
      );
      return;
    }
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để AI xem/sửa.')),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final buffer = StringBuffer();
      buffer.writeln('Đây là các file trong 1 dự án source code (.zip) người dùng đã upload. '
          'Đọc kỹ rồi thực hiện đúng yêu cầu bên dưới.');
      buffer.writeln();
      for (final path in _selectedPaths) {
        buffer.writeln('```$path');
        buffer.writeln(_allFiles[path]);
        buffer.writeln('```');
      }
      buffer.writeln();
      buffer.writeln('--- YÊU CẦU ---');
      buffer.writeln(_instructionController.text.trim());
      buffer.writeln();
      buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
      buffer.writeln('CHỈ trả lời bằng các code block cho những file BẠN THÊM MỚI hoặc '
          'THAY ĐỔI (không cần lặp lại file không đổi). Mỗi file 1 block, đường dẫn '
          'đặt ngay sau dấu ``` (ví dụ ```lib/main.dart), nội dung đầy đủ của file đó '
          'bên trong block. KHÔNG thêm lời dẫn/giải thích ngoài các code block.');

      final result = await chat.apiService.sendMessageOnce(
        config: provider,
        messages: [ApiMessage('user', buffer.toString())],
        onUsage: (usage) => chat.usageService.record(provider.id, usage),
      );

      final changed = CodeZipExporter.extractFiles(result);
      if (changed.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI không trả về file nào theo đúng định dạng mong đợi — thử lại với yêu cầu rõ ràng hơn.')),
          );
        }
        return;
      }

      final merged = Map<String, String>.from(_allFiles)..addAll(changed);
      final zipBytes = CodeZipExporter.export(
        merged,
        readmeExtra: '# Đã chỉnh sửa bởi thư ký AI\n\n'
            'Các file thay đổi/thêm mới: ${changed.keys.join(', ')}',
      );
      final outName = _zipName != null
          ? '${_zipName!.replaceAll('.zip', '')}_edited_${DateTime.now().millisecondsSinceEpoch}.zip'
          : 'source_edited_${DateTime.now().millisecondsSinceEpoch}.zip';
      await FileSaver.saveAndShare(zipBytes, outName);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã sửa ${changed.length} file, tải về "$outName".')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Sửa source code (.zip)')),
      body: _allFiles.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Upload 1 file .zip source code để bắt đầu.', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _pickZip,
                      icon: const Icon(Icons.upload_file),
                      label: const Text('Upload .zip'),
                    ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(child: Text('$_zipName — ${_allFiles.length} file text'
                          '${_skippedBinary.isNotEmpty ? ', bỏ qua ${_skippedBinary.length} file nhị phân' : ''}')),
                      TextButton(onPressed: _pickZip, child: const Text('Đổi file khác')),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    children: _allFiles.keys.map((path) {
                      return CheckboxListTile(
                        dense: true,
                        value: _selectedPaths.contains(path),
                        onChanged: (v) => setState(() {
                          if (v == true) {
                            _selectedPaths.add(path);
                          } else {
                            _selectedPaths.remove(path);
                          }
                        }),
                        title: Text(path, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      );
                    }).toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: TextField(
                    controller: _instructionController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Yêu cầu sửa gì?',
                      hintText: 'VD: sửa lỗi build, thêm màn hình đăng nhập, đổi màu theme...',
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : () => _runEdit(chat),
                      icon: _busy
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.auto_fix_high),
                      label: Text(_busy ? 'Đang xử lý...' : 'Sửa bằng AI (1 lần gọi API) & tải zip'),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
    );
  }
}
