import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../services/api_service.dart';
import '../../services/export/code_zip_export.dart';
import '../../utils/file_saver.dart';

/// Cho phép upload 1 file .zip source code BẤT KỲ (không nhất thiết là dự án
/// do chính app này tạo ra), rồi có 2 CÁCH để lấy bản sửa:
///
///  CÁCH 1 — AI trong app tự sửa: chọn file cần xem, gõ yêu cầu, 1 lần gọi
///  API, nhận lại + tải zip ngay.
///
///  CÁCH 2 — đã nhờ 1 nơi khác (AI khác, hoặc 1 người khác) sửa giúp: bấm
///  "Copy nội dung" để lấy toàn bộ file đã chọn dưới dạng text (đúng cú
///  pháp ```đường/dẫn/file``` mà [CodeZipExporter] hiểu được) rồi tự gửi đi
///  bằng bất kỳ cách nào (dán vào WebviewCaptureScreen, gửi qua app khác...);
///  khi có kết quả trả về, dán ngược lại vào ô "Kết quả đã sửa" rồi bấm
///  "Ghép & tải zip" — bước này KHÔNG gọi API của app (0 token), vì việc
///  sửa đã do bên ngoài làm.
///
/// Cả 2 cách đều tái dùng đúng cú pháp
/// ```đường/dẫn/file.ext ... ``` mà [CodeZipExporter] đã hỗ trợ sẵn, và chỉ
/// merge những file thay đổi/thêm mới với các file gốc không đổi.
///
/// Chỉ các file dạng text (đuôi phổ biến: dart/yaml/json/md/kts/gradle/xml/
/// html/js/css/txt/gitignore/properties) được đưa vào ngữ cảnh — file nhị
/// phân (ảnh, font, .g.dart quá dài, ...) bị bỏ qua để tránh vỡ encoding và
/// tốn token vô ích. Người dùng tick chọn thêm/bớt nếu cần.
///
/// [initialBytes]/[initialName]: cho phép nạp sẵn 1 file .zip đã tải về từ
/// nơi khác (ví dụ vừa tải bằng link download trong WebviewCaptureScreen),
/// bỏ qua bước phải tự chọn file lại lần 2.
class ZipEditScreen extends StatefulWidget {
  final Uint8List? initialBytes;
  final String? initialName;
  const ZipEditScreen({super.key, this.initialBytes, this.initialName});

  @override
  State<ZipEditScreen> createState() => _ZipEditScreenState();
}

const _textExtensions = {
  'dart', 'yaml', 'yml', 'json', 'md', 'kts', 'gradle', 'xml', 'html', 'js',
  'css', 'txt', 'properties', 'gitignore', 'toml', 'lock', 'sh',
};

class _ZipEditScreenState extends State<ZipEditScreen> {
  Map<String, String> _allFiles = {}; // path -> nội dung text
  final Set<String> _skippedBinary = {};
  final Set<String> _selectedPaths = {};
  final _instructionController = TextEditingController();
  final _externalResultController = TextEditingController();
  String? _zipName;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialBytes != null) {
      // Đợi 1 frame để context/Provider sẵn sàng trước khi có thể show SnackBar.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadZipBytes(widget.initialBytes!, widget.initialName ?? 'downloaded.zip');
      });
    }
  }

  void _loadZipBytes(Uint8List bytes, String name) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final files = <String, String>{};
    final skipped = <String>{};
    for (final entry in archive) {
      if (!entry.isFile) continue;
      final ext = entry.name.contains('.') ? entry.name.split('.').last.toLowerCase() : '';
      if (_textExtensions.contains(ext)) {
        try {
          files[entry.name] = utf8.decode(entry.content as List<int>, allowMalformed: true);
        } catch (_) {
          skipped.add(entry.name);
        }
      } else {
        skipped.add(entry.name);
      }
    }
    setState(() {
      _zipName = name;
      _allFiles = files;
      _skippedBinary
        ..clear()
        ..addAll(skipped);
      _selectedPaths
        ..clear()
        ..addAll(files.keys);
    });
  }

  Future<void> _pickZip() async {
    const typeGroup = XTypeGroup(label: 'zip', extensions: ['zip']);
    final f = await openFile(acceptedTypeGroups: [typeGroup]);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    _loadZipBytes(bytes, f.name);
  }

  Future<void> _copySelectedForSharing() async {
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để copy.')),
      );
      return;
    }
    final selected = {for (final p in _selectedPaths) p: _allFiles[p]!};
    final text = CodeZipExporter.formatForSharing(selected);
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(
          'Đã copy ${_selectedPaths.length} file (${text.length} ký tự) vào clipboard — '
          'dán vào đâu cũng được: AI khác, ô chat trong WebView (nút 📋 Dán nội dung), v.v.',
        )),
      );
    }
  }

  /// Ghép kết quả ĐÃ ĐƯỢC SỬA SẴN từ bên ngoài (1 AI khác, hoặc 1 người
  /// khác) thành zip hoàn chỉnh — KHÔNG gọi API của app (0 token), vì việc
  /// đọc/sửa đã do bên ngoài làm; app chỉ parse lại đúng cú pháp
  /// ```đường/dẫn/file``` và merge với file gốc không đổi.
  Future<void> _mergeExternalResult() async {
    final text = _externalResultController.text;
    if (text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dán kết quả đã sửa vào ô bên trên trước.')),
      );
      return;
    }
    final changed = CodeZipExporter.extractFiles(text);
    if (changed.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Không đọc được file nào — kết quả cần đúng cú pháp ```đường/dẫn/file.ext ... ```.',
          ),
          duration: const Duration(seconds: 8),
          action: SnackBarAction(
            label: 'Copy prompt định dạng',
            onPressed: () {
              Clipboard.setData(const ClipboardData(text: CodeZipExporter.formatInstructionPrompt));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text(
                  'Đã copy — dán gửi lại cho bên kia (AI khác/người khác), nhờ họ trả lời lại đúng định dạng này.',
                )),
              );
            },
          ),
        ),
      );
      return;
    }
    final merged = Map<String, String>.from(_allFiles)..addAll(changed);
    final zipBytes = CodeZipExporter.export(
      merged,
      readmeExtra: '# Đã chỉnh sửa từ bên ngoài (không qua AI trong app)\n\n'
          'Các file thay đổi/thêm mới: ${changed.keys.join(', ')}',
    );
    final outName = _zipName != null
        ? '${_zipName!.replaceAll('.zip', '')}_edited_${DateTime.now().millisecondsSinceEpoch}.zip'
        : 'source_edited_${DateTime.now().millisecondsSinceEpoch}.zip';
    await FileSaver.saveAndShare(zipBytes, outName);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã ghép ${changed.length} file, tải về "$outName".')),
      );
    }
  }

  Future<void> _runEdit(ChatProvider chat) async {
    if (chat.current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hãy mở hoặc tạo 1 đoạn chat trước.')),
      );
      return;
    }
    final provider = chat.storage.secretaryProvider ?? chat.storage.providerFor(chat.current!);
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chưa cấu hình Provider API. Vào Cài đặt để thêm.')),
      );
      return;
    }
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để AI xem/sửa.')),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final buffer = StringBuffer();
      buffer.writeln('Đây là các file trong 1 dự án source code (.zip) người dùng đã upload. '
          'Đọc kỹ rồi thực hiện đúng yêu cầu bên dưới.');
      buffer.writeln();
      for (final path in _selectedPaths) {
        buffer.writeln('```$path');
        buffer.writeln(_allFiles[path]);
        buffer.writeln('```');
      }
      buffer.writeln();
      buffer.writeln('--- YÊU CẦU ---');
      buffer.writeln(_instructionController.text.trim());
      buffer.writeln();
      buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
      buffer.writeln('CHỈ trả lời bằng các code block cho những file BẠN THÊM MỚI hoặc '
          'THAY ĐỔI (không cần lặp lại file không đổi). Mỗi file 1 block, đường dẫn '
          'đặt ngay sau dấu ``` (ví dụ ```lib/main.dart), nội dung đầy đủ của file đó '
          'bên trong block. KHÔNG thêm lời dẫn/giải thích ngoài các code block.');

      final result = await chat.apiService.sendMessageOnce(
        config: provider,
        messages: [ApiMessage('user', buffer.toString())],
        onUsage: (usage) => chat.usageService.record(provider.id, usage),
      );

      final changed = CodeZipExporter.extractFiles(result);
      if (changed.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI không trả về file nào theo đúng định dạng mong đợi — thử lại với yêu cầu rõ ràng hơn.')),
          );
        }
        return;
      }

      final merged = Map<String, String>.from(_allFiles)..addAll(changed);
      final zipBytes = CodeZipExporter.export(
        merged,
        readmeExtra: '# Đã chỉnh sửa bởi thư ký AI\n\n'
            'Các file thay đổi/thêm mới: ${changed.keys.join(', ')}',
      );
      final outName = _zipName != null
          ? '${_zipName!.replaceAll('.zip', '')}_edited_${DateTime.now().millisecondsSinceEpoch}.zip'
          : 'source_edited_${DateTime.now().millisecondsSinceEpoch}.zip';
      await FileSaver.saveAndShare(zipBytes, outName);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã sửa ${changed.length} file, tải về "$outName".')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Sửa source code (.zip)')),
      body: _allFiles.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Upload 1 file .zip source code để bắt đầu.', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _pickZip,
                      icon: const Icon(Icons.upload_file),
                      label: const Text('Upload .zip'),
                    ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(child: Text('$_zipName — ${_allFiles.length} file text'
                          '${_skippedBinary.isNotEmpty ? ', bỏ qua ${_skippedBinary.length} file nhị phân' : ''}')),
                      TextButton(onPressed: _pickZip, child: const Text('Đổi file khác')),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(
                          height: 220,
                          child: ListView(
                            children: _allFiles.keys.map((path) {
                              return CheckboxListTile(
                                dense: true,
                                value: _selectedPaths.contains(path),
                                onChanged: (v) => setState(() {
                                  if (v == true) {
                                    _selectedPaths.add(path);
                                  } else {
                                    _selectedPaths.remove(path);
                                  }
                                }),
                                title: Text(path, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                              );
                            }).toList(),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: OutlinedButton.icon(
                            onPressed: _copySelectedForSharing,
                            icon: const Icon(Icons.copy_all_outlined),
                            label: Text('Copy ${_selectedPaths.length} file đã chọn (gửi cho AI khác/người khác)'),
                          ),
                        ),
                        const Divider(height: 1),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                          child: Text('Cách 1 — AI trong app tự sửa', style: Theme.of(context).textTheme.labelLarge),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _instructionController,
                            maxLines: 2,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Yêu cầu sửa gì?',
                              hintText: 'VD: sửa lỗi build, thêm màn hình đăng nhập, đổi màu theme...',
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: FilledButton.icon(
                            onPressed: _busy ? null : () => _runEdit(chat),
                            icon: _busy
                                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Icon(Icons.auto_fix_high),
                            label: Text(_busy ? 'Đang xử lý...' : 'Sửa bằng AI (1 lần gọi API) & tải zip'),
                          ),
                        ),
                        const Divider(height: 24),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                          child: Text('Cách 2 — đã có bản sửa từ nơi khác (0 token)', style: Theme.of(context).textTheme.labelLarge),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                          child: Text(
                            'Mẹo: dán prompt "mồi" này cho bên kia (AI khác/người khác) TRƯỚC KHI '
                            'họ trả lời, để kết quả trả về parse được ngay — khỏi cần app gọi thêm AI.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Clipboard.setData(const ClipboardData(text: CodeZipExporter.formatInstructionPrompt));
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Đã copy prompt định dạng — dán gửi cho bên kia trước khi họ trả lời.')),
                              );
                            },
                            icon: const Icon(Icons.content_copy),
                            label: const Text('Copy prompt định dạng chuẩn'),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _externalResultController,
                            maxLines: 3,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Dán kết quả đã sửa (cú pháp ```đường/dẫn/file.ext ... ```)',
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: OutlinedButton.icon(
                            onPressed: _mergeExternalResult,
                            icon: const Icon(Icons.merge_type),
                            label: const Text('Ghép & tải zip (không gọi AI)'),
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
