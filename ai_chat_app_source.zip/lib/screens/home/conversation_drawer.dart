import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/conversation.dart';
import '../../providers/chat_provider.dart';
import '../settings/provider_settings_screen.dart';
import '../settings/usage_stats_screen.dart';
import '../sources/source_documents_screen.dart';
import '../code/zip_edit_screen.dart';

/// Drawer quản lý các đoạn chat: tạo mới, ghim, đổi tên, xóa, nhóm theo
/// folder — giống các app chat khác (ChatGPT/Claude client).
class ConversationDrawer extends StatelessWidget {
  const ConversationDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final folders = chat.folders;

    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () async {
                        await chat.createConversation();
                        if (context.mounted) Navigator.pop(context);
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Đoạn chat mới'),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Thống kê token đã dùng',
                    icon: const Icon(Icons.query_stats_outlined),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const UsageStatsScreen()),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Cài đặt API / Provider',
                    icon: const Icon(Icons.settings_outlined),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ProviderSettingsScreen()),
                    ),
                  ),
                ],
              ),
            ),
            IconButton(
              alignment: Alignment.centerLeft,
              onPressed: () => _newFolderDialog(context, chat),
              icon: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [Icon(Icons.create_new_folder_outlined, size: 18), SizedBox(width: 6), Text('Tạo thư mục')],
              ),
            ),
            ListTile(
              dense: true,
              leading: const Icon(Icons.auto_awesome_outlined),
              title: const Text('Tài liệu nguồn — Thư ký AI'),
              subtitle: const Text('Upload file / trích xuất web → tổng hợp docx/pptx/xlsx'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const SourceDocumentsScreen()));
              },
            ),
            ListTile(
              dense: true,
              leading: const Icon(Icons.folder_zip_outlined),
              title: const Text('Sửa source code (.zip)'),
              subtitle: const Text('Upload zip bất kỳ → AI sửa → tải zip hoàn chỉnh'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ZipEditScreen()));
              },
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                children: [
                  if (folders.isEmpty)
                    // Chưa tạo thư mục nào -> hiện danh sách chat phẳng,
                    // không bọc trong 1 ExpansionTile "Không phân loại" gây
                    // cảm giác thừa 1 lớp thư mục không cần thiết.
                    ...chat.conversationsInFolder(null).map((c) => _convTile(context, chat, c))
                  else ...[
                    _folderSection(context, chat, null, 'Không phân loại'),
                    for (final f in folders) _folderSection(context, chat, f.id, f.name),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _folderSection(BuildContext context, ChatProvider chat, String? folderId, String label) {
    final convs = chat.conversationsInFolder(folderId);
    if (convs.isEmpty && folderId != null) return const SizedBox.shrink();
    return ExpansionTile(
      initiallyExpanded: true,
      leading: Icon(folderId == null ? Icons.chat_bubble_outline : Icons.folder_outlined),
      title: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
      children: convs.map((c) => _convTile(context, chat, c)).toList(),
    );
  }

  Widget _convTile(BuildContext context, ChatProvider chat, Conversation c) {
    final selected = chat.current?.id == c.id;
    return ListTile(
      selected: selected,
      dense: true,
      leading: Icon(c.pinned ? Icons.push_pin : Icons.chat_bubble_outline, size: 18),
      title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: PopupMenuButton<String>(
        onSelected: (v) {
          if (v == 'pin') chat.togglePin(c);
          if (v == 'delete') chat.deleteConversation(c.id);
        },
        itemBuilder: (_) => [
          PopupMenuItem(value: 'pin', child: Text(c.pinned ? 'Bỏ ghim' : 'Ghim')),
          const PopupMenuItem(value: 'delete', child: Text('Xóa')),
        ],
      ),
      onTap: () {
        chat.selectConversation(c);
        Navigator.pop(context);
      },
    );
  }

  void _newFolderDialog(BuildContext context, ChatProvider chat) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Tên thư mục mới'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isNotEmpty) chat.createFolder(controller.text.trim());
              Navigator.pop(context);
            },
            child: const Text('Tạo'),
          ),
        ],
      ),
    );
  }
}
