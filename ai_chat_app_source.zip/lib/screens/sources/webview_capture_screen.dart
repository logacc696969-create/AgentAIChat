import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:webview_cookie_manager/webview_cookie_manager.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:uuid/uuid.dart';
import '../../models/source_document.dart';
import '../../providers/chat_provider.dart';
import '../../services/storage_service.dart';
import '../code/zip_edit_screen.dart';

/// Trình duyệt nhúng ngay trong app để người dùng tự đăng nhập vào BẤT KỲ
/// hệ thống web nào họ có quyền truy cập (web nội bộ công ty, hộp thư, hệ
/// thống quản lý công việc, mạng xã hội, ...) bằng chính phiên đăng nhập của
/// họ — app KHÔNG lưu, KHÔNG can thiệp mật khẩu/đăng nhập.
///
/// Khi đang xem 1 trang bất kỳ, bấm nút "Trích xuất nội dung trang" sẽ chạy
/// JS `document.body.innerText` lấy toàn bộ text đang HIỂN THỊ trên trang
/// (đúng những gì mắt người dùng đang thấy, họ tự quyết định trang nào cần
/// lấy) và lưu thành 1 SourceDocument — bước này KHÔNG gọi API model nào cả,
/// nên KHÔNG tốn token. Token chỉ bị tốn 1 LẦN DUY NHẤT sau đó, khi người
/// dùng chủ động bấm "Tổng hợp" ở màn hình Tài liệu nguồn.
///
/// LƯU Ý KỸ THUẬT: một số trang (đặc biệt hệ thống doanh nghiệp có SSO/2FA
/// nghiêm ngặt, hoặc chặn User-Agent lạ) có thể từ chối hiển thị trong
/// WebView — nếu gặp trang trắng/lỗi đăng nhập, đó là do chính hệ thống đó
/// chặn, không phải lỗi của app.
class WebviewCaptureScreen extends StatefulWidget {
  final String initialUrl;
  const WebviewCaptureScreen({super.key, this.initialUrl = 'https://www.google.com'});

  @override
  State<WebviewCaptureScreen> createState() => _WebviewCaptureScreenState();
}

class _WebviewCaptureScreenState extends State<WebviewCaptureScreen> {
  static const _downloadableExtensions = {
    'zip', 'rar', '7z', 'docx', 'doc', 'pdf', 'xlsx', 'xls', 'pptx', 'ppt', 'csv',
  };

  late final WebViewController _controller;
  final _cookieManager = WebviewCookieManager();
  final _urlController = TextEditingController();
  bool _loading = true;
  bool _downloading = false;
  String _currentUrl = '';
  String _currentTitle = '';

  @override
  void initState() {
    super.initState();
    _urlController.text = widget.initialUrl;
    _currentUrl = widget.initialUrl;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (url) => setState(() {
          _loading = true;
          _currentUrl = url;
          _urlController.text = url;
        }),
        onPageFinished: (url) async {
          String title = url;
          try {
            title = await _controller.getTitle() ?? url;
          } catch (_) {}
          if (!mounted) return;
          setState(() {
            _loading = false;
            _currentUrl = url;
            _currentTitle = title;
          });
        },
        // WebView (giống Chrome/Safari) KHÔNG tự tải file đính kèm xuống —
        // nếu để mặc định, link .zip/.docx/.pdf sẽ chỉ hiện trang trắng hoặc
        // lỗi. Chặn lại các link có đuôi file rồi tự tải bằng http + cookie
        // phiên thật của WebView (xem _downloadFile).
        onNavigationRequest: (request) {
          final path = Uri.tryParse(request.url)?.path.toLowerCase() ?? '';
          final isDownloadLink = _downloadableExtensions.any((ext) => path.endsWith('.$ext'));
          if (isDownloadLink) {
            _downloadFile(request.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.initialUrl));
  }

  Future<void> _goTo(String input) async {
    var url = input.trim();
    if (url.isEmpty) return;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }
    await _controller.loadRequest(Uri.parse(url));
  }

  Future<void> _extractAndSave(StorageService storage) async {
    String text;
    try {
      // Lấy toàn bộ text đang hiển thị trên trang — không cần biết cấu trúc
      // DOM cụ thể của từng trang web, nên hoạt động với hầu hết trang.
      final raw = await _controller.runJavaScriptReturningResult(
        'document.body ? document.body.innerText : ""',
      );
      text = raw.toString();
      // Kết quả runJavaScriptReturningResult trên Android có thể được bọc
      // trong dấu nháy kép + escape — gỡ ra cho sạch.
      if (text.startsWith('"') && text.endsWith('"')) {
        text = text.substring(1, text.length - 1);
      }
      text = text.replaceAll(r'\n', '\n').replaceAll(r'\"', '"');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không trích xuất được nội dung trang này: $e')),
        );
      }
      return;
    }

    if (text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Trang này không có nội dung text để trích xuất.')),
        );
      }
      return;
    }

    final doc = SourceDocument(
      id: const Uuid().v4(),
      title: _currentTitle.isNotEmpty ? _currentTitle : _currentUrl,
      content: text,
      origin: 'webview',
      sourceLabel: _currentUrl,
      createdAt: DateTime.now(),
    );
    await storage.sourceDocuments.put(doc.id, doc);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã lưu "${doc.title}" vào Tài liệu nguồn (${text.length} ký tự).')),
      );
    }
  }

  /// Tải 1 file đính kèm (zip/docx/pdf/...) từ [url] bằng chính phiên đăng
  /// nhập hiện tại của WebView. Dùng [WebviewCookieManager] (đọc cookie qua
  /// CookieManager GỐC của hệ điều hành) thay vì `document.cookie` trong JS,
  /// vì `document.cookie` KHÔNG đọc được cookie đánh dấu HttpOnly — mà cookie
  /// phiên đăng nhập (session/auth token) thường được đánh dấu HttpOnly vì lý
  /// do bảo mật, nên cách này mới thực sự tải được file cần đăng nhập.
  Future<void> _downloadFile(String url) async {
    if (_downloading) return;
    setState(() => _downloading = true);
    try {
      final cookies = await _cookieManager.getCookies(url);
      final cookieHeader = cookies.map((c) => '${c.name}=${c.value}').join('; ');
      String userAgent = '';
      try {
        final ua = await _controller.runJavaScriptReturningResult('navigator.userAgent');
        userAgent = ua.toString().replaceAll('"', '');
      } catch (_) {}

      final resp = await http.get(
        Uri.parse(url),
        headers: {
          if (cookieHeader.isNotEmpty) 'Cookie': cookieHeader,
          if (userAgent.isNotEmpty) 'User-Agent': userAgent,
        },
      );

      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw Exception('Server trả về mã lỗi ${resp.statusCode} — có thể trang '
            'yêu cầu đăng nhập lại hoặc cookie phiên không hợp lệ cho link này.');
      }

      final name = Uri.parse(url).pathSegments.isNotEmpty ? Uri.parse(url).pathSegments.last : 'downloaded_file';
      final ext = name.contains('.') ? name.split('.').last.toLowerCase() : '';

      if (!mounted) return;

      if (ext == 'zip') {
        // Đưa thẳng sang màn "Sửa source code (.zip)" — không cần chọn lại
        // file lần 2.
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ZipEditScreen(initialBytes: resp.bodyBytes, initialName: name),
          ),
        );
        return;
      }

      // File không phải zip: cố đọc thành text để lưu làm Tài liệu nguồn.
      // Lưu ý: .docx/.pdf/.xlsx/.pptx là định dạng nhị phân (bản chất cũng là
      // zip có cấu trúc XML bên trong) — đọc thẳng bằng utf8 sẽ ra ký tự rác,
      // KHÔNG phải nội dung thật. App hiện chưa có bước tự parse các định
      // dạng này (cần thư viện riêng cho từng loại) — nếu gặp, khuyên người
      // dùng tải file đó về máy qua trình duyệt thường rồi convert sang .txt/
      // .md trước, hoặc yêu cầu tôi bổ sung parser riêng cho từng định dạng.
      if (!{'txt', 'md', 'csv', 'json', 'html', 'xml', 'log'}.contains(ext)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(
            'Đã tải "$name" ($ext) nhưng đây là định dạng nhị phân — app chưa đọc được '
            'nội dung text từ .$ext. Tải về máy rồi mở bằng ứng dụng phù hợp, hoặc báo '
            'tôi bổ sung parser riêng cho .$ext.',
          )),
        );
        return;
      }

      final storage = context.read<ChatProvider>().storage;
      final text = utf8.decode(resp.bodyBytes, allowMalformed: true);
      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: name,
        content: text,
        origin: 'webview',
        sourceLabel: url,
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã tải "$name" và lưu vào Tài liệu nguồn (${text.length} ký tự).')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không tải được file: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final storage = context.read<ChatProvider>().storage;
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _urlController,
          decoration: const InputDecoration(
            border: InputBorder.none,
            hintText: 'Nhập địa chỉ web...',
          ),
          keyboardType: TextInputType.url,
          textInputAction: TextInputAction.go,
          onSubmitted: _goTo,
        ),
        actions: [
          IconButton(
            tooltip: 'Tải lại',
            icon: const Icon(Icons.refresh),
            onPressed: () => _controller.reload(),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          if (_downloading)
            Container(
              width: double.infinity,
              color: Theme.of(context).colorScheme.primaryContainer,
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
              child: const Row(
                children: [
                  SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 8),
                  Text('Đang tải file đính kèm...'),
                ],
              ),
            ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.content_paste_go),
        label: const Text('Trích xuất nội dung trang'),
        onPressed: () => _extractAndSave(storage),
      ),
    );
  }
}
