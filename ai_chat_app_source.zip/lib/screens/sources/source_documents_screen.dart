import 'dart:convert';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../models/source_document.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/export_runner.dart';
import 'webview_capture_screen.dart';

/// Trung tâm "Tài liệu nguồn" cho tính năng thư ký AI:
///  1. Thêm tài liệu — bằng cách upload file (txt/md/csv/json/xuất dữ liệu từ
///     nơi khác) HOẶC mở trình duyệt nhúng để trích xuất nội dung trang
///     (không tốn token).
///  2. Chọn (các) tài liệu muốn dùng.
///  3. Gõ thêm yêu cầu chi tiết (VD: "thêm số liệu quý 3", "chỉ lấy phần kết
///     luận", "trình bày dạng bảng thống kê") rồi chọn định dạng xuất.
///  4. App gọi API model ĐÚNG 1 LẦN để tổng hợp, rồi xuất file bằng đúng
///     exporter (docx/pptx/xlsx/zip) đã có sẵn trong app.
class SourceDocumentsScreen extends StatefulWidget {
  const SourceDocumentsScreen({super.key});

  @override
  State<SourceDocumentsScreen> createState() => _SourceDocumentsScreenState();
}

class _SourceDocumentsScreenState extends State<SourceDocumentsScreen> {
  final Set<String> _selectedIds = {};
  bool _busy = false;

  Future<void> _uploadFile(ChatProvider chat) async {
    const typeGroup = XTypeGroup(
      label: 'tài liệu',
      extensions: ['txt', 'md', 'csv', 'json', 'log', 'html', 'xml'],
    );
    final f = await openFile(acceptedTypeGroups: [typeGroup]);
    if (f == null) return;
    final bytes = await f.readAsBytes();

    String content;
    try {
      content = utf8.decode(bytes, allowMalformed: true);
    } catch (_) {
      content = String.fromCharCodes(bytes);
    }

    final doc = SourceDocument(
      id: const Uuid().v4(),
      title: f.name,
      content: content,
      origin: 'upload',
      sourceLabel: f.name,
      createdAt: DateTime.now(),
    );
    await chat.storage.sourceDocuments.put(doc.id, doc);
    setState(() {});
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã thêm "${f.name}" (${content.length} ký tự).')),
      );
    }
  }

  Future<void> _openWebview() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const WebviewCaptureScreen()),
    );
    setState(() {}); // refresh danh sách sau khi quay lại (có thể vừa lưu thêm)
  }

  Future<void> _delete(ChatProvider chat, SourceDocument doc) async {
    await doc.delete();
    _selectedIds.remove(doc.id);
    setState(() {});
  }

  Future<void> _compile(ChatProvider chat, List<SourceDocument> docs) async {
    if (chat.current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hãy mở hoặc tạo 1 đoạn chat trước — kết quả tổng hợp sẽ lưu vào đó.')),
      );
      return;
    }

    final result = await showModalBottomSheet<_CompileRequest>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CompileSheet(docCount: docs.length),
    );
    if (result == null) return;

    setState(() => _busy = true);
    try {
      final msg = await chat.compileSources(
        sources: docs,
        instruction: result.instruction,
        outputFormat: result.format,
      );
      if (msg == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Lỗi: ${chat.lastError ?? "không rõ"}')),
          );
        }
        return;
      }
      if (!mounted) return;
      await ExportRunner.run(
        context: context,
        chat: chat,
        conv: chat.current!,
        sourceMessage: msg,
        type: result.format,
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final docs = chat.storage.sourceDocumentsSorted;
    final selected = docs.where((d) => _selectedIds.contains(d.id)).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tài liệu nguồn — Thư ký AI'),
      ),
      body: docs.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Chưa có tài liệu nào.\nUpload file hoặc mở trình duyệt để trích xuất nội dung trang.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
            )
          : ListView.builder(
              itemCount: docs.length,
              itemBuilder: (_, i) {
                final d = docs[i];
                return CheckboxListTile(
                  value: _selectedIds.contains(d.id),
                  onChanged: (v) => setState(() {
                    if (v == true) {
                      _selectedIds.add(d.id);
                    } else {
                      _selectedIds.remove(d.id);
                    }
                  }),
                  title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                    '${d.origin == 'webview' ? '🌐 Web' : '📄 File'} · ${d.sourceLabel} · ${d.content.length} ký tự',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  secondary: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _delete(chat, d),
                  ),
                );
              },
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _uploadFile(chat),
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Upload file'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _openWebview,
                  icon: const Icon(Icons.public),
                  label: const Text('Duyệt web'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.icon(
                  onPressed: (_busy || selected.isEmpty) ? null : () => _compile(chat, selected),
                  icon: _busy
                      ? const SizedBox(
                          width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome),
                  label: Text('Tổng hợp (${selected.length})'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CompileRequest {
  final String instruction;
  final String format;
  _CompileRequest(this.instruction, this.format);
}

class _CompileSheet extends StatefulWidget {
  final int docCount;
  const _CompileSheet({required this.docCount});

  @override
  State<_CompileSheet> createState() => _CompileSheetState();
}

class _CompileSheetState extends State<_CompileSheet> {
  final _controller = TextEditingController();
  String _format = 'docx';

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Tổng hợp ${widget.docCount} tài liệu', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          TextField(
            controller: _controller,
            maxLines: 4,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Yêu cầu chi tiết (tuỳ chọn)',
              hintText: 'VD: thêm số liệu quý 3, chỉ lấy phần kết luận, trình bày dạng bảng...',
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(label: const Text('Word (.docx)'), selected: _format == 'docx', onSelected: (_) => setState(() => _format = 'docx')),
              ChoiceChip(label: const Text('PowerPoint (.pptx)'), selected: _format == 'pptx', onSelected: (_) => setState(() => _format = 'pptx')),
              ChoiceChip(label: const Text('Excel (.xlsx)'), selected: _format == 'xlsx', onSelected: (_) => setState(() => _format = 'xlsx')),
              ChoiceChip(label: const Text('Source code (.zip)'), selected: _format == 'zip', onSelected: (_) => setState(() => _format = 'zip')),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () => Navigator.pop(context, _CompileRequest(_controller.text, _format)),
              child: const Text('Tổng hợp (1 lần gọi API)'),
            ),
          ),
        ],
      ),
    );
  }
}
