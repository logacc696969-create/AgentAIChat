// GENERATED CODE (viết tay thay cho build_runner)
part of 'generated_file.dart';

class GeneratedFileAdapter extends TypeAdapter<GeneratedFile> {
  @override
  final int typeId = 7;

  @override
  GeneratedFile read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return GeneratedFile(
      id: fields[0] as String,
      fileName: fields[1] as String,
      type: fields[2] as String,
      sourceMessageId: fields[3] as String,
      createdAt: fields[4] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, GeneratedFile obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.fileName)
      ..writeByte(2)
      ..write(obj.type)
      ..writeByte(3)
      ..write(obj.sourceMessageId)
      ..writeByte(4)
      ..write(obj.createdAt);
  }
}
