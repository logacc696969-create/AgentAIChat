import 'package:hive/hive.dart';
import 'message.dart';
import 'generated_file.dart';

part 'conversation.g.dart';

@HiveType(typeId: 5)
class Conversation extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  List<ChatMessage> messages;

  @HiveField(3)
  DateTime createdAt;

  @HiveField(4)
  DateTime updatedAt;

  @HiveField(5)
  String? folderId;

  @HiveField(6)
  bool pinned;

  @HiveField(7)
  String? providerConfigId; // nếu null -> dùng provider mặc định

  @HiveField(8)
  String systemPrompt;

  /// Tổng số token đã ước lượng còn "sống" trong ngữ cảnh hiện tại
  /// (sau khi đã trừ phần bị tóm tắt/gấp lại).
  @HiveField(9)
  int liveTokenEstimate;

  /// Danh sách id các Provider CÙNG tham gia thảo luận trong đoạn chat này.
  /// Rỗng = chat 1-model bình thường. Có ≥2 phần tử = mỗi tin nhắn người
  /// dùng gửi sẽ được LẦN LƯỢT từng model trong danh sách trả lời (mỗi model
  /// thấy được câu trả lời của các model trước đó trong cùng lượt).
  @HiveField(10)
  List<String> discussionProviderIds;

  /// Override RIÊNG cho đoạn chat này, đổi được ngay trong lúc chat (không
  /// cần vào Cài đặt Provider) — null = dùng mặc định của Provider.
  @HiveField(11)
  String? reasoningEffortOverride;

  @HiveField(12)
  double? temperatureOverride;

  /// Override tìm kiếm web riêng cho đoạn chat này: null = dùng mặc định
  /// của Provider, true/false = ép bật/tắt bất kể mặc định Provider.
  @HiveField(13)
  bool? webSearchOverride;

  /// Danh sách file (docx/pptx/xlsx/zip) đã xuất trong đoạn chat này — hiện
  /// trong panel "File đã tạo" (icon 📁 trên chat_screen), giống panel
  /// Artifacts bên phải của Claude.
  @HiveField(14)
  List<GeneratedFile> generatedFiles;

  /// Danh sách id các đoạn chat KHÁC được liên kết tới đoạn chat này.
  @HiveField(15)
  List<String> linkedConversationIds;

  /// Cache bản tóm tắt ĐÃ RÚT GỌN của từng đoạn chat liên kết (key = id đoạn
  /// chat kia, value = text sẵn sàng chèn vào ngữ cảnh, đã giới hạn độ dài
  /// cứng) — bắt buộc phải có cache này để việc liên kết KHÔNG BAO GIỜ đốt
  /// token tỉ lệ thuận với độ dài đoạn chat được liên kết (xem
  /// `ContextManager.refreshLinkedContext`).
  @HiveField(16)
  Map<String, String> linkedContextCache;

  /// Số tin nhắn của đoạn chat liên kết tại thời điểm cache ở trên được tạo
  /// — dùng để biết khi nào cần tính lại (chỉ tính lại khi lệch nhiều, tránh
  /// gọi API tóm tắt lại liên tục).
  @HiveField(17)
  Map<String, int> linkedContextCacheVersion;

  Conversation({
    required this.id,
    required this.title,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
    this.folderId,
    this.pinned = false,
    this.providerConfigId,
    this.systemPrompt = 'Bạn là một trợ lý AI hữu ích.',
    this.liveTokenEstimate = 0,
    List<String>? discussionProviderIds,
    this.reasoningEffortOverride,
    this.temperatureOverride,
    this.webSearchOverride,
    List<GeneratedFile>? generatedFiles,
    List<String>? linkedConversationIds,
    Map<String, String>? linkedContextCache,
    Map<String, int>? linkedContextCacheVersion,
  })  : discussionProviderIds = discussionProviderIds ?? [],
        generatedFiles = generatedFiles ?? [],
        linkedConversationIds = linkedConversationIds ?? [],
        linkedContextCache = linkedContextCache ?? {},
        linkedContextCacheVersion = linkedContextCacheVersion ?? {};
}

@HiveType(typeId: 6)
class ChatFolder extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  int colorValue;

  ChatFolder({required this.id, required this.name, this.colorValue = 0xFF6750A4});
}
