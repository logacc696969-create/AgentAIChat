import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../providers/chat_provider.dart';
import 'export_runner.dart';

/// Hiển thị bottom sheet cho phép người dùng chọn 1 tin nhắn (thường là câu
/// trả lời cuối của AI) và xuất ra .docx / .pptx / .xlsx / .zip source code.
/// File xuất ra sẽ tự động được ghi vào panel "File đã tạo" của đoạn chat.
class ExportMenu extends StatelessWidget {
  final Conversation conversation;
  final ChatProvider chat;
  final List<ChatMessage> assistantMessages;

  const ExportMenu({
    super.key,
    required this.conversation,
    required this.chat,
    required this.assistantMessages,
  });

  static Future<void> show(
    BuildContext context,
    Conversation conv,
    ChatProvider chat,
    List<ChatMessage> assistantMessages,
  ) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => ExportMenu(conversation: conv, chat: chat, assistantMessages: assistantMessages),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (assistantMessages.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Chưa có câu trả lời nào của AI trong đoạn chat này để xuất file.'),
      );
    }
    final last = assistantMessages.last;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Xuất câu trả lời gần nhất thành file', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('Word (.docx)'),
              onTap: () => _run(context, last, 'docx'),
            ),
            ListTile(
              leading: const Icon(Icons.slideshow_outlined),
              title: const Text('PowerPoint (.pptx)'),
              subtitle: const Text('Nội dung cần theo dạng slide: # tiêu đề, - gạch đầu dòng, --- ngăn slide'),
              onTap: () => _run(context, last, 'pptx'),
            ),
            ListTile(
              leading: const Icon(Icons.table_chart_outlined),
              title: const Text('Excel (.xlsx)'),
              subtitle: const Text('Nội dung cần theo dạng bảng, các cột cách nhau bởi |'),
              onTap: () => _run(context, last, 'xlsx'),
            ),
            ListTile(
              leading: const Icon(Icons.folder_zip_outlined),
              title: const Text('Source code dự án (.zip)'),
              subtitle: const Text('Tự nhận diện các code block có đường dẫn file để đóng gói'),
              onTap: () => _run(context, last, 'zip'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _run(BuildContext context, ChatMessage msg, String type) async {
    await ExportRunner.run(context: context, chat: chat, conv: conversation, sourceMessage: msg, type: type);
    if (context.mounted) Navigator.pop(context);
  }
}
