import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../models/generated_file.dart';
import '../models/message.dart';
import '../providers/chat_provider.dart';
import 'export_runner.dart';

/// Panel liệt kê mọi file (docx/pptx/xlsx/zip) đã xuất trong đoạn chat này —
/// giống panel Artifacts bên phải của Claude. Mở qua icon 📁 trên chat_screen.
class GeneratedFilesPanel extends StatelessWidget {
  final Conversation conversation;
  final ChatProvider chat;
  const GeneratedFilesPanel({super.key, required this.conversation, required this.chat});

  @override
  Widget build(BuildContext context) {
    final files = conversation.generatedFiles.reversed.toList(); // mới nhất trước

    return Drawer(
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('File đã tạo', style: Theme.of(context).textTheme.titleLarge),
            ),
            const Divider(height: 1),
            Expanded(
              child: files.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Chưa có file nào được xuất trong đoạn chat này.\n'
                          'Dùng nút 📎 cạnh ô nhắn tin để xuất docx/pptx/xlsx/zip từ câu trả lời AI.',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: files.length,
                      itemBuilder: (_, i) => _fileTile(context, files[i]),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fileTile(BuildContext context, GeneratedFile file) {
    return ListTile(
      leading: Icon(_iconFor(file.type)),
      title: Text(file.fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(_timeAgo(file.createdAt)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.ios_share, size: 20),
            tooltip: 'Chia sẻ lại',
            onPressed: () => _reshare(context, file),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, size: 20),
            tooltip: 'Xoá khỏi danh sách',
            onPressed: () => chat.removeGeneratedFile(conversation, file),
          ),
        ],
      ),
    );
  }

  Future<void> _reshare(BuildContext context, GeneratedFile file) async {
    ChatMessage? source;
    try {
      source = conversation.messages.firstWhere((m) => m.id == file.sourceMessageId);
    } catch (_) {
      source = null;
    }
    if (source == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tin nhắn gốc đã bị xoá, không thể xuất lại file này.')),
      );
      return;
    }
    // Xuất lại NGAY TỪ nội dung gốc (không lưu trữ bytes file lâu dài) rồi
    // mở share sheet lần nữa — ghi thêm 1 bản ghi mới vào danh sách.
    await ExportRunner.run(
      context: context,
      chat: chat,
      conv: conversation,
      sourceMessage: source,
      type: file.type,
    );
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'docx':
        return Icons.description_outlined;
      case 'pptx':
        return Icons.slideshow_outlined;
      case 'xlsx':
        return Icons.table_chart_outlined;
      case 'zip':
        return Icons.folder_zip_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }

  String _timeAgo(DateTime t) {
    final diff = DateTime.now().difference(t);
    if (diff.inMinutes < 1) return 'Vừa xong';
    if (diff.inMinutes < 60) return '${diff.inMinutes} phút trước';
    if (diff.inHours < 24) return '${diff.inHours} giờ trước';
    return '${diff.inDays} ngày trước';
  }
}
