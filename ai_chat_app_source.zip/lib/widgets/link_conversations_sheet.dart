import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../providers/chat_provider.dart';

/// Chọn (multi-select) các đoạn chat KHÁC để liên kết tới đoạn chat hiện
/// tại. Nội dung đoạn chat liên kết sẽ được đưa vào ngữ cảnh dưới dạng bản
/// tóm tắt RÚT GỌN CỨNG (xem ContextManager.refreshLinkedContext) — không
/// bao giờ gửi nguyên văn, đảm bảo không phình to token dù đoạn chat kia
/// dài bao nhiêu.
class LinkConversationsSheet extends StatefulWidget {
  final Conversation conversation;
  final ChatProvider chat;
  const LinkConversationsSheet({super.key, required this.conversation, required this.chat});

  static Future<void> show(BuildContext context, Conversation conv, ChatProvider chat) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => LinkConversationsSheet(conversation: conv, chat: chat),
    );
  }

  @override
  State<LinkConversationsSheet> createState() => _LinkConversationsSheetState();
}

class _LinkConversationsSheetState extends State<LinkConversationsSheet> {
  late Set<String> _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.conversation.linkedConversationIds.toSet();
  }

  @override
  Widget build(BuildContext context) {
    final others = widget.chat.storage.conversations.values
        .where((c) => c.id != widget.conversation.id)
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Liên kết đoạn chat khác', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'Nội dung đoạn chat được chọn sẽ đưa vào dưới dạng TÓM TẮT RÚT '
              'GỌN (tối đa vài trăm ký tự/link, tái dùng cache khi có thể) — '
              'không bao giờ gửi nguyên văn, nên không phình to token dù đoạn '
              'chat kia dài bao nhiêu.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            if (others.isEmpty)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Chưa có đoạn chat nào khác để liên kết.'),
              ),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final c in others)
                    CheckboxListTile(
                      value: _selected.contains(c.id),
                      title: Text(c.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${c.messages.length} tin nhắn'),
                      onChanged: (v) => setState(() {
                        if (v == true) {
                          _selected.add(c.id);
                        } else {
                          _selected.remove(c.id);
                        }
                      }),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      await widget.chat.setLinkedConversations(widget.conversation, []);
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Gỡ hết liên kết'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: () async {
                      await widget.chat.setLinkedConversations(widget.conversation, _selected.toList());
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Lưu'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
