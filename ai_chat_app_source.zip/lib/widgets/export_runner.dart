import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../providers/chat_provider.dart';
import 'export/docx_export.dart';
import 'export/pptx_export.dart';
import 'export/xlsx_export.dart';
import 'export/code_zip_export.dart';
import '../utils/file_saver.dart';

/// Logic xuất file DÙNG CHUNG cho cả bottom sheet "Xuất tài liệu" (lần đầu)
/// và panel "File đã tạo" (xuất lại). Tách riêng để không lặp code, và để
/// panel bên phải có thể "xuất lại" đúng y hệt cách đã tạo lần đầu.
class ExportRunner {
  /// Xuất + lưu + ghi nhận vào panel "File đã tạo". Trả về tên file nếu
  /// thành công, null nếu không xuất được (ví dụ zip không tìm thấy code
  /// block hợp lệ).
  static Future<String?> run({
    required BuildContext context,
    required ChatProvider chat,
    required Conversation conv,
    required ChatMessage sourceMessage,
    required String type, // 'docx' | 'pptx' | 'xlsx' | 'zip'
  }) async {
    final content = sourceMessage.content;
    List<int>? bytes;
    String ext = type;

    switch (type) {
      case 'docx':
        bytes = DocxExporter.export(title: 'Tài liệu', markdownLike: content);
        break;
      case 'pptx':
        bytes = PptxExporter.export(content);
        break;
      case 'xlsx':
        bytes = XlsxExporter.export(content);
        break;
      case 'zip':
        bytes = CodeZipExporter.exportFromResponse(
          content,
          readmeExtra: '# Dự án được tạo bởi AgentAiChat\n\nGiải nén và push lên GitHub để build.',
        );
        break;
    }

    if (bytes == null) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không xuất được — nội dung nguồn không còn phù hợp định dạng này.')),
        );
      }
      return null;
    }

    final fileName = '${_prefixFor(type)}_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await FileSaver.saveAndShare(bytes, fileName);
    await chat.recordGeneratedFile(
      conv,
      fileName: fileName,
      type: type,
      sourceMessageId: sourceMessage.id,
    );
    return fileName;
  }

  static String _prefixFor(String type) {
    switch (type) {
      case 'docx':
        return 'tai_lieu';
      case 'pptx':
        return 'trinh_bay';
      case 'xlsx':
        return 'bang_tinh';
      case 'zip':
        return 'source_code';
      default:
        return 'file';
    }
  }
}
