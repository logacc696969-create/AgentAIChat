import 'package:hive/hive.dart';

part 'message.g.dart';

/// Vai trò của tin nhắn trong hội thoại.
@HiveType(typeId: 1)
enum MessageRole {
  @HiveField(0)
  system,
  @HiveField(1)
  user,
  @HiveField(2)
  assistant,
}

/// Một tin nhắn trong đoạn chat.
///
/// [isSummary] = true nghĩa là tin nhắn này KHÔNG phải do người dùng/model
/// tạo ra trực tiếp, mà là bản tóm tắt tự động của một loạt tin nhắn cũ hơn
/// (được sinh ra bởi ContextManager để tiết kiệm token). Khi build lại
/// request gửi lên API, các tin nhắn gốc đã bị tóm tắt sẽ không được gửi lại
/// nữa, chỉ gửi bản tóm tắt này thay thế.
@HiveType(typeId: 2)
class ChatMessage extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  MessageRole role;

  @HiveField(2)
  String content;

  @HiveField(3)
  DateTime createdAt;

  @HiveField(4)
  bool isSummary;

  @HiveField(5)
  int? approxTokens;

  /// true nếu tin nhắn đã bị "gấp" vào một bản tóm tắt phía sau
  /// (không còn được gửi lên API nữa, chỉ giữ lại để người dùng xem lịch sử).
  @HiveField(6)
  bool collapsedIntoSummary;

  /// true = tin nhắn chỉ mang tính hiển thị cho người dùng biết mốc sự kiện
  /// (ví dụ "Đã chuyển sang model X"), KHÔNG bao giờ được tính token hay gửi
  /// lên API. Dùng cho tính năng chuyển đổi model giữa chừng mà không tốn
  /// thêm token nào cho việc đánh dấu đó.
  @HiveField(7)
  bool isSystemNote;

  /// Khi hội thoại có NHIỀU model cùng tham gia thảo luận: 2 field này ghi
  /// nhận model nào đã tạo ra tin nhắn assistant này (id + tên hiển thị đã
  /// chụp lại tại thời điểm gửi, để vẫn hiển thị đúng dù sau này người dùng
  /// đổi tên/xoá provider đó). null = chat 1-model bình thường.
  @HiveField(8)
  String? speakerProviderId;

  @HiveField(9)
  String? speakerName;

  ChatMessage({
    required this.id,
    required this.role,
    required this.content,
    required this.createdAt,
    this.isSummary = false,
    this.approxTokens,
    this.collapsedIntoSummary = false,
    this.isSystemNote = false,
    this.speakerProviderId,
    this.speakerName,
  });
}
