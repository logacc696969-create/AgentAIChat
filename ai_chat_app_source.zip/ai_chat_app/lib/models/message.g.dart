// GENERATED CODE (viết tay thay cho build_runner để tránh phụ thuộc mạng khi build)
// Nếu bạn sửa message.dart, hãy cập nhật tương ứng file này, hoặc chạy:
//   flutter pub run build_runner build --delete-conflicting-outputs
// sau khi đã xóa các dòng `part 'xxx.g.dart';`-generated thủ công bên dưới.

part of 'message.dart';

class MessageRoleAdapter extends TypeAdapter<MessageRole> {
  @override
  final int typeId = 1;

  @override
  MessageRole read(BinaryReader reader) {
    final index = reader.readByte();
    switch (index) {
      case 0:
        return MessageRole.system;
      case 1:
        return MessageRole.user;
      case 2:
        return MessageRole.assistant;
      default:
        return MessageRole.user;
    }
  }

  @override
  void write(BinaryWriter writer, MessageRole obj) {
    switch (obj) {
      case MessageRole.system:
        writer.writeByte(0);
        break;
      case MessageRole.user:
        writer.writeByte(1);
        break;
      case MessageRole.assistant:
        writer.writeByte(2);
        break;
    }
  }
}

class ChatMessageAdapter extends TypeAdapter<ChatMessage> {
  @override
  final int typeId = 2;

  @override
  ChatMessage read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ChatMessage(
      id: fields[0] as String,
      role: fields[1] as MessageRole,
      content: fields[2] as String,
      createdAt: fields[3] as DateTime,
      isSummary: fields[4] == null ? false : fields[4] as bool,
      approxTokens: fields[5] as int?,
      collapsedIntoSummary: fields[6] == null ? false : fields[6] as bool,
      isSystemNote: fields[7] == null ? false : fields[7] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ChatMessage obj) {
    writer
      ..writeByte(8)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.role)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.createdAt)
      ..writeByte(4)
      ..write(obj.isSummary)
      ..writeByte(5)
      ..write(obj.approxTokens)
      ..writeByte(6)
      ..write(obj.collapsedIntoSummary)
      ..writeByte(7)
      ..write(obj.isSystemNote);
  }
}
