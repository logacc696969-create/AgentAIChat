import 'package:hive/hive.dart';
import 'message.dart';

part 'conversation.g.dart';

@HiveType(typeId: 5)
class Conversation extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  List<ChatMessage> messages;

  @HiveField(3)
  DateTime createdAt;

  @HiveField(4)
  DateTime updatedAt;

  @HiveField(5)
  String? folderId;

  @HiveField(6)
  bool pinned;

  @HiveField(7)
  String? providerConfigId; // nếu null -> dùng provider mặc định

  @HiveField(8)
  String systemPrompt;

  /// Tổng số token đã ước lượng còn "sống" trong ngữ cảnh hiện tại
  /// (sau khi đã trừ phần bị tóm tắt/gấp lại).
  @HiveField(9)
  int liveTokenEstimate;

  /// Danh sách id các Provider CÙNG tham gia thảo luận trong đoạn chat này.
  /// Rỗng = chat 1-model bình thường. Có ≥2 phần tử = mỗi tin nhắn người
  /// dùng gửi sẽ được LẦN LƯỢT từng model trong danh sách trả lời (mỗi model
  /// thấy được câu trả lời của các model trước đó trong cùng lượt).
  @HiveField(10)
  List<String> discussionProviderIds;

  /// Override RIÊNG cho đoạn chat này, đổi được ngay trong lúc chat (không
  /// cần vào Cài đặt Provider) — null = dùng mặc định của Provider.
  @HiveField(11)
  String? reasoningEffortOverride;

  @HiveField(12)
  double? temperatureOverride;

  /// Override tìm kiếm web riêng cho đoạn chat này: null = dùng mặc định
  /// của Provider, true/false = ép bật/tắt bất kể mặc định Provider.
  @HiveField(13)
  bool? webSearchOverride;

  Conversation({
    required this.id,
    required this.title,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
    this.folderId,
    this.pinned = false,
    this.providerConfigId,
    this.systemPrompt = 'Bạn là một trợ lý AI hữu ích.',
    this.liveTokenEstimate = 0,
    List<String>? discussionProviderIds,
    this.reasoningEffortOverride,
    this.temperatureOverride,
    this.webSearchOverride,
  }) : discussionProviderIds = discussionProviderIds ?? [];
}

@HiveType(typeId: 6)
class ChatFolder extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  int colorValue;

  ChatFolder({required this.id, required this.name, this.colorValue = 0xFF6750A4});
}
