import 'package:hive/hive.dart';
import 'message.dart';

part 'conversation.g.dart';

@HiveType(typeId: 5)
class Conversation extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  List<ChatMessage> messages;

  @HiveField(3)
  DateTime createdAt;

  @HiveField(4)
  DateTime updatedAt;

  @HiveField(5)
  String? folderId;

  @HiveField(6)
  bool pinned;

  @HiveField(7)
  String? providerConfigId; // nếu null -> dùng provider mặc định

  @HiveField(8)
  String systemPrompt;

  /// Tổng số token đã ước lượng còn "sống" trong ngữ cảnh hiện tại
  /// (sau khi đã trừ phần bị tóm tắt/gấp lại).
  @HiveField(9)
  int liveTokenEstimate;

  Conversation({
    required this.id,
    required this.title,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
    this.folderId,
    this.pinned = false,
    this.providerConfigId,
    this.systemPrompt = 'Bạn là một trợ lý AI hữu ích.',
    this.liveTokenEstimate = 0,
  });
}

@HiveType(typeId: 6)
class ChatFolder extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  int colorValue;

  ChatFolder({required this.id, required this.name, this.colorValue = 0xFF6750A4});
}
