// GENERATED CODE (viết tay thay cho build_runner)
part of 'provider_config.dart';

class ApiFormatAdapter extends TypeAdapter<ApiFormat> {
  @override
  final int typeId = 3;

  @override
  ApiFormat read(BinaryReader reader) {
    final index = reader.readByte();
    switch (index) {
      case 0:
        return ApiFormat.openaiCompatible;
      case 1:
        return ApiFormat.anthropicCompatible;
      case 2:
        return ApiFormat.custom;
      default:
        return ApiFormat.openaiCompatible;
    }
  }

  @override
  void write(BinaryWriter writer, ApiFormat obj) {
    switch (obj) {
      case ApiFormat.openaiCompatible:
        writer.writeByte(0);
        break;
      case ApiFormat.anthropicCompatible:
        writer.writeByte(1);
        break;
      case ApiFormat.custom:
        writer.writeByte(2);
        break;
    }
  }
}

class ProviderConfigAdapter extends TypeAdapter<ProviderConfig> {
  @override
  final int typeId = 4;

  @override
  ProviderConfig read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ProviderConfig(
      id: fields[0] as String,
      name: fields[1] as String,
      baseUrl: fields[2] as String,
      apiKey: fields[3] as String,
      model: fields[4] as String,
      format: fields[5] as ApiFormat,
      maxContextTokens: fields[6] == null ? 128000 : fields[6] as int,
      temperature: fields[7] == null ? 0.7 : fields[7] as double,
      customRequestTemplate: fields[8] as String?,
      isDefault: fields[9] == null ? false : fields[9] as bool,
      dailyTokenQuota: fields[10] as int?,
      reasoningEffort: fields[11] as String?,
      webSearchEnabled: fields[12] == null ? false : fields[12] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, ProviderConfig obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.baseUrl)
      ..writeByte(3)
      ..write(obj.apiKey)
      ..writeByte(4)
      ..write(obj.model)
      ..writeByte(5)
      ..write(obj.format)
      ..writeByte(6)
      ..write(obj.maxContextTokens)
      ..writeByte(7)
      ..write(obj.temperature)
      ..writeByte(8)
      ..write(obj.customRequestTemplate)
      ..writeByte(9)
      ..write(obj.isDefault)
      ..writeByte(10)
      ..write(obj.dailyTokenQuota)
      ..writeByte(11)
      ..write(obj.reasoningEffort)
      ..writeByte(12)
      ..write(obj.webSearchEnabled);
  }
}
