import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';
import '../services/api_service.dart';
import '../services/context_manager.dart';
import '../services/storage_service.dart';
import '../services/token_estimator.dart';
import '../services/usage_service.dart';

class ChatProvider extends ChangeNotifier {
  final StorageService storage;
  final ApiService apiService = ApiService();
  late final ContextManager contextManager;
  late final UsageService usageService;

  Conversation? current;
  bool isStreaming = false;
  bool isSummarizing = false;
  String? lastError;

  final _uuid = const Uuid();

  ChatProvider(this.storage) {
    contextManager = ContextManager(apiService);
    usageService = UsageService(storage.settings);
  }

  // ---------------- Quản lý danh sách hội thoại / folder ----------------

  List<Conversation> conversationsInFolder(String? folderId) =>
      storage.conversationsInFolder(folderId);

  List<ChatFolder> get folders => storage.folders.values.toList();

  Future<Conversation> createConversation({String? folderId, ProviderConfig? provider}) async {
    final conv = Conversation(
      id: _uuid.v4(),
      title: 'Cuộc trò chuyện mới',
      messages: [],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      folderId: folderId,
      providerConfigId: provider?.id,
    );
    await storage.conversations.put(conv.id, conv);
    current = conv;
    notifyListeners();
    return conv;
  }

  Future<void> deleteConversation(String id) async {
    await storage.conversations.delete(id);
    if (current?.id == id) current = null;
    notifyListeners();
  }

  Future<void> renameConversation(Conversation c, String newTitle) async {
    c.title = newTitle;
    await c.save();
    notifyListeners();
  }

  Future<void> togglePin(Conversation c) async {
    c.pinned = !c.pinned;
    await c.save();
    notifyListeners();
  }

  Future<ChatFolder> createFolder(String name) async {
    final folder = ChatFolder(id: _uuid.v4(), name: name);
    await storage.folders.put(folder.id, folder);
    notifyListeners();
    return folder;
  }

  void selectConversation(Conversation c) {
    current = c;
    notifyListeners();
  }

  /// Chuyển model đang dùng cho đoạn chat NGAY GIỮA CHỪNG, không cần người
  /// dùng giải thích lại ngữ cảnh — và tiết kiệm token tối đa (xem chi tiết
  /// giải thích trong ContextManager.switchModel).
  Future<void> switchProvider(Conversation conv, ProviderConfig newProvider) async {
    final oldProvider = storage.providerFor(conv) ?? newProvider;
    isSummarizing = true;
    notifyListeners();
    try {
      await contextManager.switchModel(conv, oldProvider, newProvider);
      conv.providerConfigId = newProvider.id;
      conv.liveTokenEstimate = contextManager.buildContext(conv, newProvider).estimatedTokens;
      await conv.save();
    } finally {
      isSummarizing = false;
      notifyListeners();
    }
  }

  // ---------------- Gửi tin nhắn (lõi tối ưu token) ----------------

  /// Gửi tin nhắn của người dùng, TỰ ĐỘNG:
  /// 1. Kiểm tra & tóm tắt ngữ cảnh cũ nếu hội thoại đã dài (tiết kiệm token).
  /// 2. Build context tối ưu (sliding window + summary) thay vì gửi toàn bộ.
  /// 3. Gọi API streaming, cập nhật UI theo từng chunk.
  Future<void> sendMessage(String text) async {
    final conv = current;
    if (conv == null) return;
    final provider = storage.providerFor(conv);
    if (provider == null) {
      lastError = 'Chưa cấu hình Provider API. Vào Cài đặt để thêm.';
      notifyListeners();
      return;
    }

    lastError = null;

    final userMsg = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.user,
      content: text,
      createdAt: DateTime.now(),
      approxTokens: TokenEstimator.estimateMessage(text),
    );
    conv.messages.add(userMsg);
    conv.updatedAt = DateTime.now();
    await conv.save();
    notifyListeners();

    // Bước 1: tự động tóm tắt nếu hội thoại đã dài / phức tạp, để giảm số
    // token phải gửi lại ở các lượt sau — đây chính là điểm "tiết kiệm token
    // tối ưu nhất" khi đoạn chat dài ra.
    if (contextManager.needsSummarization(conv, provider)) {
      isSummarizing = true;
      notifyListeners();
      try {
        await contextManager.summarizeIfNeeded(
          conv,
          provider,
          onUsage: (usage) => usageService.record(provider.id, usage),
        );
        await conv.save();
      } catch (e) {
        // Nếu tóm tắt lỗi (vd. mất mạng), vẫn tiếp tục gửi bằng sliding window
        // thường, không chặn người dùng.
      }
      isSummarizing = false;
      notifyListeners();
    }

    // Bước 2: build context tối ưu thay vì gửi toàn bộ lịch sử.
    final built = contextManager.buildContext(conv, provider);
    conv.liveTokenEstimate = built.estimatedTokens;

    final assistantMsg = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    conv.messages.add(assistantMsg);
    isStreaming = true;
    notifyListeners();

    try {
      final buffer = StringBuffer();
      await for (final chunk in apiService.sendMessageStream(
        config: provider,
        messages: built.messages,
        onUsage: (usage) {
          usageService.record(provider.id, usage);
          // Có số thật rồi thì dùng luôn thay vì ước lượng, cho các quyết
          // định tóm tắt/hiển thị ở lượt sau chính xác hơn.
          conv.liveTokenEstimate = usage.totalTokens;
        },
      )) {
        buffer.write(chunk);
        assistantMsg.content = buffer.toString();
        notifyListeners();
      }
      assistantMsg.approxTokens = TokenEstimator.estimateMessage(assistantMsg.content);

      if (conv.title == 'Cuộc trò chuyện mới' && conv.messages.length >= 2) {
        conv.title = text.length > 40 ? '${text.substring(0, 40)}...' : text;
      }
    } catch (e) {
      lastError = e.toString();
      assistantMsg.content = assistantMsg.content.isEmpty
          ? '⚠️ Lỗi khi gọi API: $e'
          : assistantMsg.content;
    } finally {
      isStreaming = false;
      conv.updatedAt = DateTime.now();
      await conv.save();
      notifyListeners();
    }
  }

  /// Ước lượng % ngữ cảnh đang dùng so với giới hạn của model, để hiển thị
  /// thanh tiến trình token cho người dùng biết khi nào app sắp tự tóm tắt.
  double contextUsageRatio() {
    final conv = current;
    if (conv == null) return 0;
    final provider = storage.providerFor(conv);
    if (provider == null) return 0;
    return (conv.liveTokenEstimate / provider.maxContextTokens).clamp(0, 1);
  }

  @override
  void dispose() {
    apiService.dispose();
    super.dispose();
  }
}
