import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../models/provider_config.dart';
import '../providers/chat_provider.dart';

/// Cho phép chọn (multi-select) các Provider sẽ CÙNG tham gia thảo luận
/// trong đoạn chat hiện tại. Chọn 0 hoặc 1 provider = chat bình thường.
/// Chọn ≥2 = mỗi tin nhắn gửi lên sẽ được từng model lần lượt trả lời.
class DiscussionSetupSheet extends StatefulWidget {
  final Conversation conversation;
  final ChatProvider chat;
  const DiscussionSetupSheet({super.key, required this.conversation, required this.chat});

  static Future<void> show(BuildContext context, Conversation conv, ChatProvider chat) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => DiscussionSetupSheet(conversation: conv, chat: chat),
    );
  }

  @override
  State<DiscussionSetupSheet> createState() => _DiscussionSetupSheetState();
}

class _DiscussionSetupSheetState extends State<DiscussionSetupSheet> {
  late Set<String> _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.conversation.discussionProviderIds.toSet();
  }

  @override
  Widget build(BuildContext context) {
    final providers = widget.chat.storage.providers.values.toList();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Thảo luận nhóm nhiều model', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(
              'Chọn ≥2 model — mỗi tin nhắn bạn gửi sẽ được TỪNG model lần '
              'lượt trả lời, model sau thấy được ý kiến của model trước. '
              'Bỏ chọn hết hoặc chỉ chọn 1 để quay lại chat bình thường.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            if (providers.isEmpty)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Chưa có Provider nào — thêm ít nhất 2 provider trong Cài đặt trước.'),
              ),
            for (final p in providers)
              CheckboxListTile(
                value: _selected.contains(p.id),
                title: Text(p.name),
                subtitle: Text(p.model),
                onChanged: (v) => setState(() {
                  if (v == true) {
                    _selected.add(p.id);
                  } else {
                    _selected.remove(p.id);
                  }
                }),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      await widget.chat.setDiscussionProviders(widget.conversation, []);
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Tắt thảo luận nhóm'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: () async {
                      await widget.chat.setDiscussionProviders(widget.conversation, _selected.toList());
                      if (context.mounted) Navigator.pop(context);
                    },
                    child: const Text('Lưu'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
