import 'package:flutter/material.dart';
import '../models/message.dart';
import '../services/export/docx_export.dart';
import '../services/export/pptx_export.dart';
import '../services/export/xlsx_export.dart';
import '../services/export/code_zip_export.dart';
import '../utils/file_saver.dart';

/// Hiển thị bottom sheet cho phép người dùng chọn 1 tin nhắn (thường là câu
/// trả lời cuối của AI) và xuất ra .docx / .pptx / .xlsx / .zip source code.
class ExportMenu extends StatelessWidget {
  final List<ChatMessage> assistantMessages;
  const ExportMenu({super.key, required this.assistantMessages});

  static Future<void> show(BuildContext context, List<ChatMessage> assistantMessages) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => ExportMenu(assistantMessages: assistantMessages),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (assistantMessages.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Chưa có câu trả lời nào của AI trong đoạn chat này để xuất file.'),
      );
    }
    final last = assistantMessages.last;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Xuất câu trả lời gần nhất thành file', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('Word (.docx)'),
              onTap: () => _exportDocx(context, last.content),
            ),
            ListTile(
              leading: const Icon(Icons.slideshow_outlined),
              title: const Text('PowerPoint (.pptx)'),
              subtitle: const Text('Nội dung cần theo dạng slide: # tiêu đề, - gạch đầu dòng, --- ngăn slide'),
              onTap: () => _exportPptx(context, last.content),
            ),
            ListTile(
              leading: const Icon(Icons.table_chart_outlined),
              title: const Text('Excel (.xlsx)'),
              subtitle: const Text('Nội dung cần theo dạng bảng, các cột cách nhau bởi |'),
              onTap: () => _exportXlsx(context, last.content),
            ),
            ListTile(
              leading: const Icon(Icons.folder_zip_outlined),
              title: const Text('Source code dự án (.zip)'),
              subtitle: const Text('Tự nhận diện các code block có đường dẫn file để đóng gói'),
              onTap: () => _exportZip(context, last.content),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _exportDocx(BuildContext context, String content) async {
    final bytes = DocxExporter.export(title: 'Tài liệu', markdownLike: content);
    await FileSaver.saveAndShare(bytes, 'tai_lieu_${DateTime.now().millisecondsSinceEpoch}.docx');
    if (context.mounted) Navigator.pop(context);
  }

  Future<void> _exportPptx(BuildContext context, String content) async {
    final bytes = PptxExporter.export(content);
    await FileSaver.saveAndShare(bytes, 'trinh_bay_${DateTime.now().millisecondsSinceEpoch}.pptx');
    if (context.mounted) Navigator.pop(context);
  }

  Future<void> _exportXlsx(BuildContext context, String content) async {
    final bytes = XlsxExporter.export(content);
    await FileSaver.saveAndShare(bytes, 'bang_tinh_${DateTime.now().millisecondsSinceEpoch}.xlsx');
    if (context.mounted) Navigator.pop(context);
  }

  Future<void> _exportZip(BuildContext context, String content) async {
    final bytes = CodeZipExporter.exportFromResponse(
      content,
      readmeExtra: '# Dự án được tạo bởi AI Chat App\n\nGiải nén và push lên GitHub để build.',
    );
    if (bytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không tìm thấy code block có đường dẫn file trong câu trả lời này.')),
      );
      return;
    }
    await FileSaver.saveAndShare(bytes, 'source_code_${DateTime.now().millisecondsSinceEpoch}.zip');
    if (context.mounted) Navigator.pop(context);
  }
}
