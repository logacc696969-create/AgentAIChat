import 'package:hive_flutter/hive_flutter.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';

/// Lớp truy cập dữ liệu local. Toàn bộ dữ liệu (hội thoại, cấu hình API key)
/// được lưu HOÀN TOÀN trên máy người dùng qua Hive — không có backend nào
/// của app, vì app chỉ là client gọi thẳng tới API do người dùng tự cấu hình.
class StorageService {
  static const _convBox = 'conversations';
  static const _folderBox = 'folders';
  static const _providerBox = 'providers';
  static const _settingsBox = 'settings';

  late Box<Conversation> conversations;
  late Box<ChatFolder> folders;
  late Box<ProviderConfig> providers;
  late Box settings;

  Future<void> init() async {
    await Hive.initFlutter();

    Hive.registerAdapter(MessageRoleAdapter());
    Hive.registerAdapter(ChatMessageAdapter());
    Hive.registerAdapter(ApiFormatAdapter());
    Hive.registerAdapter(ProviderConfigAdapter());
    Hive.registerAdapter(ConversationAdapter());
    Hive.registerAdapter(ChatFolderAdapter());

    conversations = await Hive.openBox<Conversation>(_convBox);
    folders = await Hive.openBox<ChatFolder>(_folderBox);
    providers = await Hive.openBox<ProviderConfig>(_providerBox);
    settings = await Hive.openBox(_settingsBox);
  }

  ProviderConfig? get defaultProvider {
    try {
      return providers.values.firstWhere((p) => p.isDefault);
    } catch (_) {
      return providers.values.isNotEmpty ? providers.values.first : null;
    }
  }

  ProviderConfig? providerFor(Conversation c) {
    if (c.providerConfigId == null) return defaultProvider;
    try {
      return providers.values.firstWhere((p) => p.id == c.providerConfigId);
    } catch (_) {
      return defaultProvider;
    }
  }

  List<Conversation> conversationsInFolder(String? folderId) {
    final list = conversations.values.where((c) => c.folderId == folderId).toList();
    list.sort((a, b) {
      if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
    return list;
  }
}
