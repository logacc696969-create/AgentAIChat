import 'dart:convert';
import 'package:archive/archive.dart';

/// Trích xuất nhiều file code từ nội dung trả lời của model rồi đóng gói
/// thành .zip để người dùng tải về và push lên GitHub build.
///
/// Quy ước nhận diện file trong câu trả lời của AI (khuyến nghị đặt trong
/// system prompt của app khi người dùng yêu cầu "tạo dự án/source code"):
///
///   ```path/to/file.ext
///   nội dung file...
///   ```
///
/// hoặc dùng comment ngay dòng đầu code block:
///
///   ```
///   // file: lib/main.dart
///   nội dung file...
///   ```
class CodeZipExporter {
  static final _fencedWithPath = RegExp(
    r'```([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)\n([\s\S]*?)```',
  );
  static final _fencedWithFileComment = RegExp(
    r'```[a-zA-Z0-9]*\n(?:#|//|<!--)\s*file:\s*([a-zA-Z0-9_\-./]+)\s*(?:-->)?\n([\s\S]*?)```',
  );

  /// Trả về map { đường_dẫn_file: nội_dung }.
  static Map<String, String> extractFiles(String modelResponse) {
    final files = <String, String>{};

    for (final m in _fencedWithFileComment.allMatches(modelResponse)) {
      files[m.group(1)!.trim()] = m.group(2)!;
    }
    for (final m in _fencedWithPath.allMatches(modelResponse)) {
      final path = m.group(1)!.trim();
      if (!files.containsKey(path)) {
        files[path] = m.group(2)!;
      }
    }
    return files;
  }

  static List<int>? exportFromResponse(String modelResponse, {String? readmeExtra}) {
    final files = extractFiles(modelResponse);
    if (files.isEmpty) return null;
    return export(files, readmeExtra: readmeExtra);
  }

  static List<int> export(Map<String, String> files, {String? readmeExtra}) {
    final archive = Archive();
    files.forEach((path, content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    });

    if (readmeExtra != null) {
      final bytes = utf8.encode(readmeExtra);
      archive.addFile(ArchiveFile('README.md', bytes.length, bytes));
    }

    return ZipEncoder().encode(archive)!;
  }
}
