import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .docx hợp lệ (định dạng OOXML) mà KHÔNG cần thư viện Word nào,
/// bằng cách tự dựng cấu trúc zip + XML tối thiểu mà Word/LibreOffice/Google
/// Docs đều đọc được.
///
/// Cú pháp input hỗ trợ (markdown rút gọn, do model AI sinh ra trong chat):
///   # Heading 1
///   ## Heading 2
///   - bullet item
///   1. numbered item
///   (dòng thường) -> đoạn văn bình thường
class DocxExporter {
  static List<int> export({required String title, required String markdownLike}) {
    final bodyXml = StringBuffer();

    for (final rawLine in markdownLike.split('\n')) {
      final line = rawLine.trimRight();
      if (line.trim().isEmpty) {
        bodyXml.write('<w:p/>');
        continue;
      }
      if (line.startsWith('## ')) {
        bodyXml.write(_paragraph(_esc(line.substring(3)), style: 'Heading2'));
      } else if (line.startsWith('# ')) {
        bodyXml.write(_paragraph(_esc(line.substring(2)), style: 'Heading1'));
      } else if (line.trimLeft().startsWith('- ')) {
        bodyXml.write(_paragraph('•  ${_esc(line.trimLeft().substring(2))}'));
      } else if (RegExp(r'^\d+\.\s').hasMatch(line.trimLeft())) {
        bodyXml.write(_paragraph(_esc(line.trimLeft())));
      } else {
        bodyXml.write(_paragraph(_esc(line)));
      }
    }

    final documentXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${_paragraph(_esc(title), style: 'Title')}
    $bodyXml
    <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417"/></w:sectPr>
  </w:body>
</w:document>''';

    final archive = Archive();
    _addAll(archive, documentXml);

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }

  static String _paragraph(String text, {String? style}) {
    final styleTag = style != null ? '<w:pPr><w:pStyle w:val="$style"/></w:pPr>' : '';
    return '<w:p>$styleTag<w:r><w:t xml:space="preserve">$text</w:t></w:r></w:p>';
  }

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static void _addAll(Archive archive, String documentXml) {
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    add('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>''');

    add('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''');

    add('word/_rels/document.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>''');

    add('word/styles.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:rPr><w:b/><w:sz w:val="48"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="Heading 1"/><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="Heading 2"/><w:rPr><w:b/><w:sz w:val="26"/></w:rPr></w:style>
</w:styles>''');

    add('word/document.xml', documentXml);
  }
}
