import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .xlsx tối giản nhưng hợp lệ, từ dữ liệu dạng bảng.
///
/// Cú pháp input: mỗi dòng là 1 hàng, các cột cách nhau bằng ký tự "|" hoặc
/// tab. Ví dụ model AI sinh ra:
///
///   Tên | Số lượng | Đơn giá
///   Bút bi | 10 | 5000
///   Vở | 20 | 8000
class XlsxExporter {
  static List<int> export(String tableLike) {
    final rows = tableLike
        .split('\n')
        .where((l) => l.trim().isNotEmpty)
        .map((l) => l.contains('|')
            ? l.split('|').map((c) => c.trim()).toList()
            : l.split('\t').map((c) => c.trim()).toList())
        .toList();

    final sheetXml = StringBuffer();
    sheetXml.write('<sheetData>');
    for (int r = 0; r < rows.length; r++) {
      sheetXml.write('<row r="${r + 1}">');
      for (int c = 0; c < rows[r].length; c++) {
        final cellRef = '${_colLetter(c)}${r + 1}';
        final value = rows[r][c];
        final isNumber = num.tryParse(value) != null;
        if (isNumber) {
          sheetXml.write('<c r="$cellRef"><v>$value</v></c>');
        } else {
          sheetXml.write('<c r="$cellRef" t="inlineStr"><is><t xml:space="preserve">${_esc(value)}</t></is></c>');
        }
      }
      sheetXml.write('</row>');
    }
    sheetXml.write('</sheetData>');

    final archive = Archive();
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    add('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>''');

    add('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>''');

    add('xl/_rels/workbook.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>''');

    add('xl/workbook.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets>
</workbook>''');

    add('xl/worksheets/sheet1.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">$sheetXml</worksheet>''');

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }

  static String _colLetter(int index) {
    String letter = '';
    int i = index;
    while (i >= 0) {
      letter = String.fromCharCode(65 + (i % 26)) + letter;
      i = (i ~/ 26) - 1;
    }
    return letter;
  }

  static String _esc(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
