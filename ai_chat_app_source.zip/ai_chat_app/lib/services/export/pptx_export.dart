import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .pptx tối giản nhưng hợp lệ.
///
/// Cú pháp input: các slide cách nhau bằng dòng "---".
/// Trong mỗi slide, dòng đầu bắt đầu bằng "# " là tiêu đề, các dòng "- " là
/// bullet point nội dung. Ví dụ model AI sinh ra:
///
///   # Giới thiệu
///   - Vấn đề cần giải quyết
///   - Mục tiêu dự án
///   ---
///   # Giải pháp
///   - Kiến trúc tổng quan
class PptxExporter {
  static List<int> export(String slidesMarkdown) {
    final rawSlides = slidesMarkdown.split(RegExp(r'\n-{3,}\n'));
    final slides = rawSlides.where((s) => s.trim().isNotEmpty).toList();
    if (slides.isEmpty) slides.add('# (Trống)');

    final archive = Archive();
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    add('[Content_Types].xml', _contentTypes(slides.length));
    add('_rels/.rels', _rootRels);
    add('ppt/presentation.xml', _presentationXml(slides.length));
    add('ppt/_rels/presentation.xml.rels', _presentationRels(slides.length));

    for (int i = 0; i < slides.length; i++) {
      final lines = slides[i].trim().split('\n');
      final title = lines.isNotEmpty && lines.first.startsWith('#')
          ? lines.first.replaceFirst(RegExp(r'^#+\s*'), '')
          : 'Slide ${i + 1}';
      final bullets = lines
          .skip(lines.first.startsWith('#') ? 1 : 0)
          .where((l) => l.trim().isNotEmpty)
          .map((l) => l.trim().replaceFirst(RegExp(r'^-\s*'), ''))
          .toList();

      add('ppt/slides/slide${i + 1}.xml', _slideXml(title, bullets));
      add('ppt/slides/_rels/slide${i + 1}.xml.rels', _slideRels);
    }

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }

  static String _esc(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static String _contentTypes(int n) {
    final overrides = List.generate(
      n,
      (i) => '<Override PartName="/ppt/slides/slide${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>',
    ).join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
  $overrides
</Types>''';
  }

  static const _rootRels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>''';

  static String _presentationXml(int n) {
    final sldIds = List.generate(
      n,
      (i) => '<p:sldId id="${256 + i}" r:id="rId${i + 2}"/>',
    ).join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:sldIdLst>$sldIds</p:sldIdLst>
  <p:sldSz cx="9144000" cy="6858000"/>
  <p:notesSz cx="6858000" cy="9144000"/>
</p:presentation>''';
  }

  static String _presentationRels(int n) {
    final rels = List.generate(
      n,
      (i) => '<Relationship Id="rId${i + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i + 1}.xml"/>',
    ).join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$rels</Relationships>''';
  }

  static const _slideRels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>''';

  static String _slideXml(String title, List<String> bullets) {
    final bulletParas = bullets
        .map((b) => '<a:p><a:r><a:rPr lang="vi-VN" sz="2000"/><a:t>${_esc(b)}</a:t></a:r></a:p>')
        .join();
    return '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:cSld>
    <p:spTree>
      <p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>
      <p:grpSpPr/>
      <p:sp>
        <p:nvSpPr><p:cNvPr id="2" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="457200" y="274638"/><a:ext cx="8229600" cy="1143000"/></a:xfrm></p:spPr>
        <p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="vi-VN" sz="3200" b="1"/><a:t>${_esc(title)}</a:t></a:r></a:p></p:txBody>
      </p:sp>
      <p:sp>
        <p:nvSpPr><p:cNvPr id="3" name="Content"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr>
        <p:spPr><a:xfrm><a:off x="457200" y="1600200"/><a:ext cx="8229600" cy="4525963"/></a:xfrm></p:spPr>
        <p:txBody><a:bodyPr/><a:lstStyle/>$bulletParas</p:txBody>
      </p:sp>
    </p:spTree>
  </p:cSld>
</p:sld>''';
  }
}
