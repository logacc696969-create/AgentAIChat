import 'package:hive/hive.dart';
import 'api_service.dart';

/// Ghi nhận & truy vấn số token THẬT đã dùng (lấy từ trường "usage" mà API
/// trả về, KHÔNG phải ước lượng) — theo từng provider, theo từng ngày.
///
/// Lưu trong box "settings" (Hive box thường, không cần model/adapter riêng)
/// dưới dạng key "usage:{providerId}:{yyyy-MM-dd}" -> {"prompt": x,
/// "completion": y, "requests": n}.
class UsageService {
  final Box settingsBox;
  UsageService(this.settingsBox);

  String _key(String providerId, DateTime day) {
    final d = '${day.year.toString().padLeft(4, '0')}-'
        '${day.month.toString().padLeft(2, '0')}-'
        '${day.day.toString().padLeft(2, '0')}';
    return 'usage:$providerId:$d';
  }

  Future<void> record(String providerId, ApiUsage usage) async {
    final key = _key(providerId, DateTime.now());
    final raw = settingsBox.get(key);
    final current = raw is Map
        ? Map<String, dynamic>.from(raw)
        : {'prompt': 0, 'completion': 0, 'requests': 0};

    current['prompt'] = (current['prompt'] as int) + usage.promptTokens;
    current['completion'] = (current['completion'] as int) + usage.completionTokens;
    current['requests'] = (current['requests'] as int) + 1;

    await settingsBox.put(key, current);
  }

  /// Tổng token đã dùng hôm nay cho 1 provider.
  DailyUsage todayUsage(String providerId) => _readDay(providerId, DateTime.now());

  /// Tổng token đã dùng từ đầu tháng tới nay cho 1 provider.
  MonthUsage monthUsage(String providerId) {
    final now = DateTime.now();
    int prompt = 0, completion = 0, requests = 0;
    for (int d = 1; d <= now.day; d++) {
      final day = DateTime(now.year, now.month, d);
      final u = _readDay(providerId, day);
      prompt += u.promptTokens;
      completion += u.completionTokens;
      requests += u.requests;
    }
    return MonthUsage(promptTokens: prompt, completionTokens: completion, requests: requests);
  }

  DailyUsage _readDay(String providerId, DateTime day) {
    final raw = settingsBox.get(_key(providerId, day));
    if (raw is! Map) return DailyUsage(promptTokens: 0, completionTokens: 0, requests: 0);
    return DailyUsage(
      promptTokens: (raw['prompt'] ?? 0) as int,
      completionTokens: (raw['completion'] ?? 0) as int,
      requests: (raw['requests'] ?? 0) as int,
    );
  }
}

class DailyUsage {
  final int promptTokens;
  final int completionTokens;
  final int requests;
  DailyUsage({required this.promptTokens, required this.completionTokens, required this.requests});
  int get totalTokens => promptTokens + completionTokens;
}

class MonthUsage {
  final int promptTokens;
  final int completionTokens;
  final int requests;
  MonthUsage({required this.promptTokens, required this.completionTokens, required this.requests});
  int get totalTokens => promptTokens + completionTokens;
}
