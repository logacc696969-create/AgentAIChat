import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';
import 'api_service.dart';
import 'token_estimator.dart';

/// Kết quả build ngữ cảnh: danh sách message thực sự sẽ gửi lên API,
/// kèm số liệu để hiển thị cho người dùng biết app đang "tiết kiệm" bao nhiêu.
class BuiltContext {
  final List<ApiMessage> messages;
  final int estimatedTokens;
  final bool wasSummarized;
  BuiltContext(this.messages, this.estimatedTokens, this.wasSummarized);
}

/// Chiến lược tối ưu token khi hội thoại dài dần / công việc phức tạp dần:
///
/// 1. SLIDING WINDOW: luôn giữ nguyên văn N tin nhắn gần nhất (mặc định 12)
///    để model có đủ ngữ cảnh "nóng" cho lượt trả lời tiếp theo.
///
/// 2. AUTO-SUMMARIZE: khi tổng token ước tính của toàn hội thoại vượt quá
///    một ngưỡng (mặc định 65% maxContextTokens của provider đang dùng),
///    các tin nhắn cũ hơn cửa sổ trượt sẽ được gộp lại và gọi chính model
///    đó để tóm tắt thành 1 đoạn "summary" ngắn gọn, giữ lại các quyết định/
///    dữ kiện quan trọng. Từ lần gửi sau, các tin nhắn gốc đã tóm tắt sẽ
///    KHÔNG được gửi lại nữa — chỉ gửi bản tóm tắt (đánh dấu
///    [collapsedIntoSummary] = true trên message gốc để UI vẫn hiển thị được
///    lịch sử đầy đủ cho người dùng xem lại, nhưng không tốn token API nữa).
///
/// 3. INCREMENTAL SUMMARY: nếu hội thoại tiếp tục dài ra sau khi đã có 1 bản
///    tóm tắt, lần tóm tắt sau sẽ gộp "bản tóm tắt cũ + các tin nhắn mới cũ
///    hơn cửa sổ trượt" thành 1 bản tóm tắt mới duy nhất, tránh tình trạng
///    chồng nhiều summary chunk chiếm token.
///
/// 4. SAFETY MARGIN: luôn chừa 15% ngân sách token cho câu trả lời & sai số
///    ước lượng, không bao giờ build ngữ cảnh sát 100% giới hạn.
class ContextManager {
  static const int slidingWindowSize = 12;
  static const double summarizeTriggerRatio = 0.65;
  static const double safetyMarginRatio = 0.85;

  final ApiService _apiService;
  ContextManager(this._apiService);

  /// Kiểm tra xem có cần tóm tắt trước khi gửi lượt tiếp theo không.
  bool needsSummarization(Conversation conversation, ProviderConfig config) {
    final total = _estimateTotal(conversation);
    return total > config.maxContextTokens * summarizeTriggerRatio;
  }

  /// Thực hiện tóm tắt các tin nhắn cũ (nếu cần) rồi cập nhật vào conversation.
  /// Trả về true nếu đã thực hiện tóm tắt.
  Future<bool> summarizeIfNeeded(
    Conversation conversation,
    ProviderConfig config, {
    void Function(ApiUsage usage)? onUsage,
  }) async {
    if (!needsSummarization(conversation, config)) return false;

    final active = conversation.messages.where((m) => !m.collapsedIntoSummary).toList();
    if (active.length <= slidingWindowSize + 1) return false; // chưa đủ dài để tóm tắt

    final toCollapse = active.sublist(0, active.length - slidingWindowSize);
    final existingSummary = toCollapse.firstWhere(
      (m) => m.isSummary,
      orElse: () => ChatMessage(
        id: '',
        role: MessageRole.system,
        content: '',
        createdAt: DateTime.now(),
      ),
    );

    final transcript = toCollapse
        .where((m) => !m.isSummary)
        .map((m) => '${_roleLabel(m.role)}: ${m.content}')
        .join('\n\n');

    final prompt = '''
Hãy tóm tắt đoạn hội thoại sau thành một bản tóm tắt NGẮN GỌN nhưng đầy đủ,
giữ lại: quyết định đã chốt, dữ kiện/số liệu quan trọng, yêu cầu của người
dùng chưa được giải quyết, và ngữ cảnh cần thiết để tiếp tục hội thoại một
cách mạch lạc. Không thêm bình luận, chỉ trả về nội dung tóm tắt.

${existingSummary.content.isNotEmpty ? "BẢN TÓM TẮT TRƯỚC ĐÓ:\n${existingSummary.content}\n\n" : ""}
HỘI THOẠI CẦN TÓM TẮT THÊM:
$transcript
''';

    final summaryText = await _apiService.sendMessageOnce(
      config: config,
      messages: [ApiMessage('user', prompt)],
      onUsage: onUsage,
    );

    // Đánh dấu toàn bộ tin nhắn cũ đã bị gấp vào summary (vẫn giữ trong list
    // để người dùng xem lại lịch sử, nhưng không gửi lên API nữa).
    for (final m in toCollapse) {
      m.collapsedIntoSummary = true;
    }

    conversation.messages.removeWhere((m) => m.isSummary);
    conversation.messages.insert(
      0,
      ChatMessage(
        id: 'summary-${DateTime.now().millisecondsSinceEpoch}',
        role: MessageRole.system,
        content: summaryText,
        createdAt: DateTime.now(),
        isSummary: true,
        approxTokens: TokenEstimator.estimate(summaryText),
      ),
    );

    conversation.liveTokenEstimate = _estimateTotal(conversation);
    return true;
  }

  /// Build danh sách message thực sự sẽ gửi lên API cho lượt hiện tại,
  /// đã áp dụng cửa sổ trượt + safety margin. Gọi HÀM NÀY thay vì gửi thẳng
  /// toàn bộ conversation.messages để tiết kiệm token tối đa.
  BuiltContext buildContext(Conversation conversation, ProviderConfig config) {
    final budget = (config.maxContextTokens * safetyMarginRatio).floor();

    final systemMsg = ApiMessage('system', conversation.systemPrompt);
    int used = TokenEstimator.estimateMessage(conversation.systemPrompt);

    final summary = conversation.messages.where((m) => m.isSummary).toList();
    final active = conversation.messages
        .where((m) => !m.collapsedIntoSummary && !m.isSummary && !m.isSystemNote)
        .toList();

    final result = <ApiMessage>[systemMsg];

    if (summary.isNotEmpty) {
      final s = summary.first;
      result.add(ApiMessage(
        'system',
        'Tóm tắt phần đầu hội thoại (đã lược bớt để tiết kiệm ngữ cảnh):\n${s.content}',
      ));
      used += s.approxTokens ?? TokenEstimator.estimate(s.content);
    }

    // Giữ nguyên văn các tin nhắn gần nhất, tính ngược từ cuối lên cho tới
    // khi chạm ngân sách token còn lại.
    final keep = <ChatMessage>[];
    for (final m in active.reversed) {
      final t = m.approxTokens ?? TokenEstimator.estimateMessage(m.content);
      if (used + t > budget && keep.length >= 2) break; // luôn giữ tối thiểu 2 tin gần nhất
      keep.insert(0, m);
      used += t;
    }

    result.addAll(keep.map((m) => ApiMessage(_roleKey(m.role), m.content)));

    return BuiltContext(result, used, summary.isNotEmpty);
  }

  int _estimateTotal(Conversation conversation) {
    int total = TokenEstimator.estimate(conversation.systemPrompt);
    for (final m in conversation.messages) {
      if (m.isSystemNote) continue; // mốc chuyển model: hiển thị UI, không tốn token
      if (m.collapsedIntoSummary && !m.isSummary) continue;
      total += m.approxTokens ?? TokenEstimator.estimateMessage(m.content);
    }
    return total;
  }

  /// Gọi khi người dùng CHUYỂN SANG MODEL KHÁC giữa chừng đoạn chat.
  ///
  /// Điểm mấu chốt tiết kiệm token: hàm này KHÔNG gửi lại toàn bộ lịch sử
  /// cho model mới. Nó chỉ:
  ///   1. Chèn 1 tin nhắn "mốc" (isSystemNote) để người dùng thấy trực quan
  ///      điểm chuyển đổi — tin nhắn này không được tính token.
  ///   2. Kiểm tra bản tóm tắt hiện có (nếu có) còn phù hợp với giới hạn
  ///      ngữ cảnh của model MỚI hay không:
  ///      - Nếu model mới có ngữ cảnh lớn hơn hoặc bằng model cũ: TÁI SỬ
  ///        DỤNG NGUYÊN VẸN bản tóm tắt đã có, không tốn thêm 1 token API
  ///        nào để tóm tắt lại.
  ///      - Nếu model mới có ngữ cảnh nhỏ hơn đáng kể (ví dụ chuyển từ model
  ///        200K xuống model 8K), mới cần tóm tắt lại (nén thêm) — và khi đó
  ///        sẽ tóm tắt DỰA TRÊN bản tóm tắt cũ (rẻ hơn nhiều so với tóm tắt
  ///        lại từ đầu toàn bộ lịch sử gốc).
  /// Nhờ vậy, lượt gửi đầu tiên cho model mới có chi phí token tương đương
  /// (hoặc RẺ HƠN) lượt gửi cuối cùng cho model cũ — không bao giờ "đốt"
  /// nhiều token hơn để tiếp tục.
  Future<void> switchModel(
    Conversation conversation,
    ProviderConfig oldProvider,
    ProviderConfig newProvider,
  ) async {
    final noteId = 'switch-${DateTime.now().millisecondsSinceEpoch}';
    conversation.messages.add(ChatMessage(
      id: noteId,
      role: MessageRole.system,
      content: 'Đã chuyển từ "${oldProvider.name}" sang "${newProvider.name}" — '
          'tiếp tục nguyên ngữ cảnh, không phải giải thích lại.',
      createdAt: DateTime.now(),
      isSystemNote: true,
    ));

    // Nếu model mới có ngữ cảnh nhỏ hơn hẳn (< 90% model cũ) và hội thoại
    // hiện đã vượt ngưỡng tóm tắt của model mới, thì tóm tắt (nén thêm) NGAY
    // trước khi người dùng nhắn tiếp — để lượt gửi đầu tiên cho model mới
    // không bị lỗi "vượt giới hạn ngữ cảnh" và vẫn tối ưu token nhất có thể.
    final newBudgetSmaller = newProvider.maxContextTokens < oldProvider.maxContextTokens * 0.9;
    if (newBudgetSmaller && needsSummarization(conversation, newProvider)) {
      await summarizeIfNeeded(conversation, newProvider);
    }
    // Ngược lại (model mới >= model cũ): CHỦ ĐỘNG KHÔNG gọi tóm tắt lại —
    // bản tóm tắt + sliding window hiện có được tái sử dụng nguyên vẹn ở
    // buildContext(), tiết kiệm toàn bộ chi phí token của một lượt tóm tắt.
  }

  String _roleKey(MessageRole r) {
    switch (r) {
      case MessageRole.system:
        return 'system';
      case MessageRole.user:
        return 'user';
      case MessageRole.assistant:
        return 'assistant';
    }
  }

  String _roleLabel(MessageRole r) {
    switch (r) {
      case MessageRole.system:
        return 'Hệ thống';
      case MessageRole.user:
        return 'Người dùng';
      case MessageRole.assistant:
        return 'Trợ lý';
    }
  }
}
