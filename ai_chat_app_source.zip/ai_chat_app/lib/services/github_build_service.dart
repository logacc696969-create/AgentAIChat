import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/provider_config.dart';
import 'api_service.dart';

/// Tự động hoá vòng lặp "build → lỗi → tự sửa → build lại" bằng GitHub API,
/// KHÔNG cần biên dịch trên điện thoại (điều đó không khả thi). Toàn bộ việc
/// build thật diễn ra trên máy chủ GitHub Actions (miễn phí cho repo public,
/// có giới hạn phút chạy cho repo private) — app chỉ điều phối qua HTTP.
///
/// Yêu cầu người dùng cung cấp:
///  - GitHub Personal Access Token (PAT) có quyền "repo" + "workflow".
///  - owner/repo đích (repo cần đã tồn tại và có sẵn workflow build, ví dụ
///    file .github/workflows/build_apk.yml đã có trong project).
///
/// Quy trình applyAndBuildUntilSuccess():
///  1. Đẩy (tạo/update) toàn bộ file code lên nhánh chỉ định qua Contents API.
///  2. Kích hoạt workflow bằng "workflow_dispatch".
///  3. Poll trạng thái run cho tới khi hoàn thành.
///  4. Nếu FAIL: tải log lỗi, gửi kèm code hiện tại cho model AI để nó tự
///     sinh ra bản vá (diff dạng "file: nội dung mới"), áp dụng bản vá, quay
///     lại bước 1. Lặp tối đa [maxAttempts] lần.
///  5. Nếu SUCCESS: lấy link tải artifact (file APK) trả về cho UI.
class GithubBuildService {
  final String token;
  final String owner;
  final String repo;
  final String branch;
  final http.Client _client = http.Client();

  GithubBuildService({
    required this.token,
    required this.owner,
    required this.repo,
    this.branch = 'main',
  });

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  /// Đẩy nhiều file cùng lúc (tạo mới hoặc update nếu đã tồn tại — tự lấy sha
  /// hiện có để tránh lỗi conflict).
  Future<void> pushFiles(Map<String, String> pathToContent, {String message = 'chore: auto update by AI'}) async {
    for (final entry in pathToContent.entries) {
      await _putFile(entry.key, entry.value, message);
    }
  }

  Future<void> _putFile(String path, String content, String message) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/contents/$path');

    String? sha;
    final getResp = await _client.get(uri.replace(queryParameters: {'ref': branch}), headers: _headers);
    if (getResp.statusCode == 200) {
      sha = jsonDecode(getResp.body)['sha'] as String?;
    }

    final resp = await _client.put(
      uri,
      headers: _headers,
      body: jsonEncode({
        'message': message,
        'content': base64Encode(utf8.encode(content)),
        'branch': branch,
        if (sha != null) 'sha': sha,
      }),
    );

    if (resp.statusCode != 200 && resp.statusCode != 201) {
      throw Exception('Đẩy file $path thất bại (${resp.statusCode}): ${resp.body}');
    }
  }

  /// Kích hoạt workflow build. [workflowFile] là tên file trong
  /// .github/workflows/, ví dụ "build_apk.yml".
  Future<void> triggerWorkflow(String workflowFile) async {
    final uri = Uri.https(
      'api.github.com',
      '/repos/$owner/$repo/actions/workflows/$workflowFile/dispatches',
    );
    final resp = await _client.post(
      uri,
      headers: _headers,
      body: jsonEncode({'ref': branch}),
    );
    if (resp.statusCode != 204) {
      throw Exception('Không kích hoạt được workflow (${resp.statusCode}): ${resp.body}');
    }
  }

  /// Chờ và trả về run mới nhất của workflow (poll mỗi [interval]).
  Future<Map<String, dynamic>> waitForRunCompletion(
    String workflowFile, {
    Duration interval = const Duration(seconds: 10),
    Duration timeout = const Duration(minutes: 15),
  }) async {
    final started = DateTime.now();
    // Đợi vài giây để GitHub kịp tạo run mới sau khi dispatch.
    await Future.delayed(const Duration(seconds: 5));

    while (DateTime.now().difference(started) < timeout) {
      final uri = Uri.https(
        'api.github.com',
        '/repos/$owner/$repo/actions/workflows/$workflowFile/runs',
        {'branch': branch, 'per_page': '1'},
      );
      final resp = await _client.get(uri, headers: _headers);
      if (resp.statusCode == 200) {
        final runs = jsonDecode(resp.body)['workflow_runs'] as List;
        if (runs.isNotEmpty) {
          final run = runs.first as Map<String, dynamic>;
          if (run['status'] == 'completed') return run;
        }
      }
      await Future.delayed(interval);
    }
    throw Exception('Hết thời gian chờ build (timeout).');
  }

  /// Lấy nội dung log (dạng text) của 1 run bị lỗi, để đưa cho AI đọc và sửa.
  Future<String> fetchRunLog(int runId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/runs/$runId/logs');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) {
      throw Exception('Không tải được log (${resp.statusCode}).');
    }
    // GitHub trả về file .zip chứa nhiều log text — ở mức đơn giản, phần này
    // nên được giải nén bằng package `archive` (đã có sẵn trong project) rồi
    // gộp các *.txt lại thành 1 chuỗi để đưa cho AI phân tích.
    return utf8.decode(resp.bodyBytes, allowMalformed: true);
  }

  /// Lấy danh sách artifact (file APK) của 1 run thành công.
  Future<List<Map<String, dynamic>>> fetchArtifacts(int runId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/runs/$runId/artifacts');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) return [];
    return List<Map<String, dynamic>>.from(jsonDecode(resp.body)['artifacts']);
  }

  /// Tải file .zip chứa artifact (APK) về dạng bytes.
  Future<List<int>> downloadArtifact(int artifactId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/artifacts/$artifactId/zip');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) {
      throw Exception('Tải artifact thất bại (${resp.statusCode}).');
    }
    return resp.bodyBytes;
  }

  /// VÒNG LẶP CHÍNH: đẩy code → build → nếu lỗi thì nhờ AI tự sửa → build
  /// lại, tối đa [maxAttempts] lần. Trả về (thành công?, log cuối cùng,
  /// artifactId nếu có).
  Future<AutoBuildResult> applyAndBuildUntilSuccess({
    required Map<String, String> initialFiles,
    required String workflowFile,
    required ApiService aiApiService,
    required ProviderConfig aiProvider,
    int maxAttempts = 3,
    void Function(String status)? onStatus,
  }) async {
    var files = Map<String, String>.from(initialFiles);

    for (int attempt = 1; attempt <= maxAttempts; attempt++) {
      onStatus?.call('Lần thử $attempt/$maxAttempts: đang đẩy code lên GitHub...');
      await pushFiles(files, message: 'AI auto-build attempt $attempt');

      onStatus?.call('Đang kích hoạt build trên GitHub Actions...');
      await triggerWorkflow(workflowFile);

      onStatus?.call('Đang chờ kết quả build...');
      final run = await waitForRunCompletion(workflowFile);
      final conclusion = run['conclusion'];
      final runId = run['id'] as int;

      if (conclusion == 'success') {
        final artifacts = await fetchArtifacts(runId);
        onStatus?.call('Build thành công!');
        return AutoBuildResult(
          success: true,
          attempts: attempt,
          artifactId: artifacts.isNotEmpty ? artifacts.first['id'] as int : null,
        );
      }

      onStatus?.call('Build lỗi ở lần $attempt, đang đọc log để tự sửa...');
      final log = await fetchRunLog(runId);
      final trimmedLog = log.length > 6000 ? log.substring(log.length - 6000) : log;

      if (attempt == maxAttempts) {
        return AutoBuildResult(success: false, attempts: attempt, lastLog: trimmedLog);
      }

      // Nhờ chính model AI đang dùng đọc log lỗi + code hiện tại, sinh bản vá.
      final fixPrompt = '''
Build Flutter/Android bị lỗi. Đây là log lỗi (đã cắt bớt):
$trimmedLog

Dưới đây là các file hiện tại (đường dẫn : nội dung):
${files.entries.map((e) => '--- ${e.key} ---\n${e.value}').join('\n\n')}

Hãy sửa lỗi. CHỈ trả về các file cần thay đổi/thêm mới, theo đúng định dạng
mỗi file 1 code block có đường dẫn ngay dòng đầu, ví dụ:
```lib/main.dart
nội dung file đã sửa...
```
Không giải thích gì thêm ngoài các code block.
''';

      final fixResponse = await aiApiService.sendMessageOnce(
        config: aiProvider,
        messages: [ApiMessage('user', fixPrompt)],
      );

      final fixedFiles = _extractFiles(fixResponse);
      if (fixedFiles.isEmpty) {
        return AutoBuildResult(success: false, attempts: attempt, lastLog: trimmedLog);
      }
      files.addAll(fixedFiles);
    }

    return AutoBuildResult(success: false, attempts: maxAttempts);
  }

  Map<String, String> _extractFiles(String response) {
    final regex = RegExp(r'```([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)\n([\s\S]*?)```');
    final files = <String, String>{};
    for (final m in regex.allMatches(response)) {
      files[m.group(1)!.trim()] = m.group(2)!;
    }
    return files;
  }

  void dispose() => _client.close();
}

class AutoBuildResult {
  final bool success;
  final int attempts;
  final int? artifactId;
  final String? lastLog;
  AutoBuildResult({required this.success, required this.attempts, this.artifactId, this.lastLog});
}
