import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/message.dart';
import '../../models/provider_config.dart';
import '../../providers/chat_provider.dart';
import '../../widgets/message_bubble.dart';
import '../../widgets/chat_input_bar.dart';
import '../../widgets/token_usage_bar.dart';
import '../../widgets/export_menu.dart';
import '../../widgets/discussion_setup_sheet.dart';
import '../../widgets/chat_quick_settings_sheet.dart';

class ChatScreen extends StatefulWidget {
  final VoidCallback onOpenDrawer;
  const ChatScreen({super.key, required this.onOpenDrawer});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _scrollController = ScrollController();

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final conv = chat.current;

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: widget.onOpenDrawer),
        title: Text(conv?.title ?? 'Chọn hoặc tạo đoạn chat'),
        actions: [
          if (conv != null) ...[
            Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.groups_outlined),
                  tooltip: 'Thảo luận nhóm nhiều model',
                  onPressed: () => DiscussionSetupSheet.show(context, conv, chat),
                ),
                if (conv.discussionProviderIds.length >= 2)
                  Positioned(
                    top: 6,
                    right: 6,
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '${conv.discussionProviderIds.length}',
                        style: TextStyle(fontSize: 9, color: Theme.of(context).colorScheme.onPrimary),
                      ),
                    ),
                  ),
              ],
            ),
            IconButton(
              icon: const Icon(Icons.swap_horiz),
              tooltip: 'Chuyển model (tiếp tục ngữ cảnh, tiết kiệm token)',
              onPressed: () => _switchModelSheet(context, chat, conv),
            ),
            IconButton(
              icon: const Icon(Icons.tune),
              tooltip: 'Cài đặt nhanh: Thinking / Temperature / System prompt',
              onPressed: () => ChatQuickSettingsSheet.show(context, conv, chat),
            ),
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              tooltip: 'Đổi tên',
              onPressed: () => _renameDialog(context, chat, conv),
            ),
          ],
        ],
      ),
      body: conv == null
          ? const Center(child: Text('Chưa có đoạn chat nào được chọn.\nBấm menu để tạo mới.', textAlign: TextAlign.center))
          : Column(
              children: [
                TokenUsageBar(ratio: chat.contextUsageRatio(), isSummarizing: chat.isSummarizing),
                if (conv.discussionProviderIds.length >= 2)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Wrap(
                      spacing: 6,
                      children: conv.discussionProviderIds.map((pid) {
                        String name = pid;
                        try {
                          name = chat.storage.providers.values.firstWhere((p) => p.id == pid).name;
                        } catch (_) {}
                        return Chip(
                          label: Text(name, style: const TextStyle(fontSize: 11)),
                          visualDensity: VisualDensity.compact,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        );
                      }).toList(),
                    ),
                  ),
                if (chat.lastError != null)
                  Container(
                    width: double.infinity,
                    color: Theme.of(context).colorScheme.errorContainer,
                    padding: const EdgeInsets.all(8),
                    child: Text(chat.lastError!, style: Theme.of(context).textTheme.bodySmall),
                  ),
                Expanded(
                  child: ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: conv.messages.length,
                    itemBuilder: (_, i) => MessageBubble(message: conv.messages[i]),
                  ),
                ),
                ChatInputBar(
                  isStreaming: chat.isStreaming,
                  onSend: (text) {
                    if (conv.discussionProviderIds.length >= 2) {
                      chat.sendDiscussionMessage(text);
                    } else {
                      chat.sendMessage(text);
                    }
                    _scrollToBottom();
                  },
                  onExportTap: () {
                    final assistantMsgs =
                        conv.messages.where((m) => m.role == MessageRole.assistant && m.content.isNotEmpty).toList();
                    ExportMenu.show(context, assistantMsgs);
                  },
                ),
              ],
            ),
    );
  }

  void _switchModelSheet(BuildContext context, ChatProvider chat, conv) {
    final providers = chat.storage.providers.values.toList();
    final currentProviderId = chat.storage.providerFor(conv)?.id;

    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Chọn model để tiếp tục — giữ nguyên toàn bộ ngữ cảnh,\n'
                'không cần giải thích lại, tối ưu token khi chuyển.',
                textAlign: TextAlign.center,
              ),
            ),
            for (final p in providers)
              ListTile(
                leading: Icon(p.id == currentProviderId ? Icons.radio_button_checked : Icons.radio_button_off),
                title: Text(p.name),
                subtitle: Text(p.model),
                onTap: () async {
                  Navigator.pop(context);
                  if (p.id != currentProviderId) {
                    await chat.switchProvider(conv, p);
                  }
                },
              ),
          ],
        ),
      ),
    );
  }

  void _renameDialog(BuildContext context, ChatProvider chat, conv) {
    final controller = TextEditingController(text: conv.title);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Đổi tên đoạn chat'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () {
              chat.renameConversation(conv, controller.text.trim());
              Navigator.pop(context);
            },
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }
}
