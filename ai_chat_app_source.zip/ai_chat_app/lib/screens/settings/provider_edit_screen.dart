import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../../models/provider_config.dart';
import '../../providers/chat_provider.dart';

class ProviderEditScreen extends StatefulWidget {
  final ProviderConfig? existing;
  const ProviderEditScreen({super.key, this.existing});

  @override
  State<ProviderEditScreen> createState() => _ProviderEditScreenState();
}

class _ProviderEditScreenState extends State<ProviderEditScreen> {
  late final TextEditingController _name;
  late final TextEditingController _baseUrl;
  late final TextEditingController _apiKey;
  late final TextEditingController _model;
  late final TextEditingController _maxContext;
  late final TextEditingController _customTemplate;
  late final TextEditingController _dailyQuota;
  ApiFormat _format = ApiFormat.openaiCompatible;
  String? _reasoningEffort;
  double _temperature = 0.7;
  bool _webSearchEnabled = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _baseUrl = TextEditingController(text: e?.baseUrl ?? '');
    _apiKey = TextEditingController(text: e?.apiKey ?? '');
    _model = TextEditingController(text: e?.model ?? '');
    _maxContext = TextEditingController(text: (e?.maxContextTokens ?? 128000).toString());
    _customTemplate = TextEditingController(text: e?.customRequestTemplate ?? '');
    _dailyQuota = TextEditingController(text: e?.dailyTokenQuota?.toString() ?? '');
    _format = e?.format ?? ApiFormat.openaiCompatible;
    _reasoningEffort = e?.reasoningEffort;
    _temperature = e?.temperature ?? 0.7;
    _webSearchEnabled = e?.webSearchEnabled ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.read<ChatProvider>();

    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'Thêm Provider' : 'Sửa Provider')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Tên hiển thị')),
          const SizedBox(height: 12),
          DropdownButtonFormField<ApiFormat>(
            value: _format,
            decoration: const InputDecoration(labelText: 'Định dạng API'),
            items: const [
              DropdownMenuItem(value: ApiFormat.openaiCompatible, child: Text('OpenAI-compatible (/chat/completions)')),
              DropdownMenuItem(value: ApiFormat.anthropicCompatible, child: Text('Anthropic-compatible (/messages)')),
              DropdownMenuItem(value: ApiFormat.custom, child: Text('Custom (tự định nghĩa JSON template)')),
            ],
            onChanged: (v) => setState(() => _format = v!),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _baseUrl,
            decoration: const InputDecoration(
              labelText: 'Base URL',
              hintText: 'ví dụ: https://api.openai.com/v1',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _apiKey,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'API Key'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _model,
            decoration: const InputDecoration(
              labelText: 'Tên model',
              hintText: 'app không hardcode — tự nhập tên model của bạn',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _maxContext,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Giới hạn ngữ cảnh (token)',
              helperText: 'Dùng để tính khi nào app tự động tóm tắt nhằm tiết kiệm token',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _dailyQuota,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Hạn mức token/ngày (tuỳ chọn)',
              helperText: 'Tự nhập nếu bạn biết free-tier/gói của mình — dùng để vẽ thanh thống kê đã dùng/được cấp. Để trống nếu không muốn theo dõi.',
            ),
          ),
          const SizedBox(height: 12),
          Text('Temperature (độ sáng tạo): ${_temperature.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.bodyMedium),
          Slider(
            value: _temperature,
            min: 0.0,
            max: 2.0,
            divisions: 40,
            label: _temperature.toStringAsFixed(2),
            onChanged: (v) => setState(() => _temperature = v),
          ),
          Text(
            'Thấp (~0.2): trả lời ổn định, ít sáng tạo, hợp code/tác vụ chính xác. '
            'Cao (~1.2+): trả lời đa dạng/sáng tạo hơn, dễ lan man hơn. '
            'Giá trị này là MẶC ĐỊNH cho provider — có thể chỉnh riêng theo từng '
            'đoạn chat bằng icon ⚙️ trên màn hình chat, không cần vào lại đây.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: _reasoningEffort,
            decoration: const InputDecoration(
              labelText: 'Thinking / Reasoning effort (mặc định)',
              helperText: 'Đặt cao hơn để model suy luận kỹ trước khi viết code — '
                  'giảm tình trạng trả về khối code rỗng chỉ có comment. '
                  'Với Gemini: map sang reasoning_effort qua endpoint OpenAI-compatible. '
                  'Đổi lại: chậm hơn và tốn thêm token "suy nghĩ" (tính vào completion tokens). '
                  'Đây là mặc định — có thể đổi riêng theo từng đoạn chat mà không cần vào lại đây (icon ⚙️ trên màn hình chat).',
            ),
            items: const [
              DropdownMenuItem(value: null, child: Text('Mặc định của model (không chỉnh)')),
              DropdownMenuItem(value: 'none', child: Text('Tắt (nhanh nhất, có thể không hỗ trợ trên 1 số model)')),
              DropdownMenuItem(value: 'low', child: Text('Thấp')),
              DropdownMenuItem(value: 'medium', child: Text('Trung bình')),
              DropdownMenuItem(value: 'high', child: Text('Cao — khuyên dùng khi yêu cầu viết code')),
            ],
            onChanged: (v) => setState(() => _reasoningEffort = v),
          ),
          if (_format == ApiFormat.custom) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customTemplate,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'JSON template',
                helperText: 'Dùng {{MODEL}}, {{STREAM}}; field "messages" sẽ tự được ghép vào',
              ),
            ),
          ],
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _webSearchEnabled,
            title: const Text('Tìm kiếm web khi trả lời (mặc định)'),
            subtitle: Text(
              _format == ApiFormat.anthropicCompatible
                  ? 'Anthropic: dùng tool web_search chính thức, hoạt động ổn định.'
                  : _format == ApiFormat.openaiCompatible
                      ? 'OpenAI: CHỈ hoạt động nếu model là dòng search (gpt-4o-search-preview, gpt-5-search-api...). Gemini: hiện chưa xác nhận có tác dụng qua endpoint này.'
                      : 'Custom: thêm field web_search_options vào request, tuỳ backend có hỗ trợ hay không.',
            ),
            onChanged: (v) => setState(() => _webSearchEnabled = v),
          ),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: () async {
              final config = widget.existing ??
                  ProviderConfig(
                    id: const Uuid().v4(),
                    name: '',
                    baseUrl: '',
                    apiKey: '',
                    model: '',
                    format: ApiFormat.openaiCompatible,
                  );
              config
                ..name = _name.text.trim()
                ..baseUrl = _baseUrl.text.trim()
                ..apiKey = _apiKey.text.trim()
                ..model = _model.text.trim()
                ..format = _format
                ..maxContextTokens = int.tryParse(_maxContext.text.trim()) ?? 128000
                ..temperature = _temperature
                ..dailyTokenQuota = int.tryParse(_dailyQuota.text.trim())
                ..reasoningEffort = _reasoningEffort
                ..webSearchEnabled = _webSearchEnabled
                ..customRequestTemplate = _customTemplate.text.trim().isEmpty ? null : _customTemplate.text.trim();

              final isFirst = chat.storage.providers.isEmpty;
              await chat.storage.providers.put(config.id, config);
              if (isFirst) {
                config.isDefault = true;
                await config.save();
              }
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }
}
